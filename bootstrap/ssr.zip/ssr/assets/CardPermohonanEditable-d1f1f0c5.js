import { jsxs, Fragment, jsx } from "react/jsx-runtime";
import { M as ModalAddPermohonan } from "./ModalAddPermohonan-72cf984e.js";
import { Link } from "@inertiajs/react";
import { useState, useEffect } from "react";
function CardPermohonanEditable({
  permohonan,
  base_route,
  setPermohonan
}) {
  const [showModalEditPermohonan, setShowModalEditPermohonan] = useState(false);
  const [permohonanId, setPermohonanId] = useState("");
  const [newpermohonan, setNewpermohonan] = useState();
  const setCPermohonan = (perm) => {
    setPermohonan ? setPermohonan(perm) : null;
    setNewpermohonan(perm);
  };
  useEffect(() => {
    setNewpermohonan(permohonan);
  }, [permohonan]);
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    newpermohonan ? /* @__PURE__ */ jsx("div", { className: "relative flex flex-col min-w-0 break-words w-full mb-2 shadow-lg rounded-lg bg-blueGray-50 border-0 text-xs mt-2", children: /* @__PURE__ */ jsx("div", { className: "flex-auto px-2 lg:px-4 py-4 pt-0", children: /* @__PURE__ */ jsxs("div", { className: "relative w-full mt-2 grid grid-cols-2 md:grid-cols-4", children: [
      /* @__PURE__ */ jsx("span", { className: "font-bold", children: "No Daftar" }),
      /* @__PURE__ */ jsxs("span", { children: [
        " ",
        newpermohonan.transpermohonan.nodaftar_transpermohonan,
        "/",
        newpermohonan.transpermohonan.thdaftar_transpermohonan
      ] }),
      /* @__PURE__ */ jsx("span", { className: "font-bold", children: "Tgl Daftar" }),
      /* @__PURE__ */ jsxs("span", { children: [
        " ",
        newpermohonan.tgl_daftar
      ] }),
      /* @__PURE__ */ jsx("span", { className: "font-bold", children: "Nama Pelepas" }),
      /* @__PURE__ */ jsxs("span", { children: [
        " ",
        newpermohonan.nama_pelepas
      ] }),
      /* @__PURE__ */ jsx("span", { className: "font-bold", children: "Nama Penerima" }),
      /* @__PURE__ */ jsxs("span", { children: [
        " ",
        newpermohonan.nama_penerima
      ] }),
      /* @__PURE__ */ jsx("span", { className: "font-bold", children: "Alas Hak" }),
      /* @__PURE__ */ jsxs("span", { children: [
        " ",
        newpermohonan.nomor_hak
      ] }),
      /* @__PURE__ */ jsx("span", { className: "font-bold", children: "Atas Nama" }),
      /* @__PURE__ */ jsxs("span", { children: [
        " ",
        newpermohonan.atas_nama
      ] }),
      /* @__PURE__ */ jsx("span", { className: "font-bold", children: "Luas Tanah" }),
      /* @__PURE__ */ jsxs("span", { children: [
        " ",
        newpermohonan.luas_tanah,
        " M2"
      ] }),
      /* @__PURE__ */ jsx("span", { className: "font-bold", children: "Letak Obyek" }),
      /* @__PURE__ */ jsxs("span", { children: [
        " ",
        newpermohonan.letak_obyek
      ] }),
      /* @__PURE__ */ jsx("span", { className: "font-bold", children: "Jenis Permohonan" }),
      newpermohonan.transpermohonan && /* @__PURE__ */ jsx("span", { children: newpermohonan.transpermohonan.jenispermohonan.nama_jenispermohonan }),
      /* @__PURE__ */ jsx("span", { className: "font-bold", children: "Users" }),
      /* @__PURE__ */ jsx("span", { children: newpermohonan.users && newpermohonan.users.map(
        (user, i) => /* @__PURE__ */ jsxs("span", { children: [
          i > 0 ? ", " : "",
          user.name
        ] }, i)
      ) }),
      /* @__PURE__ */ jsx(
        Link,
        {
          href: "#",
          tabIndex: -1,
          className: "w-8 h-8 px-2 py-2 text-center rounded-full bg-blue-600/20 shadow-xl mb-1 absolute -bottom-2 -right-2 ",
          onClick: (e) => {
            e.preventDefault();
            setPermohonanId(newpermohonan.id);
            setShowModalEditPermohonan(true);
          },
          children: /* @__PURE__ */ jsx("i", { className: "fas fa-edit text-md text-center text-gray-700" })
        }
      )
    ] }) }) }) : null,
    /* @__PURE__ */ jsx(
      ModalAddPermohonan,
      {
        showModal: showModalEditPermohonan,
        setShowModal: setShowModalEditPermohonan,
        setPermohonan: setCPermohonan,
        src: route(base_route + "permohonans.modal.edit", permohonanId)
      }
    )
  ] });
}
export {
  CardPermohonanEditable as C
};
