import { jsx } from "react/jsx-runtime";
import { C as CardTableEvents } from "./CardTableEvents-3425390a.js";
import { S as StafLayout } from "./StafLayout-f28c615d.js";
import "react";
import "tailwind-merge";
import "@inertiajs/react";
import "react-use";
import "lodash";
import "./useSwal-5d61a319.js";
import "sweetalert2";
import "./Pagination-30af682d.js";
import "classnames";
import "./InputSearch-6032da7e.js";
import "./LinkButton-a291522b.js";
import "./SelectSearch-22ab8168.js";
import "react-select";
import "./DateRangeInput-279d71a2.js";
import "moment";
import "react-datepicker";
/* empty css                           */import "./Button-e2b11bd9.js";
import "./NotificationDropdown-abde11b8.js";
import "@popperjs/core";
import "./ResponsiveNavLink-41b4fa07.js";
import "react-hot-toast";
import "./AuthContext-5300e6b5.js";
import "firebase/app";
import "firebase/auth";
import "firebase/firestore";
import "firebase/storage";
import "./bootstrap-b9d9b211.js";
import "axios";
import "firebase/messaging";
import "./MenuItem-f3c50e94.js";
const Index = ({
  events
}) => {
  const { data, meta, links, base_route } = events;
  return /* @__PURE__ */ jsx(StafLayout, { children: /* @__PURE__ */ jsx(
    CardTableEvents,
    {
      color: "dark",
      events: data,
      meta,
      labelLinks: links
    }
  ) });
};
export {
  Index as default
};
