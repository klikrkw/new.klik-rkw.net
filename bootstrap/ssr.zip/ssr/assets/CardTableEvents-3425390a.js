import { jsx, Fragment, jsxs } from "react/jsx-runtime";
import { useState, useEffect } from "react";
import { twMerge } from "tailwind-merge";
import { usePage, router, Link } from "@inertiajs/react";
import { usePrevious } from "react-use";
import { pickBy } from "lodash";
import { u as useSwal } from "./useSwal-5d61a319.js";
import { P as Pagination } from "./Pagination-30af682d.js";
import { I as InputSearch } from "./InputSearch-6032da7e.js";
import { L as LinkButton } from "./LinkButton-a291522b.js";
import { S as SelectSearch } from "./SelectSearch-22ab8168.js";
import { D as DateRangeInput } from "./DateRangeInput-279d71a2.js";
import moment from "moment";
function CardTableEvents({
  color = "light",
  events,
  className = "",
  meta,
  labelLinks
}) {
  const {
    periodOpts,
    period,
    date1,
    date2,
    kategorieventOpts,
    kategorieventOpt
  } = usePage().props;
  const params = new URLSearchParams(window.location.search);
  const [values, setValues] = useState({
    search: params.get("search"),
    sortBy: params.get("sortBy"),
    sortDir: params.get("sortDir"),
    period,
    kategorievent_id: params.get("kategorievent_id"),
    date1: params.get("date1") ? params.get("date1") : date1,
    date2: params.get("date2") ? params.get("date2") : date2
  });
  const prevValues = usePrevious(values);
  function handleSortLinkClick({
    sortBy,
    sortDir
  }) {
    setValues((values2) => ({ ...values2, sortBy, sortDir }));
  }
  const IconSort = ({
    sortBy,
    sortDir
  }) => {
    if (values.sortBy === sortBy && sortDir === "asc") {
      return /* @__PURE__ */ jsx("i", { className: "fa-solid fa-sort-up" });
    } else if (values.sortBy === sortBy && sortDir === "desc") {
      return /* @__PURE__ */ jsx("i", { className: "fa-solid fa-sort-down" });
    }
    return /* @__PURE__ */ jsx("i", { className: "fa-solid fa-sort" });
  };
  const handleRemoveData = (id) => {
    router.delete(route(base_route + "transaksi.events.destroy", id));
  };
  const { base_route } = usePage().props;
  useEffect(() => {
    if (prevValues) {
      const query = Object.keys(pickBy(values)).length ? pickBy(values) : {};
      router.get(
        route(route().current() ? route().current() + "" : ""),
        query,
        {
          replace: true,
          preserveState: true
        }
      );
    }
  }, [values]);
  const handleDateChange = (dates) => {
    setValues((v) => ({ ...v, date1: dates.date1, date2: dates.date2 }));
  };
  const cperiod = periodOpts.find((e) => e.value == values.period);
  const [periode, setPeriode] = useState(
    cperiod ? cperiod : null
  );
  return /* @__PURE__ */ jsx(Fragment, { children: /* @__PURE__ */ jsxs(
    "div",
    {
      className: twMerge(
        "relative flex flex-col min-w-0 break-words w-full mb-6 shadow-lg shadow-slate-700 rounded-md py-1 ",
        color === "light" ? "bg-white" : "bg-lightBlue-900 text-white",
        className
      ),
      children: [
        /* @__PURE__ */ jsx("div", { className: "rounded-t mb-0 px-4 py-3 border-0", children: /* @__PURE__ */ jsxs("div", { className: "flex flex-col md:flex-row justify-between", children: [
          /* @__PURE__ */ jsx("div", { className: "relative w-full max-w-full flex-grow flex-1", children: /* @__PURE__ */ jsx(
            "h3",
            {
              className: "font-semibold text-lg " + (color === "light" ? "text-blueGray-700" : "text-white"),
              children: "Event List"
            }
          ) }),
          /* @__PURE__ */ jsxs("div", { className: "flex flex-col justify-center gap-2 md:flex-row items-start w-full md:w-3/4", children: [
            /* @__PURE__ */ jsxs("div", { className: "w-4/5  text-blueGray-800 flex flex-col md:flex-row justify-between items-center gap-2", children: [
              period === "tanggal" ? /* @__PURE__ */ jsx(
                DateRangeInput,
                {
                  className: "w-full md:w-3/5",
                  onDataChange: (d) => handleDateChange(d),
                  value: {
                    date1: values.date1 ? values.date1 : moment().format("YYYY-MM-DD"),
                    date2: values.date2 ? values.date2 : moment().format("YYYY-MM-DD")
                  }
                }
              ) : /* @__PURE__ */ jsx("div", { className: "w-full md:w-4/5" }),
              /* @__PURE__ */ jsx(
                SelectSearch,
                {
                  name: "period",
                  className: "w-full md:w-1/3",
                  value: periode,
                  options: periodOpts,
                  placeholder: "Periode",
                  onChange: (e) => {
                    setValues((prev) => ({
                      ...prev,
                      period: e.value
                    }));
                    setPeriode(e ? e : {});
                  }
                }
              )
            ] }),
            /* @__PURE__ */ jsx(
              SelectSearch,
              {
                placeholder: "Kategori",
                className: "w-full md:w-1/3 text-black",
                name: "kategorievent_id",
                value: kategorieventOpt,
                options: kategorieventOpts,
                onChange: (e) => {
                  setValues((prev) => ({
                    ...prev,
                    kategorievent_id: e.value
                  }));
                }
              }
            ),
            /* @__PURE__ */ jsx(
              InputSearch,
              {
                value: values.search ? values.search : "",
                onChange: (e) => setValues((v) => ({
                  ...v,
                  search: e.target.value
                }))
              }
            ),
            /* @__PURE__ */ jsx(
              LinkButton,
              {
                theme: "blue",
                href: route(
                  base_route + "transaksi.events.create"
                ),
                children: /* @__PURE__ */ jsx("span", { children: "Tambah" })
              }
            )
          ] })
        ] }) }),
        /* @__PURE__ */ jsx("div", { className: "block w-full overflow-x-auto", children: /* @__PURE__ */ jsxs("table", { className: "items-center w-full bg-transparent border-collapse", children: [
          /* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", { children: [
            /* @__PURE__ */ jsx(
              "th",
              {
                className: "px-6 align-middle border border-solid py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left " + (color === "light" ? "bg-blueGray-50 text-blueGray-500 border-blueGray-100" : "bg-lightBlue-800 text-lightBlue-300 border-lightBlue-700"),
                children: /* @__PURE__ */ jsx(
                  Link,
                  {
                    href: "#",
                    onClick: (e) => handleSortLinkClick({
                      sortBy: "id",
                      sortDir: values.sortDir === "asc" ? "desc" : "asc"
                    }),
                    children: /* @__PURE__ */ jsxs("div", { className: "flex flex-row justify-between", children: [
                      /* @__PURE__ */ jsx("span", { children: "Id" }),
                      /* @__PURE__ */ jsx(
                        IconSort,
                        {
                          sortBy: "id",
                          sortDir: values.sortDir || ""
                        }
                      )
                    ] })
                  }
                )
              }
            ),
            /* @__PURE__ */ jsx(
              "th",
              {
                className: "px-6 align-middle border border-solid py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left " + (color === "light" ? "bg-blueGray-50 text-blueGray-500 border-blueGray-100" : "bg-lightBlue-800 text-lightBlue-300 border-lightBlue-700"),
                children: /* @__PURE__ */ jsx(
                  Link,
                  {
                    href: "#",
                    onClick: (e) => handleSortLinkClick({
                      sortBy: "start",
                      sortDir: values.sortDir === "asc" ? "desc" : "asc"
                    }),
                    children: /* @__PURE__ */ jsxs("div", { className: "flex flex-row justify-between", children: [
                      /* @__PURE__ */ jsx("span", { children: "Start" }),
                      /* @__PURE__ */ jsx(
                        IconSort,
                        {
                          sortBy: "start",
                          sortDir: values.sortDir || ""
                        }
                      )
                    ] })
                  }
                )
              }
            ),
            /* @__PURE__ */ jsx(
              "th",
              {
                className: "px-6 align-middle border border-solid py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left " + (color === "light" ? "bg-blueGray-50 text-blueGray-500 border-blueGray-100" : "bg-lightBlue-800 text-lightBlue-300 border-lightBlue-700"),
                children: /* @__PURE__ */ jsx(
                  Link,
                  {
                    href: "#",
                    onClick: (e) => handleSortLinkClick({
                      sortBy: "end",
                      sortDir: values.sortDir === "asc" ? "desc" : "asc"
                    }),
                    children: /* @__PURE__ */ jsxs("div", { className: "flex flex-row justify-between", children: [
                      /* @__PURE__ */ jsx("span", { children: "End" }),
                      /* @__PURE__ */ jsx(
                        IconSort,
                        {
                          sortBy: "end",
                          sortDir: values.sortDir || ""
                        }
                      )
                    ] })
                  }
                )
              }
            ),
            /* @__PURE__ */ jsx(
              "th",
              {
                className: "px-6 align-middle border border-solid py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left " + (color === "light" ? "bg-blueGray-50 text-blueGray-500 border-blueGray-100" : "bg-lightBlue-800 text-lightBlue-300 border-lightBlue-700"),
                children: /* @__PURE__ */ jsx(
                  Link,
                  {
                    href: "#",
                    onClick: (e) => handleSortLinkClick({
                      sortBy: "title",
                      sortDir: values.sortDir === "asc" ? "desc" : "asc"
                    }),
                    children: /* @__PURE__ */ jsxs("div", { className: "flex flex-row justify-between", children: [
                      /* @__PURE__ */ jsx("span", { children: "Nama Event" }),
                      /* @__PURE__ */ jsx(
                        IconSort,
                        {
                          sortBy: "title",
                          sortDir: values.sortDir || ""
                        }
                      )
                    ] })
                  }
                )
              }
            ),
            /* @__PURE__ */ jsx(
              "th",
              {
                className: "px-6 align-middle border border-solid py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left " + (color === "light" ? "bg-blueGray-50 text-blueGray-500 border-blueGray-100" : "bg-lightBlue-800 text-lightBlue-300 border-lightBlue-700"),
                children: /* @__PURE__ */ jsx("div", { className: "flex flex-row justify-between", children: /* @__PURE__ */ jsx("span", { children: "Kategori" }) })
              }
            ),
            /* @__PURE__ */ jsx(
              "th",
              {
                className: "px-6 align-middle border border-solid py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left " + (color === "light" ? "bg-blueGray-50 text-blueGray-500 border-blueGray-100" : "bg-lightBlue-800 text-lightBlue-300 border-lightBlue-700"),
                children: "Options"
              }
            )
          ] }) }),
          /* @__PURE__ */ jsx("tbody", { children: events.map(
            ({ id, start, end, title, kategorievent }, index) => /* @__PURE__ */ jsxs("tr", { children: [
              /* @__PURE__ */ jsx("td", { className: "border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-2", children: id }),
              /* @__PURE__ */ jsx("td", { className: "border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-2", children: moment(start).format(
                "DD-MM-YYYY HH:mm:ss"
              ) }),
              /* @__PURE__ */ jsx("td", { className: "border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-2", children: moment(end).format(
                "DD-MM-YYYY HH:mm:ss"
              ) }),
              /* @__PURE__ */ jsx("td", { className: "border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-2", children: title }),
              /* @__PURE__ */ jsx("td", { className: "border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-2", children: kategorievent.nama_kategorievent }),
              /* @__PURE__ */ jsx("td", { className: "border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-2 ", children: /* @__PURE__ */ jsxs("div", { className: "flex justify-start gap-1 ", children: [
                /* @__PURE__ */ jsx(
                  Link,
                  {
                    href: route(
                      base_route + "transaksi.events.edit",
                      id
                    ),
                    className: "text-lightBlue-500 background-transparent font-bold px-3 py-1 text-xs outline-none focus:outline-none hover:text-lightBlue-100 hover:scale-105 mr-1 mb-1 ease-linear transition-all duration-150",
                    type: "button",
                    children: "Edit"
                  }
                ),
                /* @__PURE__ */ jsx(
                  "button",
                  {
                    onClick: (e) => useSwal.confirm({
                      title: "Hapus Data",
                      text: "apakah akan menghapus?"
                    }).then((result) => {
                      if (result.isConfirmed) {
                        handleRemoveData(
                          id
                        );
                      }
                    }),
                    className: "text-lightBlue-500 background-transparent font-bold px-3 py-1 text-xs outline-none focus:outline-none hover:text-lightBlue-100 hover:scale-105 mr-1 mb-1 ease-linear transition-all duration-150",
                    type: "button",
                    children: "Hapus"
                  }
                )
              ] }) })
            ] }, index)
          ) })
        ] }) }),
        meta.total > meta.per_page ? /* @__PURE__ */ jsx(
          "div",
          {
            className: "flex justify-end px-2 py-1  " + (color === "light" ? "bg-blueGray-50 text-blueGray-500 border-blueGray-100" : "bg-lightBlue-800 text-lightBlue-300 border-lightBlue-700"),
            children: /* @__PURE__ */ jsx(
              Pagination,
              {
                links: meta.links,
                labelLinks
              }
            )
          }
        ) : null
      ]
    }
  ) });
}
export {
  CardTableEvents as C
};
