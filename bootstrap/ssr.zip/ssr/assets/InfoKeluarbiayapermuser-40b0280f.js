import { jsx } from "react/jsx-runtime";
import { C as CardTableInfoKeluarbiayapermusers } from "./CardTableInfoKeluarbiayapermusers-64f6eb3e.js";
import { A as AdminLayout } from "./AdminLayout-4bc80775.js";
import "react";
import "tailwind-merge";
import "@inertiajs/react";
import "react-use";
import "lodash";
import "./Pagination-30af682d.js";
import "classnames";
import "./InputSearch-6032da7e.js";
import "./AsyncSelectSearch-23c2f5cb.js";
import "react-select/async";
import "./bootstrap-b9d9b211.js";
import "axios";
import "./SelectSearch-22ab8168.js";
import "react-select";
import "./DateRangeInput-279d71a2.js";
import "moment";
import "react-datepicker";
/* empty css                           */import "./Button-e2b11bd9.js";
import "./PopupMenu-b5bc7ace.js";
import "@headlessui/react";
import "@heroicons/react/20/solid";
import "./TranspermohonanSelect-e6be2ec6.js";
import "swr";
import "./ListboxSelect-3ce899e5.js";
import "./Modal-d06b3568.js";
import "./LinkButton-a291522b.js";
import "@zxing/browser";
import "./useScreenSize-4351026c.js";
import "react-modal-image";
import "./NotificationDropdown-abde11b8.js";
import "@popperjs/core";
import "./ResponsiveNavLink-41b4fa07.js";
import "react-hot-toast";
import "./AuthContext-5300e6b5.js";
import "firebase/app";
import "firebase/auth";
import "firebase/firestore";
import "firebase/storage";
import "firebase/messaging";
import "./MenuItem-f3c50e94.js";
const InfoKeluarbiayapermuser = ({
  dkeluarbiayapermusers: { data, meta, links }
}) => {
  return /* @__PURE__ */ jsx(AdminLayout, { children: /* @__PURE__ */ jsx(
    CardTableInfoKeluarbiayapermusers,
    {
      dkeluarbiayapermusers: data,
      color: "dark",
      meta,
      labelLinks: links
    }
  ) });
};
export {
  InfoKeluarbiayapermuser as default
};
