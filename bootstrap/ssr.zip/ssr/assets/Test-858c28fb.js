import { jsx, jsxs } from "react/jsx-runtime";
import { A as AdminLayout } from "./AdminLayout-4bc80775.js";
import { useState, useEffect } from "react";
import "./NotificationDropdown-abde11b8.js";
import "@popperjs/core";
import "./ResponsiveNavLink-41b4fa07.js";
import "@inertiajs/react";
import "react-hot-toast";
import "./AuthContext-5300e6b5.js";
import "firebase/app";
import "firebase/auth";
import "firebase/firestore";
import "firebase/storage";
import "./bootstrap-b9d9b211.js";
import "axios";
import "firebase/messaging";
import "./MenuItem-f3c50e94.js";
const Test = ({ auth, data }) => {
  const [ldata, setLData] = useState([]);
  useEffect(() => {
    let dt = data;
    if (dt.data) {
      if (dt.data.content) {
        let content = dt.data.content;
        for (let index = 0; index < content.length; index++) {
          let element = content[index];
          let nmr = { ...element };
          let revisi = { ...element };
          nmr = nmr.nomor;
          let start1 = nmr.indexOf("<u>") != -1 ? nmr.indexOf("<u>") + 3 : 0;
          let end1 = nmr.indexOf("</u>") != -1 ? nmr.indexOf("</u>") - start1 : 13;
          nmr = nmr.substr(start1, end1);
          element.nomor = nmr;
          revisi = revisi.nomor;
          let start = revisi.indexOf("REVISI : ") != -1 ? revisi.indexOf("REVISI : ") + 9 : 0;
          let end = revisi.indexOf("</span>") != -1 ? revisi.indexOf("</span>") - start : 13;
          let xrevisi = revisi.substr(start, end);
          element.revisi = xrevisi;
          element.nama_wp = element.nama_wp.replace(/<[^>]*>/g, "");
          content[index] = element;
        }
        setLData(content);
      }
    }
  }, [data]);
  return /* @__PURE__ */ jsx(
    AdminLayout,
    {
      header: /* @__PURE__ */ jsx("h2", { className: "font-semibold text-xl text-gray-800 leading-tight", children: "Dashboard" }),
      children: /* @__PURE__ */ jsx("div", { className: "w-full lg:w-4/12 h-auto ", children: /* @__PURE__ */ jsx("div", { className: "relative w-full xl:w-8/12 mb-12 xl:mb-0", children: /* @__PURE__ */ jsx("ul", { children: ldata && ldata.map((v, i) => /* @__PURE__ */ jsxs("li", { children: [
        /* @__PURE__ */ jsx("div", { children: v.nomor }),
        /* @__PURE__ */ jsx("div", { children: v.revisi }),
        /* @__PURE__ */ jsx("div", { children: v.nama_wp })
      ] }, i)) }) }) })
    }
  );
};
export {
  Test as default
};
