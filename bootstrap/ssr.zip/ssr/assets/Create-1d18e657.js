import { jsx, jsxs } from "react/jsx-runtime";
import { M as ModalAddPermohonan } from "./ModalAddPermohonan-72cf984e.js";
import { D as DateInput } from "./DateInput-8d13eeac.js";
import { I as Input } from "./Input-72be4948.js";
import { L as LinkButton } from "./LinkButton-a291522b.js";
import { L as LoadingButton } from "./LoadingButton-c9189101.js";
import { P as PermohonanSelect } from "./PermohonanSelect-e6abd996.js";
import { S as SelectSearch } from "./SelectSearch-22ab8168.js";
import { A as AdminLayout } from "./AdminLayout-4bc80775.js";
import { usePage, useForm } from "@inertiajs/react";
import moment from "moment";
import { useState } from "react";
import "./bootstrap-b9d9b211.js";
import "axios";
import "react-loader-spinner";
import "@headlessui/react";
import "react-datepicker";
import "tailwind-merge";
/* empty css                           */import "classnames";
import "@heroicons/react/20/solid";
import "swr";
import "./ListboxSelect-3ce899e5.js";
import "lodash";
import "react-select";
import "./NotificationDropdown-abde11b8.js";
import "@popperjs/core";
import "./ResponsiveNavLink-41b4fa07.js";
import "react-hot-toast";
import "./AuthContext-5300e6b5.js";
import "firebase/app";
import "firebase/auth";
import "firebase/firestore";
import "firebase/storage";
import "firebase/messaging";
import "./MenuItem-f3c50e94.js";
const Create = () => {
  const {
    base_route,
    kategorieventOpts,
    transpermohonanOpts,
    transpermohonanOpt,
    transpermohonan_id,
    permohonan_id,
    permohonan
  } = usePage().props;
  const { data, setData, errors, post, processing } = useForm({
    start: moment().format("YYYY-MM-DD HH:mm"),
    end: moment().format("YYYY-MM-DD HH:mm"),
    title: "",
    data: "",
    kategorievent: "",
    kategorievent_id: "",
    transpermohonan_id,
    permohonan,
    _method: "POST"
  });
  function handleSubmit(e) {
    e.preventDefault();
    post(route(base_route + "transaksi.events.store"));
  }
  const setPermohonan = (permohonan2) => {
    if (permohonan2) {
      setData({
        ...data,
        transpermohonan_id: permohonan2.transpermohonan.id,
        permohonan: permohonan2
      });
    }
  };
  const [showModalAddPermohonan, setShowModalAddPermohonan] = useState(false);
  return /* @__PURE__ */ jsx(AdminLayout, { children: /* @__PURE__ */ jsxs("div", { className: "flex content-center items-center justify-center h-full", children: [
    /* @__PURE__ */ jsx("div", { className: "w-full lg:w-1/2 px-4", children: /* @__PURE__ */ jsxs("div", { className: "relative flex flex-col min-w-0 break-words w-full mb-6 shadow-lg rounded-lg bg-blueGray-200 border-0", children: [
      /* @__PURE__ */ jsxs("div", { className: "rounded-t mb-0 px-6 py-6", children: [
        /* @__PURE__ */ jsx("div", { className: "text-center mb-3", children: /* @__PURE__ */ jsx("h6", { className: "text-blueGray-500 text-lg font-bold", children: "Event Baru" }) }),
        /* @__PURE__ */ jsx("hr", { className: "mt-6 border-b-1 border-blueGray-300" })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "flex-auto px-4 lg:px-10 py-10 pt-0", children: /* @__PURE__ */ jsxs("form", { onSubmit: handleSubmit, children: [
        /* @__PURE__ */ jsxs("div", { className: "w-full flex flex-row gap-2", children: [
          /* @__PURE__ */ jsx(
            DateInput,
            {
              label: "Start",
              showTimeSelect: true,
              selected: data.start,
              value: data.start,
              name: "start",
              errors: errors.start,
              customDateFormat: "DD-MMM-YYYY HH:mm",
              onChange: (e) => setData(
                "start",
                moment(e).format(
                  "YYYY-MM-DD HH:mm"
                )
              )
            }
          ),
          /* @__PURE__ */ jsx(
            DateInput,
            {
              label: "End",
              showTimeSelect: true,
              selected: data.end,
              value: data.end,
              name: "end",
              errors: errors.end,
              customDateFormat: "DD-MMM-YYYY HH:mm",
              onChange: (e) => setData(
                "end",
                moment(e).format(
                  "YYYY-MM-DD HH:mm"
                )
              )
            }
          )
        ] }),
        /* @__PURE__ */ jsx(
          Input,
          {
            name: "title",
            label: "Title",
            errors: errors.title,
            value: data.title,
            onChange: (e) => setData("title", e.target.value)
          }
        ),
        /* @__PURE__ */ jsx(
          Input,
          {
            name: "data",
            label: "Data",
            errors: errors.data,
            value: data.data,
            onChange: (e) => setData("data", e.target.value)
          }
        ),
        /* @__PURE__ */ jsx(
          SelectSearch,
          {
            label: "Kategori",
            placeholder: "Pilih Kategori",
            name: "kategorievent_id",
            className: "mb-3 z-[51]",
            value: data.kategorievent,
            options: kategorieventOpts,
            onChange: (e) => setData({
              ...data,
              kategorievent: e ? e : {},
              kategorievent_id: e ? e.value : ""
            }),
            errors: errors.kategorievent_id
          }
        ),
        /* @__PURE__ */ jsxs("div", { className: "flex flex-row justify-between items-center", children: [
          /* @__PURE__ */ jsx(
            PermohonanSelect,
            {
              value: data.permohonan,
              className: "mb-1 w-full mr-2",
              errors: errors.transpermohonan_id,
              onValueChange: (e) => {
                setPermohonan(e);
              }
            }
          ),
          /* @__PURE__ */ jsx(
            "a",
            {
              tabIndex: -1,
              href: "#",
              className: "w-8 h-8 px-2 py-1 rounded-full bg-blue-600/20 shadow-xl mb-1",
              onClick: (e) => {
                e.preventDefault();
                setShowModalAddPermohonan(true);
              },
              children: /* @__PURE__ */ jsx("i", { className: "fas fa-add text-md text-center text-gray-700" })
            }
          )
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between ", children: [
          /* @__PURE__ */ jsx(
            LinkButton,
            {
              theme: "blueGrey",
              href: route(
                base_route + "transaksi.events.index"
              ),
              children: /* @__PURE__ */ jsx("span", { children: "Kembali" })
            }
          ),
          /* @__PURE__ */ jsx(
            LoadingButton,
            {
              theme: "black",
              loading: processing,
              type: "submit",
              children: /* @__PURE__ */ jsx("span", { children: "Simpan" })
            }
          )
        ] })
      ] }) })
    ] }) }),
    /* @__PURE__ */ jsx(
      ModalAddPermohonan,
      {
        showModal: showModalAddPermohonan,
        setShowModal: setShowModalAddPermohonan,
        setPermohonan,
        src: route(base_route + "permohonans.modal.create")
      }
    )
  ] }) });
};
export {
  Create as default
};
