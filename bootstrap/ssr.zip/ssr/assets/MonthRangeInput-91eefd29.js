import { jsx, Fragment, jsxs } from "react/jsx-runtime";
import { useState, Fragment as Fragment$1, useCallback } from "react";
import { twMerge } from "tailwind-merge";
import { Combobox, Transition } from "@headlessui/react";
import { ChevronUpDownIcon, CheckIcon } from "@heroicons/react/20/solid";
import moment from "moment";
import ReactDatePicker from "react-datepicker";
/* empty css                           */import { B as Button } from "./Button-e2b11bd9.js";
function SearchableCombobox({ options, className, onValueChange, value }) {
  const val = options.find((v) => v.value.includes(value ? value : ""));
  const [selected, setSelected] = useState(val);
  const [query, setQuery] = useState("");
  const filteredOption = query === "" ? options : options.filter(
    (person) => person.label.toLowerCase().replace(/\s+/g, "").includes(query.toLowerCase().replace(/\s+/g, ""))
  );
  const onChange = (e) => {
    const val2 = options.find((v) => v === e);
    setSelected(val2 ? val2 : options[0]);
    onValueChange(e);
  };
  return /* @__PURE__ */ jsx(Fragment, { children: /* @__PURE__ */ jsx(Combobox, { value: selected ? selected : "", onChange, children: /* @__PURE__ */ jsxs("div", { className: "relative", children: [
    /* @__PURE__ */ jsxs("div", { className: twMerge("relative w-full cursor-default overflow-hidden bg-white text-left shadow-md focus:outline-none focus-visible:ring-2 focus-visible:ring-white/75 focus-visible:ring-offset-2 focus-visible:ring-offset-teal-300 sm:text-sm", className), children: [
      /* @__PURE__ */ jsx(
        Combobox.Input,
        {
          className: "w-full border-none py-2 pl-3 pr-8 text-sm leading-5 text-gray-900 focus:ring-0",
          displayValue: (person) => person.label,
          onChange: (event) => setQuery(event.target.value)
        }
      ),
      /* @__PURE__ */ jsx(Combobox.Button, { className: "absolute inset-y-0 right-0 flex items-center pr-2", children: /* @__PURE__ */ jsx(
        ChevronUpDownIcon,
        {
          className: "h-5 w-5 text-gray-400",
          "aria-hidden": "true"
        }
      ) })
    ] }),
    /* @__PURE__ */ jsx(
      Transition,
      {
        as: Fragment$1,
        leave: "transition ease-in duration-100",
        leaveFrom: "opacity-100",
        leaveTo: "opacity-0",
        afterLeave: () => setQuery(""),
        children: /* @__PURE__ */ jsx(Combobox.Options, { className: "absolute mt-1 max-h-60 w-full overflow-auto rounded-md bg-white py-1 text-base shadow-lg ring-1 ring-black/5 focus:outline-none sm:text-sm", children: filteredOption.length === 0 && query !== "" ? /* @__PURE__ */ jsx("div", { className: "relative cursor-default select-none px-2 py-2 text-gray-700", children: "Nothing value." }) : filteredOption.map((person) => /* @__PURE__ */ jsx(
          Combobox.Option,
          {
            className: ({ active }) => `relative cursor-default select-none py-2 pl-3 pr-2 ${active ? "bg-teal-600 text-white" : "text-gray-900"}`,
            value: person,
            children: ({ selected: selected2, active }) => /* @__PURE__ */ jsxs(Fragment, { children: [
              /* @__PURE__ */ jsx(
                "span",
                {
                  className: `block truncate ${selected2 ? "font-medium" : "font-normal"}`,
                  children: person.label
                }
              ),
              selected2 ? /* @__PURE__ */ jsx(
                "span",
                {
                  className: `absolute inset-y-0 left-0 flex items-center pl-2 ${active ? "text-white" : "text-teal-600"}`,
                  children: /* @__PURE__ */ jsx(CheckIcon, { className: "h-5 w-5", "aria-hidden": "true" })
                }
              ) : null
            ] })
          },
          person.value
        )) })
      }
    )
  ] }) }) });
}
const InputWithSelect = ({ value, comboboxValue, onInputChange, onSelecChange, className = "", ...props }) => {
  const options = [
    { value: "", label: "-- All --" },
    { value: "nomor_hak", label: "Nomor Hak" },
    { value: "nama_pelepas", label: "Nama Pelepas" },
    { value: "nama_penerima", label: "Nama Penerima" }
  ];
  const [selectValue, setSelectValue] = useState(options[0]);
  return /* @__PURE__ */ jsxs("div", { className: twMerge("flex w-full items-start relative mb-3 gap-0 ", className), children: [
    /* @__PURE__ */ jsx(SearchableCombobox, { options, className: "rounded-tl-md rounded-bl-md w-full", value: comboboxValue, onValueChange: (e) => {
      const val = options.find((v) => v.value === e.value);
      setSelectValue(val ? val : options[0]);
      onSelecChange(e);
    } }),
    /* @__PURE__ */ jsx(
      "input",
      {
        name: "search",
        value,
        onChange: (e) => onInputChange(e, selectValue.value),
        autoComplete: "off",
        ...props,
        className: `border-0 px-2 py-2 placeholder-blueGray-300 text-blueGray-600 bg-white rounded-tr-md rounded-br-md text-sm shadow focus:outline-none focus:ring w-3/5 ease-linear transition-all duration-150 `
      }
    )
  ] });
};
const MonthRangeInput = ({ onDataChange, className, errors, label, value }) => {
  const renderMonthContent = (month = 0, shortMonth = "", longMonth = "", day = 0) => {
    const fullYear = new Date(day).getFullYear();
    const tooltipText = `Tooltip for month: ${longMonth} ${fullYear}`;
    return /* @__PURE__ */ jsx("span", { title: tooltipText, children: shortMonth });
  };
  const [dates, setDates] = useState({ date1: value.date1 ? value.date1 : moment().format("YYYY-MM-DD"), date2: value.date2 ? value.date2 : moment().format("YYYY-MM-DD") });
  const handleChange = useCallback((field, value2) => {
    setDates((d) => ({ ...d, [field]: moment(value2).format("YYYY-MM-DD") }));
  }, [dates]);
  return /* @__PURE__ */ jsxs("div", { className: twMerge("relative w-full mb-3 text-black ", className), children: [
    label && /* @__PURE__ */ jsx(
      "label",
      {
        className: `block uppercase text-blueGray-600 text-xs font-bold mb-2 ${errors ? "text-red-500" : ""} `,
        children: label
      }
    ),
    /* @__PURE__ */ jsxs("div", { className: "flex flex-row gap-0", children: [
      /* @__PURE__ */ jsx(
        ReactDatePicker,
        {
          selected: moment(dates.date1).toDate(),
          value: moment(dates.date1).format("MMM-YYYY"),
          renderMonthContent,
          showMonthYearPicker: true,
          dateFormat: "MM/yyyy",
          className: " px-3 py-2 placeholder-blueGray-300 text-blueGray-600 border-blueGray-300 bg-white rounded-l-md text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150",
          onChange: (e) => handleChange("date1", moment(e).toISOString())
        }
      ),
      /* @__PURE__ */ jsx(
        ReactDatePicker,
        {
          selected: moment(dates.date2).toDate(),
          value: moment(dates.date2).format("MMM-YYYY"),
          renderMonthContent,
          showMonthYearPicker: true,
          dateFormat: "MM/yyyy",
          className: "px-3 py-2 placeholder-blueGray-300 text-blueGray-600 border-blueGray-300 bg-white text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150",
          onChange: (e) => handleChange("date2", moment(e).toISOString())
        }
      ),
      /* @__PURE__ */ jsx(Button, { theme: "blue", className: "text-sm rounded-r-md", onClick: (e) => onDataChange(dates), children: /* @__PURE__ */ jsx("i", { className: "fa-solid fa-magnifying-glass" }) })
    ] })
  ] });
};
export {
  InputWithSelect as I,
  MonthRangeInput as M
};
