import { jsxs, jsx } from "react/jsx-runtime";
import { C as CardDkasbonList, a as CardDkasbonnopermList } from "./CardDkasbonnopermList-f8130a68.js";
import { C as CardPermohonanEditable } from "./CardPermohonanEditable-d1f1f0c5.js";
import { M as Modal } from "./Modal-29294895.js";
import { M as ModalAddPermohonan } from "./ModalAddPermohonan-72cf984e.js";
import { M as ModalCetakLaporan } from "./ModalCetakLaporan-767963a0.js";
import { B as Button } from "./Button-e2b11bd9.js";
import { I as Input } from "./Input-72be4948.js";
import { L as LinkButton } from "./LinkButton-a291522b.js";
import { L as LoadingButton } from "./LoadingButton-c9189101.js";
import { M as MoneyInput } from "./MoneyInput-87a36109.js";
import { S as SelectSearch } from "./SelectSearch-22ab8168.js";
import { T as TranspermohonanSelect } from "./TranspermohonanSelect-e6be2ec6.js";
import { A as AdminLayout } from "./AdminLayout-4bc80775.js";
import { u as useSwal } from "./useSwal-5d61a319.js";
import { usePage, useForm, router } from "@inertiajs/react";
import moment from "moment";
import { useState, useRef, useEffect } from "react";
import "./Pagination-30af682d.js";
import "classnames";
import "@headlessui/react";
import "./bootstrap-b9d9b211.js";
import "axios";
import "react-loader-spinner";
import "./Modal-d06b3568.js";
import "react-dom";
import "@emotion/react";
import "@emotion/cache";
import "tailwind-merge";
import "react-number-format";
import "lodash";
import "react-select";
import "@heroicons/react/20/solid";
import "swr";
import "./ListboxSelect-3ce899e5.js";
import "@zxing/browser";
import "./useScreenSize-4351026c.js";
import "./NotificationDropdown-abde11b8.js";
import "@popperjs/core";
import "./ResponsiveNavLink-41b4fa07.js";
import "react-hot-toast";
import "./AuthContext-5300e6b5.js";
import "firebase/app";
import "firebase/auth";
import "firebase/firestore";
import "firebase/storage";
import "firebase/messaging";
import "./MenuItem-f3c50e94.js";
import "sweetalert2";
const Edit = () => {
  var _a, _b;
  const {
    kasbon,
    statuskasbonOpts,
    statuskasbonOpt,
    is_admin,
    itemkegiatanOpts,
    base_route,
    allPermohonan
  } = usePage().props;
  const [showStatusDialog, setShowStatusDialog] = useState(false);
  const [showModalLaporan, setShowModalLaporan] = useState(false);
  const [statusKasbon, setStatusKasbon] = useState(
    statuskasbonOpt
  );
  const { data, setData, errors, post, processing, reset } = useForm({
    // jumlah_kasbon: kasbon.jumlah_kasbon.toString() || "0",
    // jumlah_penggunaan: kasbon.jumlah_penggunaan.toString() || "0",
    // sisa_penggunaan: kasbon.sisa_penggunaan.toString() || "0",
    // keperluan: kasbon.keperluan || "",
    // status_kasbon: kasbon.status_kasbon || "",
    // statuskabonOpt: statuskasbonOpt || undefined,
    // user: kasbon.user,
    itemkegiatan: void 0,
    itemkegiatan_id: "",
    jumlah_biaya: "0",
    ket_biaya: "",
    permohonan: void 0,
    transpermohonan_id: "",
    jenis_kasbon: kasbon.jenis_kasbon,
    _method: "PUT"
  });
  function handleSubmit(e) {
    e.preventDefault();
    post(route(base_route + "transaksi.kasbons.update", kasbon.id), {
      onSuccess: () => {
        reset();
        if (kasbon.jenis_kasbon === "permohonan") {
          firstInput.current.value = "";
          firstInput.current.focus();
        } else {
          secondInput.current.focus();
        }
      }
    });
  }
  const firstInput = useRef();
  const secondInput = useRef();
  const [showModalAddPermohonan, setShowModalAddPermohonan] = useState(false);
  useEffect(() => {
    if (kasbon.jenis_kasbon === "permohonan") {
      if (firstInput.current) {
        firstInput.current.focus();
      }
    } else {
      if (secondInput.current) {
        secondInput.current.focus();
      }
    }
  }, []);
  const setPermohonan = (perm) => {
    firstInput.current.value = perm == null ? void 0 : perm.nama_penerima;
    setData({
      ...data,
      permohonan: perm,
      transpermohonan_id: (perm == null ? void 0 : perm.transpermohonan) ? perm.transpermohonan.id : ""
    });
  };
  function prosesLaporan(e) {
    e.preventDefault();
    setShowModalLaporan(true);
  }
  function handleUpdateStatus(e) {
    e.preventDefault();
    const data2 = {
      status_kasbon: statusKasbon == null ? void 0 : statusKasbon.value
    };
    router.put(
      route(base_route + "transaksi.kasbons.status.update", kasbon.id),
      data2,
      {
        onSuccess: (e2) => {
          setShowStatusDialog(false);
          useSwal.info({
            title: "Informasi",
            text: "Status Kasbon Updated"
          });
        }
      }
    );
  }
  return /* @__PURE__ */ jsxs(AdminLayout, { children: [
    /* @__PURE__ */ jsxs("div", { className: "flex content-center items-center justify-center relative -top-2", children: [
      /* @__PURE__ */ jsx("div", { className: "w-full lg:w-11/12 px-4 ", children: /* @__PURE__ */ jsxs("div", { className: "relative flex flex-col min-w-0 break-words w-full mb-2 shadow-lg shadow-slate-400 rounded-lg bg-blueGray-100 border-0", children: [
        /* @__PURE__ */ jsx("div", { className: "rounded-t mb-1 px-4 py-4 ", children: /* @__PURE__ */ jsxs("div", { className: "w-full grid grid-cols-1 md:grid-cols-2 bg-lightBlue-800 text-lightBlue-100 px-4 py-2 shadow-md rounded-lg", children: [
          /* @__PURE__ */ jsx("div", { className: "text-left", children: /* @__PURE__ */ jsx("h6", { className: "font-semibold", children: "KASBON PENGELUARAN BIAYA" }) }),
          /* @__PURE__ */ jsx("div", { className: "text-left md:text-right", children: moment(
            kasbon.tgl_kasbon,
            "DD MMM YYYY hh:mm"
          ).format("DD MMM YYYY hh:mm") })
        ] }) }),
        /* @__PURE__ */ jsxs("div", { className: "flex-auto px-4 lg:px-6 py-4 pt-0", children: [
          /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 md:grid-cols-4 gap-1", children: [
            /* @__PURE__ */ jsx(
              Input,
              {
                name: "keperluan",
                label: "Keperluan",
                value: kasbon.keperluan
              }
            ),
            /* @__PURE__ */ jsx(
              Input,
              {
                name: "instansi",
                label: "Instansi",
                value: kasbon.instansi.nama_instansi,
                disabled: true
              }
            ),
            /* @__PURE__ */ jsx(
              Input,
              {
                name: "user",
                label: "User",
                value: (_a = kasbon.user) == null ? void 0 : _a.name,
                disabled: true
              }
            )
          ] }),
          kasbon && kasbon.status_kasbon == "wait_approval" ? /* @__PURE__ */ jsx("form", { onSubmit: handleSubmit, children: /* @__PURE__ */ jsxs("div", { className: "w-full grid grid-cols-2 gap-2", children: [
            /* @__PURE__ */ jsxs("div", { className: "w-full grid grid-cols-1", children: [
              kasbon.jenis_kasbon === "permohonan" && /* @__PURE__ */ jsxs("div", { className: "flex flex-row justify-between items-center", children: [
                /* @__PURE__ */ jsx(
                  TranspermohonanSelect,
                  {
                    inputRef: firstInput,
                    value: (_b = data.permohonan) == null ? void 0 : _b.transpermohonan,
                    className: "mb-1 w-full mr-2",
                    errors: errors.transpermohonan_id,
                    isDisabledCheck: !allPermohonan,
                    isChecked: allPermohonan,
                    onValueChange: (e) => {
                      if (e) {
                        setData(
                          (v) => ({
                            ...v,
                            permohonan: e.permohonan,
                            transpermohonan_id: e.id
                          })
                        );
                      } else {
                        setData(
                          (v) => ({
                            ...v,
                            transpermohonan_id: ""
                          })
                        );
                      }
                    }
                  }
                ),
                /* @__PURE__ */ jsx(
                  "a",
                  {
                    tabIndex: -1,
                    href: "#",
                    className: "w-8 h-8 px-2 py-1 rounded-full bg-blue-600/20 shadow-xl mb-1",
                    onClick: (e) => {
                      e.preventDefault();
                      setShowModalAddPermohonan(
                        true
                      );
                    },
                    children: /* @__PURE__ */ jsx("i", { className: "fas fa-add text-md text-center text-gray-700" })
                  }
                )
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 gap-2", children: [
                /* @__PURE__ */ jsx(
                  SelectSearch,
                  {
                    focused: true,
                    xref: secondInput,
                    placeholder: "Pilih Kegiatan",
                    name: "itemkegiatan_id",
                    value: data.itemkegiatan,
                    options: itemkegiatanOpts,
                    onChange: (e) => setData({
                      ...data,
                      itemkegiatan: e ? e : {},
                      itemkegiatan_id: e ? e.value : ""
                    }),
                    errors: errors.itemkegiatan_id
                  }
                ),
                /* @__PURE__ */ jsx(
                  Input,
                  {
                    name: "ket_biaya",
                    placeholder: "Keterangan",
                    errors: errors.ket_biaya,
                    value: data.ket_biaya,
                    onChange: (e) => setData(
                      "ket_biaya",
                      e.target.value
                    )
                  }
                )
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "flex justify-between gap-2 items-start", children: [
                /* @__PURE__ */ jsx(
                  MoneyInput,
                  {
                    name: "jumlah_biaya",
                    errors: errors.jumlah_biaya,
                    autoComplete: "off",
                    value: data.jumlah_biaya,
                    placeholder: "Jumlah",
                    onValueChange: (e) => setData((prev) => ({
                      ...prev,
                      jumlah_biaya: e.value
                    }))
                  }
                ),
                /* @__PURE__ */ jsx(
                  LoadingButton,
                  {
                    theme: "black",
                    loading: processing,
                    type: "submit",
                    className: "pb-3 text-sm",
                    children: /* @__PURE__ */ jsx("span", { children: "Simpan" })
                  }
                ),
                /* @__PURE__ */ jsx(
                  Button,
                  {
                    disabled: !is_admin,
                    theme: "blueGrey",
                    className: "px-2 py-2 text-sm text-blueGray-500 w-full",
                    onClick: (e) => {
                      e.preventDefault();
                      setShowStatusDialog(
                        true
                      );
                    },
                    children: /* @__PURE__ */ jsx("span", { children: statusKasbon == null ? void 0 : statusKasbon.label })
                  }
                )
              ] })
            ] }),
            /* @__PURE__ */ jsx("div", { className: "w-full flex items-start", children: kasbon.jenis_kasbon === "permohonan" && /* @__PURE__ */ jsx(
              CardPermohonanEditable,
              {
                permohonan: data.permohonan,
                base_route
              }
            ) })
          ] }) }) : /* @__PURE__ */ jsx(
            Button,
            {
              disabled: !is_admin,
              theme: "blueGrey",
              className: "py-2 text-sm text-blueGray-500",
              onClick: (e) => {
                e.preventDefault();
                setShowStatusDialog(true);
              },
              children: /* @__PURE__ */ jsx("span", { children: kasbon.status_kasbon })
            }
          ),
          /* @__PURE__ */ jsx("div", { className: "w-full flex items-start", children: kasbon.jenis_kasbon === "permohonan" ? /* @__PURE__ */ jsx(CardDkasbonList, { kasbon }) : /* @__PURE__ */ jsx(CardDkasbonnopermList, { kasbon }) }),
          /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsx(
              LinkButton,
              {
                theme: "blueGrey",
                href: route(
                  base_route + "transaksi.kasbons.index"
                ),
                children: /* @__PURE__ */ jsx("span", { children: "Kembali" })
              }
            ),
            /* @__PURE__ */ jsx(
              Button,
              {
                disabled: kasbon.jumlah_kasbon == 0,
                theme: "blue",
                onClick: (e) => prosesLaporan(e),
                children: /* @__PURE__ */ jsx("span", { children: "Cetak" })
              }
            )
          ] })
        ] })
      ] }) }),
      /* @__PURE__ */ jsx(
        ModalCetakLaporan,
        {
          showModal: showModalLaporan,
          setShowModal: setShowModalLaporan,
          src: route(
            base_route + "transaksi.kasbons.lap.staf",
            kasbon.id
          )
        }
      ),
      /* @__PURE__ */ jsx(
        ModalAddPermohonan,
        {
          showModal: showModalAddPermohonan,
          setShowModal: setShowModalAddPermohonan,
          setPermohonan,
          src: route(base_route + "permohonans.modal.create")
        }
      )
    ] }),
    showStatusDialog ? /* @__PURE__ */ jsx(
      Modal,
      {
        closeable: true,
        show: showStatusDialog,
        maxWidth: "md",
        onClose: () => setShowStatusDialog(false),
        children: /* @__PURE__ */ jsxs("div", { className: "w-full p-4 flex flex-col gap-2 overflow-y-visible", children: [
          /* @__PURE__ */ jsx("h1", { children: "Update Status Kasbon" }),
          /* @__PURE__ */ jsx(
            SelectSearch,
            {
              placeholder: "Status Kasbon",
              name: "statusKasbon",
              value: statusKasbon,
              options: statuskasbonOpts,
              onChange: (e) => setStatusKasbon(e)
            }
          ),
          /* @__PURE__ */ jsxs("div", { className: "flex justify-end gap-2", children: [
            /* @__PURE__ */ jsx(
              Button,
              {
                theme: "blue",
                onClick: (e) => handleUpdateStatus(e),
                children: /* @__PURE__ */ jsx("span", { children: "Simpan" })
              }
            ),
            /* @__PURE__ */ jsx(
              Button,
              {
                theme: "blueGrey",
                onClick: (e) => setShowStatusDialog(false),
                children: /* @__PURE__ */ jsx("span", { children: "Batal" })
              }
            )
          ] })
        ] })
      }
    ) : null
  ] });
};
export {
  Edit as default
};
