import { jsxs, jsx } from "react/jsx-runtime";
import ReactDatePicker from "react-datepicker";
import { twMerge } from "tailwind-merge";
/* empty css                           */import moment from "moment";
function DateInput(props) {
  return /* @__PURE__ */ jsxs(
    "div",
    {
      className: twMerge(
        "relative w-full text-black flex flex-col ",
        props.className
      ),
      children: [
        props.label && /* @__PURE__ */ jsx(
          "label",
          {
            className: `block uppercase text-blueGray-600 text-sm font-bold ${props.errors ? "text-red-500" : ""} `,
            children: props.label
          }
        ),
        /* @__PURE__ */ jsx(
          ReactDatePicker,
          {
            selected: moment(props.selected).toDate(),
            value: props.customDateFormat ? moment(props.value).format(props.customDateFormat) : moment(props.value).format("DD-MMM-YYYY"),
            showTimeSelect: props.showTimeSelect,
            dateFormat: "DD/MM/yyyy",
            className: "px-3 py-2 placeholder-blueGray-300 rounded text-blueGray-600 border-blueGray-300 bg-white text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150",
            onChange: props.onChange
          }
        ),
        props.errors ? /* @__PURE__ */ jsx("span", { className: "text-sm text-red-500", children: props.errors }) : null
      ]
    }
  );
}
export {
  DateInput as D
};
