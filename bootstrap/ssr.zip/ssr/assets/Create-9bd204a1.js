import { jsxs, jsx } from "react/jsx-runtime";
import { I as Input } from "./Input-72be4948.js";
import { L as LinkButton } from "./LinkButton-a291522b.js";
import { L as LoadingButton } from "./LoadingButton-c9189101.js";
import { useForm, router } from "@inertiajs/react";
import { S as SelectSearch } from "./SelectSearch-22ab8168.js";
import { A as AsyncSelectSearch } from "./AsyncSelectSearch-23c2f5cb.js";
import moment from "moment";
import { S as StafLayout } from "./StafLayout-f28c615d.js";
import { useRef, useState, useEffect } from "react";
import { C as CardPermohonanEditable } from "./CardPermohonanEditable-d1f1f0c5.js";
import { M as ModalAddPermohonan } from "./ModalAddPermohonan-72cf984e.js";
import { usePrevious } from "react-use";
import { pickBy } from "lodash";
import { T as TranspermohonanSelect } from "./TranspermohonanSelect-e6be2ec6.js";
import "tailwind-merge";
import "classnames";
import "react-select";
import "react-select/async";
import "./bootstrap-b9d9b211.js";
import "axios";
import "./NotificationDropdown-abde11b8.js";
import "@popperjs/core";
import "./ResponsiveNavLink-41b4fa07.js";
import "react-hot-toast";
import "./AuthContext-5300e6b5.js";
import "firebase/app";
import "firebase/auth";
import "firebase/firestore";
import "firebase/storage";
import "firebase/messaging";
import "./MenuItem-f3c50e94.js";
import "react-loader-spinner";
import "@headlessui/react";
import "@heroicons/react/20/solid";
import "swr";
import "./ListboxSelect-3ce899e5.js";
import "./Modal-d06b3568.js";
import "@zxing/browser";
import "./useScreenSize-4351026c.js";
const Create = ({
  permohonan_id,
  transpermohonan_id,
  permohonan,
  transpermohonanOpts,
  transpermohonanOpt,
  metodebayarOpts,
  rekeningOpts,
  base_route,
  isAdmin,
  allPermohonan
}) => {
  var _a;
  const { data, setData, errors, post, processing } = useForm({
    itemrincianbiayapermOpt: void 0,
    itemrincianbiayaperm_id: "",
    permohonan,
    jenisitemrincianbiayaOpt: void 0,
    jenis_itemrincianbiaya: "",
    transpermohonan_id,
    total_pemasukan: "0",
    total_pengeluaran: "0",
    sisa_saldo: "0",
    ket_rincianbiayaperm: "",
    user: void 0,
    metodebayarOpt: void 0,
    metodebayar_id: "",
    rekeningOpt: void 0,
    rekening_id: "",
    user_id: "",
    _method: "POST"
  });
  const firstInput = useRef();
  const [showModalAddPermohonan, setShowModalAddPermohonan] = useState(false);
  function handleSubmit(e) {
    e.preventDefault();
    post(route(base_route + "transaksi.rincianbiayaperms.store"));
  }
  const setPermohonan = (permohonan2) => {
    firstInput.current.value = permohonan2 == null ? void 0 : permohonan2.nama_penerima;
    if (permohonan2) {
      setData({
        ...data,
        transpermohonan_id: permohonan2.transpermohonan.id,
        permohonan: permohonan2
      });
      setValues((prev) => ({
        ...prev,
        transpermohonan_id: permohonan2.transpermohonan.id,
        permohonan_id: permohonan2 ? permohonan2.id : ""
      }));
    }
  };
  const [values, setValues] = useState({
    permohonan_id,
    transpermohonan_id
  });
  const prevValues = usePrevious(values);
  useEffect(() => {
    if (prevValues) {
      const query = Object.keys(pickBy(values)).length ? pickBy(values) : {};
      router.get(
        route(route().current() ? route().current() + "" : ""),
        query,
        {
          replace: true,
          preserveState: true
        }
      );
    }
  }, [values]);
  return /* @__PURE__ */ jsxs(StafLayout, { children: [
    /* @__PURE__ */ jsx("div", { className: "flex content-center items-center justify-center relative -top-2", children: /* @__PURE__ */ jsx("div", { className: "w-full lg:w-11/12 px-4", children: /* @__PURE__ */ jsxs("div", { className: "relative flex flex-col min-w-0 break-words w-full mb-2 shadow-lg shadow-slate-400 rounded-lg bg-blueGray-100 border-0", children: [
      /* @__PURE__ */ jsx("div", { className: "rounded-t mb-1 px-4 py-2 ", children: /* @__PURE__ */ jsxs("div", { className: "w-full grid grid-cols-1 md:grid-cols-2 bg-lightBlue-800 text-lightBlue-100 px-2 py-2 shadow-md rounded-lg", children: [
        /* @__PURE__ */ jsx("div", { className: "text-left", children: /* @__PURE__ */ jsx("h6", { className: "font-semibold", children: "RINCIAN BIAYA PERMOHONAN BARU" }) }),
        /* @__PURE__ */ jsx("div", { className: "text-left md:text-right", children: moment(/* @__PURE__ */ new Date()).format(
          "DD MMM YYYY HH:mm"
        ) })
      ] }) }),
      /* @__PURE__ */ jsx("div", { className: "flex-auto px-4 lg:px-10 py-10 pt-0", children: /* @__PURE__ */ jsxs("form", { onSubmit: handleSubmit, children: [
        /* @__PURE__ */ jsxs("div", { className: "w-full grid grid-cols-1 md:grid-cols-2 gap-2", children: [
          /* @__PURE__ */ jsxs("div", { className: "w-full grid grid-cols-1", children: [
            /* @__PURE__ */ jsxs("div", { className: "flex flex-row justify-between items-center", children: [
              /* @__PURE__ */ jsx(
                TranspermohonanSelect,
                {
                  inputRef: firstInput,
                  value: (_a = data.permohonan) == null ? void 0 : _a.transpermohonan,
                  className: "mb-1 w-full mr-2",
                  errors: errors.transpermohonan_id,
                  isDisabledCheck: !allPermohonan,
                  isChecked: false,
                  onValueChange: (e) => {
                    if (e) {
                      setPermohonan(
                        e.permohonan
                      );
                      setValues((prev) => ({
                        ...prev,
                        transpermohonan_id: e.id,
                        permohonan_id: e.permohonan.id
                      }));
                    } else {
                      setValues((prev) => ({
                        ...prev,
                        transpermohonan_id: "",
                        permohonan_id: ""
                      }));
                    }
                  }
                }
              ),
              /* @__PURE__ */ jsx(
                "a",
                {
                  tabIndex: -1,
                  href: "#",
                  className: "w-8 h-8 px-2 py-1 rounded-full bg-blue-600/20 shadow-xl mb-1",
                  onClick: (e) => {
                    e.preventDefault();
                    setShowModalAddPermohonan(
                      true
                    );
                  },
                  children: /* @__PURE__ */ jsx("i", { className: "fas fa-add text-md text-center text-gray-700" })
                }
              )
            ] }),
            /* @__PURE__ */ jsx("div", { className: "flex flex-row items-start w-full gap-2 ", children: isAdmin ? /* @__PURE__ */ jsx(
              AsyncSelectSearch,
              {
                placeholder: "Pilih User",
                value: data.user,
                name: "users",
                url: "/admin/users/api/list/",
                errors: errors.user_id,
                onChange: (e) => setData((v) => ({
                  ...v,
                  user: e,
                  user_id: e ? e.value : ""
                })),
                isClearable: true,
                optionLabels: ["name"],
                optionValue: "id",
                className: "text-blueGray-900"
              }
            ) : null }),
            /* @__PURE__ */ jsx(
              SelectSearch,
              {
                name: "metodebayar_id",
                label: "Metode Bayar",
                className: "mb-2",
                value: data.metodebayarOpt,
                options: metodebayarOpts,
                onChange: (e) => setData({
                  ...data,
                  metodebayarOpt: e ? e : {},
                  metodebayar_id: e ? e.value : ""
                }),
                errors: errors.metodebayar_id
              }
            ),
            /* @__PURE__ */ jsx(
              SelectSearch,
              {
                name: "rekening_id",
                label: "Rekening",
                className: "mb-2",
                value: data.rekeningOpt,
                options: rekeningOpts,
                onChange: (e) => setData({
                  ...data,
                  rekeningOpt: e ? e : {},
                  rekening_id: e ? e.value : ""
                }),
                errors: errors.rekening_id
              }
            ),
            /* @__PURE__ */ jsx(
              Input,
              {
                name: "ket_rincianbiayaperm",
                placeholder: "Keterangan",
                value: data.ket_rincianbiayaperm,
                onChange: (e) => setData(
                  "ket_rincianbiayaperm",
                  e.target.value
                )
              }
            )
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "w-full flex flex-col items-start", children: [
            /* @__PURE__ */ jsx(
              SelectSearch,
              {
                options: transpermohonanOpts,
                value: transpermohonanOpt,
                onChange: (e) => {
                  setData({
                    ...data,
                    transpermohonan_id: e.value
                  });
                  setValues((prev) => ({
                    ...prev,
                    transpermohonan_id: e ? e.value : ""
                  }));
                },
                className: "mb-0",
                placeholder: "Pilih Jenis Permohonan"
              }
            ),
            /* @__PURE__ */ jsx(
              CardPermohonanEditable,
              {
                permohonan,
                base_route,
                setPermohonan
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsx(
            LinkButton,
            {
              theme: "blueGrey",
              href: route(
                base_route + "transaksi.rincianbiayaperms.index"
              ),
              children: /* @__PURE__ */ jsx("span", { children: "Kembali" })
            }
          ),
          /* @__PURE__ */ jsx(
            LoadingButton,
            {
              theme: "black",
              loading: processing,
              type: "submit",
              children: /* @__PURE__ */ jsx("span", { children: "Simpan" })
            }
          )
        ] })
      ] }) })
    ] }) }) }),
    /* @__PURE__ */ jsx(
      ModalAddPermohonan,
      {
        showModal: showModalAddPermohonan,
        setShowModal: setShowModalAddPermohonan,
        setPermohonan,
        src: route(base_route + "permohonans.modal.create")
      }
    )
  ] });
};
export {
  Create as default
};
