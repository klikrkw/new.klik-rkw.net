import { jsx, jsxs } from "react/jsx-runtime";
import { useState, useEffect, Fragment, useRef } from "react";
import { M as Modal } from "./Modal-d06b3568.js";
import { a as apputils } from "./bootstrap-b9d9b211.js";
import { Lightbox } from "react-modal-image";
import { M as ModalCetakLaporan } from "./ModalCetakLaporan-767963a0.js";
import { usePage, useForm } from "@inertiajs/react";
import { B as Button } from "./Button-e2b11bd9.js";
import { Menu, Transition } from "@headlessui/react";
import { Bars3Icon } from "@heroicons/react/20/solid";
import { L as LoadingButton } from "./LoadingButton-c9189101.js";
import { L as LinkButton } from "./LinkButton-a291522b.js";
import { I as Input } from "./Input-72be4948.js";
import { M as MoneyInput } from "./MoneyInput-87a36109.js";
import { u as useSwal } from "./useSwal-5d61a319.js";
import { S as SelectSearch } from "./SelectSearch-22ab8168.js";
import { U as UploadImage } from "./UploadImage-dc2b2f0d.js";
const ModalBayarbiayaperms = ({
  showModal,
  setShowModal,
  biayaperm_id
}) => {
  const [bayarbiayaperms, setBayarbiayaperms] = useState(
    []
  );
  const getBayarbiayaperms = async (biayaperm_id2) => {
    let xlink = `/transaksi/bayarbiayaperms/api/list?biayaperm_id=${biayaperm_id2}`;
    const response = await apputils.backend.get(xlink);
    const data = response.data;
    setBayarbiayaperms(data.data);
  };
  useEffect(() => {
    if (biayaperm_id && showModal) {
      getBayarbiayaperms(biayaperm_id);
    }
  }, [showModal]);
  const [viewImage, setViewImage] = useState(false);
  const [image, setImage] = useState(null);
  return /* @__PURE__ */ jsx(
    Modal,
    {
      show: showModal,
      maxWidth: "2xl",
      closeable: true,
      onClose: () => setShowModal(false),
      children: /* @__PURE__ */ jsxs("div", { className: "p-4 bg-blueGray-100 rounded-md text-xs", children: [
        /* @__PURE__ */ jsxs("div", { className: "w-full absolute right-1 top-1 flex justify-between items-center px-1", children: [
          /* @__PURE__ */ jsx("h1", { className: "text-lg mb-1 font-semibold text-blueGray-500 ml-4", children: "List Pembayaran" }),
          /* @__PURE__ */ jsx(
            "button",
            {
              className: "text-lightBlue-500 background-transparent font-bold uppercase px-0 py-0 text-xl outline-none focus:outline-none mr-1 mb-1 ease-linear transition-all duration-150",
              type: "button",
              onClick: (e) => setShowModal(false),
              children: /* @__PURE__ */ jsx(
                "i",
                {
                  className: "fa fa-times-circle",
                  "aria-hidden": "true"
                }
              )
            }
          )
        ] }),
        /* @__PURE__ */ jsxs("table", { className: "w-full shadow-md bottom-2 mt-5", children: [
          /* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", { className: "border-y-2 font-semibold bg-slate-300", children: [
            /* @__PURE__ */ jsx("td", { className: "px-1 py-2", width: "5%", children: "No" }),
            /* @__PURE__ */ jsx("td", { className: "px-1 py-2", width: "15%", children: "Tanggal" }),
            /* @__PURE__ */ jsx("td", { className: "px-1 py-2", width: "15%", children: "Metode Bayar" }),
            /* @__PURE__ */ jsx("td", { className: "px-1 py-2", width: "10%", children: "Info Rekening" }),
            /* @__PURE__ */ jsx("td", { className: "px-1 py-2", width: "10%", children: "Image" }),
            /* @__PURE__ */ jsx("td", { className: "px-1 py-2", width: "15%", align: "right", children: "Saldo Awal" }),
            /* @__PURE__ */ jsx("td", { className: "px-1 py-2", width: "15%", align: "right", children: "Jumlah Bayar" }),
            /* @__PURE__ */ jsx("td", { className: "px-1 py-2", width: "15%", align: "right", children: "Saldo Akhir" })
          ] }) }),
          /* @__PURE__ */ jsx("tbody", { children: bayarbiayaperms && bayarbiayaperms.map((bayarbiayaperm, idx) => /* @__PURE__ */ jsxs("tr", { children: [
            /* @__PURE__ */ jsx("td", { className: "px-1 py-2", children: idx + 1 }),
            /* @__PURE__ */ jsx("td", { className: "px-1 py-2", children: bayarbiayaperm.tgl_bayarbiayaperm }),
            /* @__PURE__ */ jsx("td", { className: "px-1 py-2", children: bayarbiayaperm.metodebayar.nama_metodebayar }),
            /* @__PURE__ */ jsx("td", { className: "px-1 py-2", children: bayarbiayaperm.info_rekening }),
            /* @__PURE__ */ jsx("td", { className: "px-1 py-2", children: bayarbiayaperm.image_bayarbiayaperm && /* @__PURE__ */ jsx(
              "button",
              {
                onClick: () => {
                  setImage(
                    bayarbiayaperm.image_bayarbiayaperm
                  );
                  setViewImage(true);
                },
                children: /* @__PURE__ */ jsx(
                  "i",
                  {
                    className: "fas fa-image mr-2 text-sm cursor-pointer"
                  }
                )
              }
            ) }),
            /* @__PURE__ */ jsx("td", { className: "px-1 py-2", align: "right", children: bayarbiayaperm.saldo_awal }),
            /* @__PURE__ */ jsx("td", { className: "px-1 py-2", align: "right", children: bayarbiayaperm.jumlah_bayar }),
            /* @__PURE__ */ jsx("td", { className: "px-1 py-2", align: "right", children: bayarbiayaperm.saldo_akhir })
          ] }, bayarbiayaperm.id)) })
        ] }),
        viewImage && /* @__PURE__ */ jsx("div", { className: "h-56 p-2", children: /* @__PURE__ */ jsx(
          Lightbox,
          {
            small: image ? image : "",
            medium: image ? image : "",
            large: image ? image : "",
            alt: "View Image",
            onClose: () => setViewImage(false)
          }
        ) })
      ] })
    }
  );
};
const ModalRincianbiayaperms = ({
  showModal,
  setShowModal,
  biayaperm_id
}) => {
  usePage().props;
  const [rincianbiayaperms, setRincianbiayaperms] = useState([]);
  const [showModalLaporan, setShowModalLaporan] = useState(false);
  const getRincianbiayaperms = async (biayaperm_id2) => {
    let xlink = `/transaksi/rincianbiayaperms/api/list?biayaperm_id=${biayaperm_id2}`;
    const response = await apputils.backend.get(xlink);
    const data = response.data;
    setRincianbiayaperms(data);
  };
  useEffect(() => {
    if (biayaperm_id && showModal) {
      getRincianbiayaperms(biayaperm_id);
    }
  }, [showModal]);
  return /* @__PURE__ */ jsx(
    Modal,
    {
      show: showModal,
      maxWidth: "2xl",
      closeable: true,
      onClose: () => setShowModal(false),
      children: /* @__PURE__ */ jsxs("div", { className: "p-4 bg-blueGray-100 rounded-md text-xs", children: [
        /* @__PURE__ */ jsxs("div", { className: "w-full absolute right-1 top-1 flex justify-between items-center px-1", children: [
          /* @__PURE__ */ jsx("h1", { className: "text-lg mb-1 font-semibold text-blueGray-500 ml-4", children: "RINCIAN BIAYA PERMOHONAN" }),
          /* @__PURE__ */ jsx(
            "button",
            {
              className: "text-lightBlue-500 background-transparent font-bold uppercase px-0 py-0 text-xl outline-none focus:outline-none mr-1 mb-1 ease-linear transition-all duration-150",
              type: "button",
              onClick: (e) => setShowModal(false),
              children: /* @__PURE__ */ jsx(
                "i",
                {
                  className: "fa fa-times-circle",
                  "aria-hidden": "true"
                }
              )
            }
          )
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "w-full mt-6 flex flex-col", children: [
          rincianbiayaperms.length === 0 && /* @__PURE__ */ jsx("div", { className: "w-full justify-center flex m-auto items-center h-80 p-4", children: /* @__PURE__ */ jsx("div", { className: "font-bold text-lg text-blue-500", children: "RINCIAN BIAYA TIDAK DIKETEMUKAN" }) }),
          rincianbiayaperms && rincianbiayaperms.map(
            (rincianbiayaperm, index) => /* @__PURE__ */ jsxs("div", { className: "w-full flex flex-col", children: [
              /* @__PURE__ */ jsx("ul", { className: "list-none container-snap max-h-56 overflow-x-hidden", children: /* @__PURE__ */ jsxs("li", { className: "flex uppercase gap-1 flex-row w-full items-center rounded-t-md text-xs border justify-start bg-lightBlue-600 border-blueGray-400 px-2 py-2  text-lightBlue-50 font-semibold", children: [
                /* @__PURE__ */ jsx("div", { className: "w-[5%]", children: "No" }),
                /* @__PURE__ */ jsx("div", { className: "w-[35%] md:w-[35%]", children: "Nama Kegiatan" }),
                /* @__PURE__ */ jsx("div", { className: "hidden md:block w-[40%]", children: "Keterangan" }),
                /* @__PURE__ */ jsx("div", { className: "w-[15%] text-right pr-2", children: "Jumlah" })
              ] }) }),
              /* @__PURE__ */ jsx("ul", { className: "list-none container-snap max-h-80 overflow-x-hidden rounded-b-md shadow-md", children: /* @__PURE__ */ jsx("li", { className: "w-full flex flex-col overflow-hidden bg-lightBlue-200", children: /* @__PURE__ */ jsxs("div", { className: "flex w-full gap-1 text-sm text-bold px-2 py-1 items-center justify-start text-lightBlue-900 border-b-2 border-lightBlue-200", children: [
                rincianbiayaperm.id,
                " -",
                " ",
                rincianbiayaperm.tgl_rincianbiayaperm
              ] }) }) }),
              /* @__PURE__ */ jsx("ul", { className: "list-none container-snap max-h-80 overflow-x-hidden rounded-b-md shadow-md", children: /* @__PURE__ */ jsx("li", { className: "w-full flex flex-col overflow-hidden bg-lightBlue-200", children: /* @__PURE__ */ jsx("div", { className: "flex w-full gap-1 text-sm text-bold px-2 py-1 items-center justify-start text-lightBlue-900 border-b-2 border-lightBlue-200", children: "PEMASUKAN" }) }) }),
              /* @__PURE__ */ jsx("ul", { className: "list-none container-snap max-h-80 overflow-x-hidden rounded-b-md shadow-md", children: rincianbiayaperm && rincianbiayaperm.drincianbiayaperms.map(
                (item, index2) => {
                  if (item.itemrincianbiayaperm.jenis_itemrincianbiayaperm === "pemasukan") {
                    return /* @__PURE__ */ jsx(
                      "li",
                      {
                        className: "w-full flex flex-col overflow-hidden bg-lightBlue-300 justify-center",
                        children: /* @__PURE__ */ jsxs("div", { className: "flex w-full gap-1 text-xs px-2 py-1 items-center justify-start text-lightBlue-900 border-b-2 border-lightBlue-200", children: [
                          /* @__PURE__ */ jsxs("div", { className: "pb-0 w-[5%]", children: [
                            index2 + 1,
                            "."
                          ] }),
                          /* @__PURE__ */ jsx("div", { className: "pb-0 w-[35%] md:w-[35%]", children: item.itemrincianbiayaperm.nama_itemrincianbiayaperm }),
                          /* @__PURE__ */ jsx("div", { className: "pb-0 hidden md:block md:w-[40%]", children: item.ket_biaya }),
                          /* @__PURE__ */ jsx("div", { className: "pb-0 w-[15%] text-right pr-2", children: item.jumlah_biaya })
                        ] })
                      },
                      item.id
                    );
                  }
                }
              ) }),
              /* @__PURE__ */ jsx("ul", { className: "list-none container-snap max-h-80 overflow-x-hidden rounded-b-md shadow-md", children: /* @__PURE__ */ jsxs("li", { className: "w-full flex flex-col overflow-hidden bg-lightBlue-200", children: [
                /* @__PURE__ */ jsx("div", { className: "flex w-full gap-1 text-sm text-bold px-2 py-1 items-center justify-start text-lightBlue-900 border-b-2 border-lightBlue-200", children: "PENGELUARAN" }),
                /* @__PURE__ */ jsx("div", { className: "absolute right-1 top-10", children: /* @__PURE__ */ jsx(
                  Button,
                  {
                    className: "shadow-lg shadow-gray-500 border-white border-2",
                    theme: "blue",
                    onClick: (e) => {
                      e.preventDefault();
                      setShowModalLaporan(
                        true
                      );
                    },
                    children: /* @__PURE__ */ jsx("i", { className: "fas fa-print" })
                  }
                ) })
              ] }) }),
              /* @__PURE__ */ jsx("ul", { className: "list-none container-snap max-h-80 overflow-x-hidden rounded-b-md shadow-md", children: rincianbiayaperm && rincianbiayaperm.drincianbiayaperms.map(
                (item, index2) => {
                  if (item.itemrincianbiayaperm.jenis_itemrincianbiayaperm === "pengeluaran") {
                    return /* @__PURE__ */ jsx(
                      "li",
                      {
                        className: "w-full flex flex-col overflow-hidden bg-lightBlue-300",
                        children: /* @__PURE__ */ jsxs("div", { className: "flex w-full gap-1 text-xs px-2 py-1 items-center justify-start text-lightBlue-900 border-b-2 border-lightBlue-200", children: [
                          /* @__PURE__ */ jsxs("div", { className: "pb-0 w-[5%]", children: [
                            index2 + 1,
                            "."
                          ] }),
                          /* @__PURE__ */ jsx("div", { className: "pb-0 w-[35%] md:w-[35%]", children: item.itemrincianbiayaperm.nama_itemrincianbiayaperm }),
                          /* @__PURE__ */ jsx("div", { className: "pb-0 hidden md:block md:w-[40%]", children: item.ket_biaya }),
                          /* @__PURE__ */ jsx("div", { className: "pb-0 w-[15%] text-right pr-2", children: item.jumlah_biaya })
                        ] })
                      },
                      item.id
                    );
                  }
                }
              ) }),
              /* @__PURE__ */ jsx("ul", { className: "list-none container-snap max-h-80 overflow-x-hidden rounded-b-md shadow-md", children: /* @__PURE__ */ jsx("li", { className: "w-full flex flex-col overflow-hidden bg-lightBlue-200", children: /* @__PURE__ */ jsx("div", { className: "flex w-full gap-1 text-sm text-bold px-2 py-1 items-center justify-start text-lightBlue-900 border-b-2 border-lightBlue-200", children: "PIUTANG" }) }) }),
              /* @__PURE__ */ jsx("ul", { className: "list-none container-snap max-h-80 overflow-x-hidden rounded-b-md shadow-md", children: rincianbiayaperm && rincianbiayaperm.drincianbiayaperms.map(
                (item, index2) => {
                  if (item.itemrincianbiayaperm.jenis_itemrincianbiayaperm === "piutang") {
                    return /* @__PURE__ */ jsx(
                      "li",
                      {
                        className: "w-full flex flex-col overflow-hidden bg-lightBlue-300",
                        children: /* @__PURE__ */ jsxs("div", { className: "flex w-full gap-1 text-xs px-2 py-1 items-center justify-start text-lightBlue-900 border-b-2 border-lightBlue-200", children: [
                          /* @__PURE__ */ jsxs("div", { className: "pb-0 w-[5%]", children: [
                            index2 + 1,
                            "."
                          ] }),
                          /* @__PURE__ */ jsx("div", { className: "pb-0 w-[35%] md:w-[35%]", children: item.itemrincianbiayaperm.nama_itemrincianbiayaperm }),
                          /* @__PURE__ */ jsx("div", { className: "pb-0 hidden md:block md:w-[40%]", children: item.ket_biaya }),
                          /* @__PURE__ */ jsx("div", { className: "pb-0 w-[15%] text-right pr-2", children: item.jumlah_biaya })
                        ] })
                      },
                      item.id
                    );
                  }
                }
              ) }),
              /* @__PURE__ */ jsx("ul", { className: "list-none container-snap max-h-80 overflow-x-hidden rounded-b-md shadow-md", children: /* @__PURE__ */ jsxs("li", { className: "w-full flex flex-col overflow-hidden bg-lightBlue-600 px-2 py-1  font-semibold text-lightBlue-50", children: [
                /* @__PURE__ */ jsxs("div", { className: "flex w-full gap-1 text-xs px-2 py-1 items-center justify-start border-b-2 border-lightBlue-500", children: [
                  /* @__PURE__ */ jsx("div", { className: "w-[60%]" }),
                  /* @__PURE__ */ jsx("div", { className: "hidden md:block md:w-[20%] text-right", children: "Total Pemasukan" }),
                  /* @__PURE__ */ jsx("div", { className: "w-[15%] text-right", children: rincianbiayaperm.total_pemasukan })
                ] }),
                /* @__PURE__ */ jsxs("div", { className: "flex w-full gap-1 text-xs px-2 py-1 items-center justify-start border-b-2 border-lightBlue-500", children: [
                  /* @__PURE__ */ jsx("div", { className: "w-[60%]" }),
                  /* @__PURE__ */ jsx("div", { className: "hidden md:block md:w-[20%] text-right", children: "Total Pengeluaran" }),
                  /* @__PURE__ */ jsx("div", { className: "w-[15%] text-right", children: rincianbiayaperm.total_pengeluaran })
                ] }),
                /* @__PURE__ */ jsxs("div", { className: "flex w-full gap-1 text-xs px-2 py-1 items-center justify-start border-b-2 border-lightBlue-500", children: [
                  /* @__PURE__ */ jsx("div", { className: "w-[60%]" }),
                  /* @__PURE__ */ jsx("div", { className: "hidden md:block md:w-[20%] text-right", children: "Total Piutang" }),
                  /* @__PURE__ */ jsx("div", { className: "w-[15%] text-right", children: rincianbiayaperm.total_piutang })
                ] }),
                /* @__PURE__ */ jsxs("div", { className: "flex w-full gap-1 text-xs px-2 py-1 items-center justify-start border-b-2 border-lightBlue-500", children: [
                  /* @__PURE__ */ jsx("div", { className: "w-[60%]" }),
                  /* @__PURE__ */ jsx("div", { className: "hidden md:block md:w-[20%] text-right", children: "Total Bayar" }),
                  /* @__PURE__ */ jsx("div", { className: "w-[15%] text-right", children: rincianbiayaperm.sisa_saldo })
                ] })
              ] }) }),
              /* @__PURE__ */ jsx(
                ModalCetakLaporan,
                {
                  showModal: showModalLaporan,
                  setShowModal: setShowModalLaporan,
                  src: route(
                    "lap.rincianbiayaperms.staf",
                    rincianbiayaperm.id
                  )
                }
              )
            ] })
          )
        ] })
      ] })
    }
  );
};
function DropdownMenu({ children, title }) {
  return /* @__PURE__ */ jsxs(Menu, { as: "div", className: "relative inline-block text-left", children: [
    /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx(Menu.Button, { className: "inline-flex w-full justify-center rounded-md bg-black/20 px-1 py-1 text-sm font-medium text-white hover:bg-black/30 focus:outline-none focus-visible:ring-2 focus-visible:ring-white/75", children: title ? /* @__PURE__ */ jsx("span", { children: title }) : /* @__PURE__ */ jsx(
      Bars3Icon,
      {
        className: "m-auto h-5 w-5 text-violet-200 hover:text-violet-100",
        "aria-hidden": "true"
      }
    ) }) }),
    /* @__PURE__ */ jsx(
      Transition,
      {
        as: Fragment,
        enter: "transition ease-out duration-100",
        enterFrom: "transform opacity-0 scale-95",
        enterTo: "transform opacity-100 scale-100",
        leave: "transition ease-in duration-75",
        leaveFrom: "transform opacity-100 scale-100",
        leaveTo: "transform opacity-0 scale-95",
        children: /* @__PURE__ */ jsx(Menu.Items, { className: "absolute z-50 right-0 mt-2 w-56 origin-top-right divide-y divide-gray-100 rounded-md bg-white shadow-lg ring-1 ring-black/5 focus:outline-none", children: /* @__PURE__ */ jsx("div", { className: "px-1 py-1", children }) })
      }
    )
  ] });
}
const ModalKeluarBiayaperm = ({
  showModal,
  setShowModal,
  transpermohonan
}) => {
  const { rekenings, metodebayars, itemkegiatansOpts, instansiOpts } = usePage().props;
  const { data, setData, errors, post, processing, reset } = useForm({
    transpermohonan_id: transpermohonan.id || "",
    jumlah_keluarbiayaperm: "",
    itemkegiatan_id: "",
    itemkegiatan: void 0,
    akun: void 0,
    akun_id: "",
    metodebayar: metodebayars.length > 0 ? metodebayars[0] : void 0,
    rekening_id: rekenings.length > 0 ? rekenings[0].value : "",
    rekening: rekenings.length > 0 ? rekenings[0] : void 0,
    metodebayar_id: metodebayars.length > 0 ? metodebayars[0].value : "",
    catatan_keluarbiayaperm: "",
    instansi: void 0,
    instansiOpt: instansiOpts.length > 0 ? instansiOpts[0] : void 0,
    instansi_id: instansiOpts.length > 0 ? instansiOpts[0].value : "",
    image_dkeluarbiayapermuser: "",
    _method: "POST"
  });
  function handleSubmit(e) {
    e.preventDefault();
    useSwal.confirm({
      title: "Simpan Data",
      text: "apakah akan menyimpan?"
    }).then((result) => {
      if (result.isConfirmed) {
        post(route("transaksi.keluarbiayaperms.store"), {
          onSuccess: () => {
            setShowModal(false);
          }
        });
      }
    });
  }
  useRef();
  useEffect(() => {
    setData((prev) => ({
      ...prev,
      transpermohonan_id: transpermohonan.id || "",
      jumlah_keluarbiayaperm: "0",
      metodebayar_id: metodebayars.length > 0 ? metodebayars[0].value : "",
      metodebayar: metodebayars.length > 0 ? metodebayars[0] : void 0,
      catatan_keluarbiayaperm: "",
      image_keluarbiayaperm: ""
    }));
  }, [transpermohonan]);
  const [imageUpload, setImageUpload] = useState(null);
  useState();
  useEffect(() => {
    setData("transpermohonan_id", transpermohonan.id);
    return () => {
      reset();
      setImageUpload(null);
    };
  }, [showModal]);
  return /* @__PURE__ */ jsx(
    Modal,
    {
      show: showModal,
      maxWidth: "md",
      closeable: false,
      onClose: () => setShowModal(false),
      children: /* @__PURE__ */ jsx("div", { className: "p-4 bg-blueGray-100 rounded-md", children: /* @__PURE__ */ jsxs("form", { onSubmit: handleSubmit, children: [
        /* @__PURE__ */ jsx("h1", { className: "font-bold text-xl text-blueGray-700 mb-4", children: "PENGELUARAN BIAYA" }),
        /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 gap-1", children: [
          /* @__PURE__ */ jsx(
            SelectSearch,
            {
              name: "metodebayar",
              options: metodebayars,
              onChange: (e) => setData((prev) => ({
                ...prev,
                metodebayar: e ? e : void 0,
                metodebayar_id: e ? e.value : ""
              })),
              label: "Metode Pembayaran",
              value: data.metodebayar,
              errors: errors.metodebayar_id
            }
          ),
          /* @__PURE__ */ jsx(
            SelectSearch,
            {
              name: "rekening",
              options: rekenings,
              onChange: (e) => setData((prev) => ({
                ...prev,
                rekening: e ? e : void 0,
                rekening_id: e ? e.value : ""
              })),
              label: "Rekening",
              value: data.rekening,
              errors: errors.rekening_id
            }
          )
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 gap-1", children: [
          /* @__PURE__ */ jsx(
            SelectSearch,
            {
              name: "instansi_id",
              label: "Instansi",
              value: data.instansiOpt,
              options: instansiOpts,
              onChange: (e) => setData({
                ...data,
                instansiOpt: e ? e : {},
                instansi_id: e ? e.value : ""
              }),
              errors: errors.instansi_id
            }
          ),
          /* @__PURE__ */ jsx(
            SelectSearch,
            {
              name: "itemkegiatan",
              options: itemkegiatansOpts,
              onChange: (e) => setData((prev) => ({
                ...prev,
                itemkegiatan: e ? e : void 0,
                itemkegiatan_id: e ? e.value : ""
              })),
              label: "Item Kegiatan",
              value: data.itemkegiatan,
              errors: errors.itemkegiatan_id
            }
          )
        ] }),
        /* @__PURE__ */ jsx(
          MoneyInput,
          {
            name: "jumlah_keluarbiayaperm",
            label: "Jumlah Bayar",
            errors: errors.jumlah_keluarbiayaperm,
            value: data.jumlah_keluarbiayaperm,
            onValueChange: (e) => {
              setData("jumlah_keluarbiayaperm", e.value);
            }
          }
        ),
        /* @__PURE__ */ jsx(
          Input,
          {
            name: "catatan_keluarbiayaperm",
            label: "Catatan",
            errors: errors.catatan_keluarbiayaperm,
            value: data.catatan_keluarbiayaperm,
            onChange: (e) => setData("catatan_keluarbiayaperm", e.target.value)
          }
        ),
        /* @__PURE__ */ jsx(
          UploadImage,
          {
            name: "image_dkeluarbiaya",
            image: data.image_dkeluarbiayapermuser,
            imagePath: "/images/dkeluarbiayapermusers/",
            setImage: (imgfile) => setData("image_dkeluarbiayapermuser", imgfile)
          }
        ),
        /* @__PURE__ */ jsxs("div", { className: "mt-4 w-full flex justify-between items-center", children: [
          /* @__PURE__ */ jsx(
            LoadingButton,
            {
              theme: "black",
              loading: processing,
              type: "submit",
              children: /* @__PURE__ */ jsx("span", { children: "Simpan" })
            }
          ),
          /* @__PURE__ */ jsx(
            LinkButton,
            {
              href: "#",
              theme: "blue",
              onClick: (e) => {
                e.preventDefault();
                setShowModal(false);
              },
              children: /* @__PURE__ */ jsx("span", { children: "Close" })
            }
          )
        ] })
      ] }) })
    }
  );
};
const ModalAddBiayaperm = ({
  showModal,
  setShowModal,
  transpermohonan_id
}) => {
  const [imageUpload, setImageUpload] = useState(null);
  const { transpermohonan, rincianbiayapermOpts } = usePage().props;
  const [xrincianbiayapermOpts, setXrincianbiayapermOpts] = useState(rincianbiayapermOpts);
  const getRincianbiayapermOpts = async (transpermohonan_id2) => {
    let xlink = `/transaksi/biayaperms/${transpermohonan_id2}/api/rincianbiayapermopts`;
    const response = await apputils.backend.get(xlink);
    const data2 = response.data;
    setXrincianbiayapermOpts(data2);
  };
  const { data, setData, errors, post, processing, reset, progress } = useForm({
    transpermohonan_id: "",
    jumlah_biayaperm: 0,
    jumlah_bayar: 0,
    kurang_bayar: 0,
    catatan_biayaperm: "",
    image_biayaperm: "",
    rincianbiayapermOpt: void 0,
    rincianbiayaperm_id: "",
    _method: "POST"
  });
  function handleSubmit(e) {
    e.preventDefault();
    useSwal.confirm({
      title: "Simpan Data",
      text: "apakah akan menyimpan ?"
    }).then((result) => {
      if (result.isConfirmed) {
        post(route("transaksi.biayaperms.store"), {
          onSuccess: () => {
            setShowModal(false);
          }
        });
      }
    });
  }
  const getKurangBayar = (jmlBiaya, jmlBayar) => {
    let xkurang = jmlBiaya > jmlBayar ? jmlBiaya - jmlBayar : 0;
    return xkurang;
  };
  useEffect(() => {
    setData("transpermohonan_id", transpermohonan_id);
    if (showModal && transpermohonan_id) {
      getRincianbiayapermOpts(transpermohonan_id);
    }
    if (!showModal) {
      setImageUpload(null);
      reset();
    }
  }, [showModal]);
  return /* @__PURE__ */ jsx(
    Modal,
    {
      show: showModal,
      maxWidth: "md",
      closeable: false,
      onClose: () => setShowModal(false),
      children: /* @__PURE__ */ jsx("div", { className: "p-4 bg-blueGray-100 rounded-md", children: /* @__PURE__ */ jsxs("form", { onSubmit: handleSubmit, children: [
        /* @__PURE__ */ jsxs("div", { className: "flex justify-between items-start", children: [
          /* @__PURE__ */ jsx("h1", { className: "font-bold text-xl text-blueGray-700 mb-4", children: "BIAYA PERMOHONAN BARU" }),
          /* @__PURE__ */ jsx("div", { className: "font-bold text-blueGray-500 text-sm", children: data.transpermohonan_id })
        ] }),
        /* @__PURE__ */ jsx(
          SelectSearch,
          {
            name: "rincianbiayaperm_id",
            label: "Rincian Biaya",
            value: data.rincianbiayapermOpt,
            options: xrincianbiayapermOpts,
            onChange: (e) => {
              setData({
                ...data,
                rincianbiayapermOpt: e ? e : {},
                rincianbiayaperm_id: e ? e.value : "",
                jumlah_biayaperm: e.rincianbiayaperm.total_pemasukan,
                jumlah_bayar: parseInt(
                  e.rincianbiayaperm.total_pemasukan
                ) - parseInt(
                  e.rincianbiayaperm.total_pengeluaran
                )
              });
            },
            errors: errors.rincianbiayaperm_id
          }
        ),
        /* @__PURE__ */ jsx(
          MoneyInput,
          {
            name: "jumlah_biayaperm",
            label: "Jumlah Biaya",
            disabled: data.rincianbiayapermOpt ? true : false,
            errors: errors.jumlah_biayaperm,
            autoComplete: "off",
            value: data.jumlah_biayaperm,
            onValueChange: (e) => setData((prev) => ({
              ...prev,
              jumlah_biayaperm: parseInt(e.value),
              kurang_bayar: getKurangBayar(
                parseInt(e.value),
                data.jumlah_bayar
              )
            }))
          }
        ),
        /* @__PURE__ */ jsx(
          MoneyInput,
          {
            disabled: true,
            name: "jumlah_bayar",
            label: "Jumlah Bayar",
            errors: errors.jumlah_bayar,
            autoComplete: "off",
            value: data.jumlah_bayar,
            onValueChange: (e) => setData((prev) => ({
              ...prev,
              jumlah_bayar: parseInt(e.value),
              kurang_bayar: getKurangBayar(
                data.jumlah_biayaperm,
                parseInt(e.value)
              )
            }))
          }
        ),
        /* @__PURE__ */ jsx(
          MoneyInput,
          {
            name: "kurang_bayar",
            label: "Kurang Bayar",
            disabled: true,
            errors: errors.kurang_bayar,
            value: data.kurang_bayar,
            onValueChange: (e) => {
              setData("kurang_bayar", parseInt(e.value));
            }
          }
        ),
        /* @__PURE__ */ jsx(
          Input,
          {
            name: "catatan_biayaperm",
            label: "Catatan",
            errors: errors.catatan_biayaperm,
            value: data.catatan_biayaperm,
            onChange: (e) => setData("catatan_biayaperm", e.target.value)
          }
        ),
        /* @__PURE__ */ jsx(
          UploadImage,
          {
            name: "image_biayaperm",
            image: data.image_biayaperm,
            imagePath: "/images/dkeluarbiayapermusers/",
            setImage: (imgfile) => setData("image_biayaperm", imgfile)
          }
        ),
        /* @__PURE__ */ jsxs("div", { className: "mt-4 w-full flex justify-between items-center", children: [
          /* @__PURE__ */ jsx(
            LoadingButton,
            {
              theme: "black",
              loading: processing,
              type: "submit",
              children: /* @__PURE__ */ jsx("span", { children: "Simpan" })
            }
          ),
          /* @__PURE__ */ jsx(
            LinkButton,
            {
              href: "#",
              theme: "blue",
              onClick: (e) => {
                e.preventDefault();
                setShowModal(false);
              },
              children: /* @__PURE__ */ jsx("span", { children: "Close" })
            }
          )
        ] })
      ] }) })
    }
  );
};
export {
  DropdownMenu as D,
  ModalBayarbiayaperms as M,
  ModalRincianbiayaperms as a,
  ModalKeluarBiayaperm as b,
  ModalAddBiayaperm as c
};
