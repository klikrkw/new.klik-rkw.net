import { jsx } from "react/jsx-runtime";
const ModalAddbiaya = () => {
  return /* @__PURE__ */ jsx("div", { children: "ModalAddbiaya" });
};
export {
  ModalAddbiaya as default
};
