import { jsxs, jsx, Fragment } from "react/jsx-runtime";
import { C as CardPermohonanEditable } from "./CardPermohonanEditable-d1f1f0c5.js";
import { M as ModalAddPermohonan } from "./ModalAddPermohonan-72cf984e.js";
import { M as ModalCetakLaporan } from "./ModalCetakLaporan-767963a0.js";
import { P as PrintDialog } from "./PrintDialog-e8e99716.js";
import { B as Button } from "./Button-e2b11bd9.js";
import { T as TranspermohonanSelect } from "./TranspermohonanSelect-e6be2ec6.js";
import { S as StafLayout } from "./StafLayout-f28c615d.js";
import { usePage, router } from "@inertiajs/react";
import { pickBy } from "lodash";
import { lazy, useState, useEffect, useRef } from "react";
import { usePrevious } from "react-use";
import "./bootstrap-b9d9b211.js";
import "axios";
import "react-loader-spinner";
import "@headlessui/react";
import "./Modal-d06b3568.js";
import "react-dom";
import "@emotion/react";
import "@emotion/cache";
import "tailwind-merge";
import "@heroicons/react/20/solid";
import "swr";
import "./ListboxSelect-3ce899e5.js";
import "./LinkButton-a291522b.js";
import "@zxing/browser";
import "./useScreenSize-4351026c.js";
import "./NotificationDropdown-abde11b8.js";
import "@popperjs/core";
import "./ResponsiveNavLink-41b4fa07.js";
import "react-hot-toast";
import "./AuthContext-5300e6b5.js";
import "firebase/app";
import "firebase/auth";
import "firebase/firestore";
import "firebase/storage";
import "firebase/messaging";
import "./MenuItem-f3c50e94.js";
lazy(
  () => import("./CardPermohonan-c73242e8.js")
);
const Create = () => {
  const { transpermohonan, base_route } = usePage().props;
  const [ctranspermohonan, setCtranspermohonan] = useState(transpermohonan);
  const setPermohonan = (permohonan) => {
    if (permohonan) {
      setValues((prev) => ({
        ...prev,
        transpermohonan_id: permohonan.transpermohonan.id,
        permohonan_id: permohonan.id
      }));
    }
  };
  const params = new URLSearchParams(window.location.search);
  const [values2, setValues] = useState({
    transpermohonan_id: params.get("transpermohonan_id"),
    permohonan_id: params.get("permohonan_id")
  });
  const [showModalAddPermohonan, setShowModalAddPermohonan] = useState(false);
  const [showModalLaporan, setShowModalLaporan] = useState(false);
  const [showModalPrint, setShowModalPrint] = useState(false);
  const [showModalLabelberkas, setShowModalLabelberkas] = useState(false);
  const [printData, setPrintData] = useState({
    row: "1",
    col: "1"
  });
  const prevValues = usePrevious(values2);
  useEffect(() => {
    if (prevValues) {
      const query = Object.keys(pickBy(values2)).length ? pickBy(values2) : {};
      router.get(
        route(route().current() ? route().current() + "" : ""),
        query,
        {
          replace: true,
          preserveState: true
        }
      );
    }
  }, [values2]);
  const firstInput = useRef();
  return /* @__PURE__ */ jsxs(StafLayout, { children: [
    /* @__PURE__ */ jsx("div", { className: "flex content-center items-center justify-center h-full", children: /* @__PURE__ */ jsx("div", { className: "w-full lg:w-2/3 px-4", children: /* @__PURE__ */ jsxs("div", { className: "relative flex flex-col min-w-0 break-words w-full mb-2 shadow-lg shadow-slate-400 rounded-lg bg-blueGray-200 border-0", children: [
      /* @__PURE__ */ jsx("div", { className: "rounded-t mt-2 px-4", children: /* @__PURE__ */ jsx("div", { className: "text-center", children: /* @__PURE__ */ jsx("h6", { className: "text-blueGray-500 text-lg font-bold", children: "CETAK LABEL BERKAS DAN QR CODE" }) }) }),
      /* @__PURE__ */ jsxs("div", { className: "flex-auto p-4", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex flex-row justify-between items-center", children: [
          /* @__PURE__ */ jsx(
            TranspermohonanSelect,
            {
              inputRef: firstInput,
              value: ctranspermohonan,
              className: "mb-1 w-full mr-2",
              onValueChange: (e) => {
                setPermohonan(e == null ? void 0 : e.permohonan);
              },
              isChecked: false
            }
          ),
          /* @__PURE__ */ jsx(
            "a",
            {
              tabIndex: -1,
              href: "#",
              className: "w-8 h-8 px-2 py-1 rounded-full bg-blue-600/20 shadow-xl mb-1",
              onClick: (e) => {
                e.preventDefault();
                setShowModalAddPermohonan(true);
              },
              children: /* @__PURE__ */ jsx("i", { className: "fas fa-add text-md text-center text-gray-700" })
            }
          )
        ] }),
        transpermohonan && transpermohonan.permohonan ? /* @__PURE__ */ jsxs(Fragment, { children: [
          /* @__PURE__ */ jsx(
            CardPermohonanEditable,
            {
              permohonan: transpermohonan.permohonan,
              base_route,
              setPermohonan
            }
          ),
          /* @__PURE__ */ jsx(
            Button,
            {
              theme: "black",
              onClick: (e) => setShowModalPrint(true),
              children: /* @__PURE__ */ jsx("span", { children: "Cetak Qrcode" })
            }
          ),
          /* @__PURE__ */ jsx(
            Button,
            {
              theme: "black",
              onClick: (e) => setShowModalLabelberkas(true),
              children: /* @__PURE__ */ jsx("span", { children: "Cetak Label Berkas" })
            }
          )
        ] }) : null
      ] })
    ] }) }) }),
    /* @__PURE__ */ jsx(
      ModalAddPermohonan,
      {
        showModal: showModalAddPermohonan,
        setShowModal: setShowModalAddPermohonan,
        setPermohonan,
        src: route(base_route + "permohonans.modal.create")
      }
    ),
    /* @__PURE__ */ jsx(
      PrintDialog,
      {
        showModal: showModalPrint,
        setShowModal: (e) => setShowModalPrint(e),
        onCommit: (e) => {
          setPrintData(e);
          setShowModalPrint(false);
          setShowModalLaporan(true);
        }
      }
    ),
    /* @__PURE__ */ jsx(
      ModalCetakLaporan,
      {
        showModal: showModalLaporan,
        setShowModal: setShowModalLaporan,
        src: route(base_route + "permohonans.qrcode.cetak", {
          transpermohonan: transpermohonan && transpermohonan.permohonan ? transpermohonan.id : "",
          row: printData.row,
          col: printData.col
        })
      }
    ),
    /* @__PURE__ */ jsx(
      ModalCetakLaporan,
      {
        showModal: showModalLabelberkas,
        setShowModal: setShowModalLabelberkas,
        src: route(
          base_route + "permohonans.labelberkas.cetak",
          transpermohonan && transpermohonan.permohonan ? transpermohonan.id : ""
        )
      }
    )
  ] });
};
export {
  Create as default
};
