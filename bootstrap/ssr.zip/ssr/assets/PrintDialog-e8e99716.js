import { jsxs, jsx } from "react/jsx-runtime";
import { useState } from "react";
import { M as Modal } from "./Modal-d06b3568.js";
import { B as Button } from "./Button-e2b11bd9.js";
import { twMerge } from "tailwind-merge";
const SelectInput = ({
  label = "",
  name = "",
  className = "",
  children = null,
  errors = [],
  ...props
}) => {
  return /* @__PURE__ */ jsxs("div", { className: twMerge("relative w-full mb-3", className), children: [
    label && /* @__PURE__ */ jsxs("label", { className: "form-label", htmlFor: name, children: [
      label,
      ":"
    ] }),
    /* @__PURE__ */ jsx(
      "select",
      {
        id: name,
        name,
        ...props,
        className: `border-0 px-3 py-2 disabled:bg-blueGray-200 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150  ${errors.length ? "error" : ""}`,
        children
      }
    ),
    errors && /* @__PURE__ */ jsx("div", { className: "form-error", children: errors })
  ] });
};
const PrintDialog = ({ showModal, setShowModal, onCommit }) => {
  const [formData, setFormData] = useState({
    col: "1",
    row: "1"
  });
  return /* @__PURE__ */ jsxs(
    Modal,
    {
      show: showModal,
      maxWidth: "md",
      closeable: true,
      onClose: () => setShowModal(false),
      children: [
        /* @__PURE__ */ jsxs("div", { className: "p-4 bg-blueGray-100 rounded-md", children: [
          /* @__PURE__ */ jsx("h1", { className: "font-bold text-xl text-blueGray-700 mb-4", children: "CETAK QR CODE" }),
          /* @__PURE__ */ jsxs("div", { className: "flex flex-col p-4", children: [
            /* @__PURE__ */ jsxs(
              SelectInput,
              {
                label: "Baris",
                name: "row",
                value: formData.row,
                onChange: (e) => setFormData({ ...formData, row: e.target.value }),
                children: [
                  /* @__PURE__ */ jsx("option", { value: "1", children: "1" }),
                  /* @__PURE__ */ jsx("option", { value: "2", children: "2" }),
                  /* @__PURE__ */ jsx("option", { value: "3", children: "3" }),
                  /* @__PURE__ */ jsx("option", { value: "4", children: "4" }),
                  /* @__PURE__ */ jsx("option", { value: "5", children: "5" }),
                  /* @__PURE__ */ jsx("option", { value: "6", children: "6" })
                ]
              }
            ),
            /* @__PURE__ */ jsxs(
              SelectInput,
              {
                label: "Kolom",
                name: "col",
                value: formData.col,
                onChange: (e) => setFormData({ ...formData, col: e.target.value }),
                children: [
                  /* @__PURE__ */ jsx("option", { value: "1", children: "1" }),
                  /* @__PURE__ */ jsx("option", { value: "2", children: "2" }),
                  /* @__PURE__ */ jsx("option", { value: "3", children: "3" }),
                  /* @__PURE__ */ jsx("option", { value: "4", children: "4" }),
                  /* @__PURE__ */ jsx("option", { value: "5", children: "5" })
                ]
              }
            ),
            /* @__PURE__ */ jsxs(Button, { theme: "black", onClick: (e) => onCommit(formData), children: [
              /* @__PURE__ */ jsx("i", { className: "fas fa-print" }),
              /* @__PURE__ */ jsx("span", { className: "ml-2", children: "Cetak" })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsx("div", { className: "w-full absolute right-1 top-1 flex justify-end items-center px-1 ", children: /* @__PURE__ */ jsx(
          "button",
          {
            className: "text-blueGray-700 background-transparent font-bold uppercase px-0 py-0 text-xl outline-none focus:outline-none mr-1 mb-1 ease-linear transition-all duration-150",
            type: "button",
            onClick: (e) => setShowModal(false),
            children: /* @__PURE__ */ jsx("i", { className: "fa fa-times-circle", "aria-hidden": "true" })
          }
        ) })
      ]
    }
  );
};
export {
  PrintDialog as P
};
