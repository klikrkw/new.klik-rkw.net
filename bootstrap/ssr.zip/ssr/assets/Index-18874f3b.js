import { jsxs, jsx } from "react/jsx-runtime";
import { A as AdminLayout } from "./AdminLayout-4bc80775.js";
import { useState, useEffect } from "react";
import { twMerge } from "tailwind-merge";
import { usePage, router, Link } from "@inertiajs/react";
import { usePrevious } from "react-use";
import { pickBy } from "lodash";
import { P as Pagination } from "./Pagination-30af682d.js";
import { I as InputSearch } from "./InputSearch-6032da7e.js";
import { L as LinkButton } from "./LinkButton-a291522b.js";
import { u as useSwal } from "./useSwal-5d61a319.js";
import { A as AsyncSelectSearch } from "./AsyncSelectSearch-23c2f5cb.js";
import { M as ModalCetakLaporan } from "./ModalCetakLaporan-767963a0.js";
import { M as MenuDropdown } from "./MenuDropdown-419bd59d.js";
import { S as SelectSearch } from "./SelectSearch-22ab8168.js";
import "./NotificationDropdown-abde11b8.js";
import "@popperjs/core";
import "./ResponsiveNavLink-41b4fa07.js";
import "react-hot-toast";
import "./AuthContext-5300e6b5.js";
import "firebase/app";
import "firebase/auth";
import "firebase/firestore";
import "firebase/storage";
import "./bootstrap-b9d9b211.js";
import "axios";
import "firebase/messaging";
import "./MenuItem-f3c50e94.js";
import "classnames";
import "sweetalert2";
import "react-select/async";
import "./Modal-d06b3568.js";
import "@headlessui/react";
import "react-dom";
import "@emotion/react";
import "@emotion/cache";
import "react-loader-spinner";
import "react-select";
function CardTableKasbons({
  color = "light",
  kasbons,
  className = "",
  meta,
  labelLinks
}) {
  const { isAdmin, user, base_route, statusOpts } = usePage().props;
  const params = new URLSearchParams(window.location.search);
  const [values, setValues] = useState({
    search: params.get("search"),
    sortBy: params.get("sortBy"),
    sortDir: params.get("sortDir"),
    status: params.get("status")
  });
  const prevValues = usePrevious(values);
  const [kasbonId, setKasbonId] = useState();
  const [showModalLaporan, setShowModalLaporan] = useState(false);
  function handleSortLinkClick({
    sortBy,
    sortDir
  }) {
    setValues((values2) => ({ ...values2, sortBy, sortDir }));
  }
  const IconSort = ({
    sortBy,
    sortDir
  }) => {
    if (values.sortBy === sortBy && sortDir === "asc") {
      return /* @__PURE__ */ jsx("i", { className: "fa-solid fa-sort-up" });
    } else if (values.sortBy === sortBy && sortDir === "desc") {
      return /* @__PURE__ */ jsx("i", { className: "fa-solid fa-sort-down" });
    }
    return /* @__PURE__ */ jsx("i", { className: "fa-solid fa-sort" });
  };
  const handleRemoveData = (id) => {
    router.delete(route("admin.transaksi.kasbons.destroy", id));
  };
  function prosesLaporan(e, kasbonId2) {
    e.preventDefault();
    setKasbonId(kasbonId2);
    setShowModalLaporan(true);
  }
  const cstatus = statusOpts.find((e) => e.value == values.status);
  const [curStatus, setCurStatus] = useState(
    cstatus ? cstatus : null
  );
  useEffect(() => {
    if (prevValues) {
      const query = Object.keys(pickBy(values)).length ? pickBy(values) : {};
      router.get(
        route(route().current() ? route().current() + "" : ""),
        query,
        {
          replace: true,
          preserveState: true
        }
      );
    }
  }, [values]);
  return /* @__PURE__ */ jsxs(
    "div",
    {
      className: twMerge(
        "relative flex flex-col min-w-0 break-words w-full mb-6 shadow-lg shadow-slate-700 rounded-md py-1 ",
        color === "light" ? "bg-white" : "bg-lightBlue-900 text-white",
        className
      ),
      children: [
        /* @__PURE__ */ jsx("div", { className: "rounded-full mb-0 px-4 py-3 border-0 ", children: /* @__PURE__ */ jsxs("div", { className: "flex justify-between w-full flex-col md:flex-row", children: [
          /* @__PURE__ */ jsx("div", { className: "relative w-full max-w-full flex-grow flex-1 mb-2", children: /* @__PURE__ */ jsx(
            "h3",
            {
              className: "font-semibold text-lg " + (color === "light" ? "text-blueGray-700" : "text-white"),
              children: "Kasbon List"
            }
          ) }),
          /* @__PURE__ */ jsxs("div", { className: "flex flex-col justify-center gap-1 md:flex-row items-start w-full md:w-2/3", children: [
            isAdmin ? /* @__PURE__ */ jsx(
              AsyncSelectSearch,
              {
                placeholder: "Pilih User",
                value: user,
                name: "users",
                url: "/admin/users/api/list/",
                onChange: (e) => setValues((v) => ({
                  ...v,
                  user_id: e ? e.value : ""
                })),
                isClearable: true,
                optionLabels: ["name"],
                optionValue: "id",
                className: "text-blueGray-900"
              }
            ) : null,
            /* @__PURE__ */ jsx(
              SelectSearch,
              {
                name: "status",
                className: "text-gray-800",
                value: curStatus,
                options: statusOpts,
                placeholder: "Pilih Status",
                onChange: (e) => {
                  setValues((prev) => ({
                    ...prev,
                    status: e.value
                  }));
                  setCurStatus(e ? e : {});
                }
              }
            ),
            /* @__PURE__ */ jsx(
              InputSearch,
              {
                className: "w-2/3",
                value: values.search ? values.search : "",
                onChange: (e) => setValues((v) => ({
                  ...v,
                  search: e.target.value
                }))
              }
            ),
            /* @__PURE__ */ jsx(
              LinkButton,
              {
                theme: "blue",
                href: route("admin.transaksi.kasbons.create"),
                children: /* @__PURE__ */ jsxs("span", { className: "flex items-center gap-1", children: [
                  /* @__PURE__ */ jsx("i", { className: "fa-solid fa-plus" }),
                  " New"
                ] })
              }
            )
          ] })
        ] }) }),
        /* @__PURE__ */ jsx("div", { className: "block w-full overflow-x-auto overflow-y-visible md:overflow-visible", children: /* @__PURE__ */ jsxs("table", { className: "items-center w-full bg-transparent border-collapse", children: [
          /* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", { children: [
            /* @__PURE__ */ jsx(
              "th",
              {
                className: "px-4 align-middle border border-solid py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left " + (color === "light" ? "bg-blueGray-50 text-blueGray-500 border-blueGray-100" : "bg-lightBlue-800 text-lightBlue-300 border-lightBlue-700"),
                children: /* @__PURE__ */ jsx(
                  Link,
                  {
                    href: "#",
                    onClick: (e) => handleSortLinkClick({
                      sortBy: "id",
                      sortDir: values.sortDir === "asc" ? "desc" : "asc"
                    }),
                    children: /* @__PURE__ */ jsxs("div", { className: "flex flex-row justify-between", children: [
                      /* @__PURE__ */ jsx("span", { children: "Id" }),
                      /* @__PURE__ */ jsx(
                        IconSort,
                        {
                          sortBy: "id",
                          sortDir: values.sortDir || ""
                        }
                      )
                    ] })
                  }
                )
              }
            ),
            /* @__PURE__ */ jsx(
              "th",
              {
                className: "px-4 align-middle border border-solid py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left " + (color === "light" ? "bg-blueGray-50 text-blueGray-500 border-blueGray-100" : "bg-lightBlue-800 text-lightBlue-300 border-lightBlue-700"),
                children: /* @__PURE__ */ jsx(
                  Link,
                  {
                    href: "#",
                    onClick: (e) => handleSortLinkClick({
                      sortBy: "created_at",
                      sortDir: values.sortDir === "asc" ? "desc" : "asc"
                    }),
                    children: /* @__PURE__ */ jsxs("div", { className: "flex flex-row justify-between", children: [
                      /* @__PURE__ */ jsx("span", { children: "Tanggal" }),
                      /* @__PURE__ */ jsx(
                        IconSort,
                        {
                          sortBy: "created_at",
                          sortDir: values.sortDir || ""
                        }
                      )
                    ] })
                  }
                )
              }
            ),
            /* @__PURE__ */ jsx(
              "th",
              {
                className: "px-4 align-middle border border-solid py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left " + (color === "light" ? "bg-blueGray-50 text-blueGray-500 border-blueGray-100" : "bg-lightBlue-800 text-lightBlue-300 border-lightBlue-700"),
                children: /* @__PURE__ */ jsx("div", { className: "flex flex-row justify-between", children: /* @__PURE__ */ jsx("span", { children: "Jumlah " }) })
              }
            ),
            /* @__PURE__ */ jsx(
              "th",
              {
                className: "px-4 align-middle border border-solid py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left " + (color === "light" ? "bg-blueGray-50 text-blueGray-500 border-blueGray-100" : "bg-lightBlue-800 text-lightBlue-300 border-lightBlue-700"),
                children: /* @__PURE__ */ jsx("div", { className: "flex flex-row justify-between", children: /* @__PURE__ */ jsx("span", { children: "Penggunaan" }) })
              }
            ),
            /* @__PURE__ */ jsx(
              "th",
              {
                className: "px-4 align-middle border border-solid py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left " + (color === "light" ? "bg-blueGray-50 text-blueGray-500 border-blueGray-100" : "bg-lightBlue-800 text-lightBlue-300 border-lightBlue-700"),
                children: /* @__PURE__ */ jsx("div", { className: "flex flex-row justify-between", children: /* @__PURE__ */ jsx("span", { children: "Sisa Penggunaan" }) })
              }
            ),
            /* @__PURE__ */ jsx(
              "th",
              {
                className: "px-4 align-middle border border-solid py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left " + (color === "light" ? "bg-blueGray-50 text-blueGray-500 border-blueGray-100" : "bg-lightBlue-800 text-lightBlue-300 border-lightBlue-700"),
                children: /* @__PURE__ */ jsx("div", { className: "flex flex-row justify-between", children: /* @__PURE__ */ jsx("span", { children: "Keperluan" }) })
              }
            ),
            /* @__PURE__ */ jsx(
              "th",
              {
                className: "px-4 align-middle border border-solid py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left " + (color === "light" ? "bg-blueGray-50 text-blueGray-500 border-blueGray-100" : "bg-lightBlue-800 text-lightBlue-300 border-lightBlue-700"),
                children: /* @__PURE__ */ jsx("div", { className: "flex flex-row justify-between", children: /* @__PURE__ */ jsx("span", { children: "Instansi" }) })
              }
            ),
            /* @__PURE__ */ jsx(
              "th",
              {
                className: "px-4 align-middle border border-solid py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left " + (color === "light" ? "bg-blueGray-50 text-blueGray-500 border-blueGray-100" : "bg-lightBlue-800 text-lightBlue-300 border-lightBlue-700"),
                children: /* @__PURE__ */ jsx("div", { className: "flex flex-row justify-between", children: /* @__PURE__ */ jsx("span", { children: "User" }) })
              }
            ),
            /* @__PURE__ */ jsx(
              "th",
              {
                className: "px-4 align-middle border border-solid py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left " + (color === "light" ? "bg-blueGray-50 text-blueGray-500 border-blueGray-100" : "bg-lightBlue-800 text-lightBlue-300 border-lightBlue-700"),
                children: /* @__PURE__ */ jsx("div", { className: "flex flex-row justify-between", children: /* @__PURE__ */ jsx("span", { children: "Status" }) })
              }
            ),
            /* @__PURE__ */ jsx(
              "th",
              {
                className: "px-4 align-middle border border-solid py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left " + (color === "light" ? "bg-blueGray-50 text-blueGray-500 border-blueGray-100" : "bg-lightBlue-800 text-lightBlue-300 border-lightBlue-700"),
                children: "Menu"
              }
            )
          ] }) }),
          /* @__PURE__ */ jsx("tbody", { children: kasbons.map(
            ({
              id,
              tgl_kasbon,
              jumlah_kasbon,
              jumlah_penggunaan,
              sisa_penggunaan,
              keperluan,
              user: user2,
              status_kasbon,
              instansi
            }, index) => /* @__PURE__ */ jsxs("tr", { children: [
              /* @__PURE__ */ jsx("td", { className: "border-t-0 px-4 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-2", children: id }),
              /* @__PURE__ */ jsx("td", { className: "border-t-0 px-4 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-2", children: tgl_kasbon }),
              /* @__PURE__ */ jsx("td", { className: "border-t-0 px-4 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-2", children: jumlah_kasbon }),
              /* @__PURE__ */ jsx("td", { className: "border-t-0 px-4 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-2", children: jumlah_penggunaan }),
              /* @__PURE__ */ jsx("td", { className: "border-t-0 px-4 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-2", children: sisa_penggunaan }),
              /* @__PURE__ */ jsx(
                "td",
                {
                  className: "border-t-0 px-4 align-middle border-l-0 border-r-0\n                                    text-xs whitespace-pre-wrap p-2",
                  children: keperluan
                }
              ),
              /* @__PURE__ */ jsx("td", { className: "border-t-0 px-4 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-2", children: instansi.nama_instansi }),
              /* @__PURE__ */ jsx("td", { className: "border-t-0 px-4 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-2", children: user2.name }),
              /* @__PURE__ */ jsx("td", { className: "border-t-0 px-4 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-2", children: status_kasbon }),
              /* @__PURE__ */ jsx("td", { className: "border-t-0 px-4 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap py-4", children: /* @__PURE__ */ jsxs(MenuDropdown, { children: [
                isAdmin ? /* @__PURE__ */ jsxs(
                  Link,
                  {
                    href: route(
                      base_route + "transaksi.kasbons.edit",
                      id
                    ),
                    className: "text-sm py-2 px-4 font-normal block w-full whitespace-nowrap bg-transparent text-blueGray-700",
                    children: [
                      /* @__PURE__ */ jsx("i", { className: "fas fa-edit" }),
                      /* @__PURE__ */ jsx("span", { children: " Edit" })
                    ]
                  }
                ) : null,
                /* @__PURE__ */ jsxs(
                  Link,
                  {
                    href: "#",
                    onClick: (e) => {
                      prosesLaporan(e, id);
                    },
                    className: "text-sm py-2 px-4 font-normal block w-full whitespace-nowrap bg-transparent text-blueGray-700",
                    children: [
                      /* @__PURE__ */ jsx("i", { className: "fas fa-print" }),
                      /* @__PURE__ */ jsx("span", { children: " Cetak Kasbon" })
                    ]
                  }
                ),
                status_kasbon === "cancelled" && /* @__PURE__ */ jsxs(
                  Link,
                  {
                    href: "#",
                    onClick: (e) => useSwal.confirm({
                      title: "Hapus Data",
                      text: "apakah akan menghapus?"
                    }).then((result) => {
                      if (result.isConfirmed) {
                        handleRemoveData(
                          id
                        );
                      }
                    }),
                    className: "text-sm py-2 px-4 font-normal block w-full whitespace-nowrap bg-transparent text-blueGray-700",
                    type: "button",
                    children: [
                      /* @__PURE__ */ jsx("i", { className: "fas fa-trash" }),
                      /* @__PURE__ */ jsx("span", { children: " Hapus" })
                    ]
                  }
                )
              ] }) })
            ] }, index)
          ) })
        ] }) }),
        meta.total > meta.per_page ? /* @__PURE__ */ jsx(
          "div",
          {
            className: "flex justify-end px-2 py-1  " + (color === "light" ? "bg-blueGray-50 text-blueGray-500 border-blueGray-100" : "bg-lightBlue-800 text-lightBlue-300 border-lightBlue-700"),
            children: /* @__PURE__ */ jsx(Pagination, { links: meta.links, labelLinks })
          }
        ) : null,
        kasbonId && /* @__PURE__ */ jsx(
          ModalCetakLaporan,
          {
            showModal: showModalLaporan,
            setShowModal: setShowModalLaporan,
            src: route(
              base_route + "transaksi.kasbons.lap.staf",
              kasbonId
            )
          }
        )
      ]
    }
  );
}
const Index = ({
  kasbons,
  base_route
}) => {
  const { data, meta, links } = kasbons;
  return /* @__PURE__ */ jsx(AdminLayout, { children: /* @__PURE__ */ jsx(
    CardTableKasbons,
    {
      color: "dark",
      kasbons: data,
      meta,
      labelLinks: links
    }
  ) });
};
export {
  Index as default
};
