import { jsx } from "react/jsx-runtime";
const Qrcode = ({ qrCode }) => {
  return /* @__PURE__ */ jsx("div", { className: "flex justify-center items-center p-4", children: qrCode ? /* @__PURE__ */ jsx("img", { src: `/${qrCode}`, alt: "", className: "w-24 h-24" }) : null });
};
export {
  Qrcode as default
};
