import { jsxs, jsx } from "react/jsx-runtime";
import { P as Pagination } from "./Pagination-30af682d.js";
import { t as toRupiah } from "./index-d9460823.js";
import { u as useSwal } from "./useSwal-5d61a319.js";
import { usePage, router } from "@inertiajs/react";
const CardDrincianbiayapermList = ({
  rincianbiayaperm
}) => {
  const {
    drincianbiayaperms: { data, links, meta },
    base_route
  } = usePage().props;
  const handleRemoveData = (id) => {
    router.delete(
      route(base_route + "transaksi.drincianbiayaperms.destroy", id)
    );
  };
  return /* @__PURE__ */ jsxs("div", { className: "w-full mt-4 flex flex-col", children: [
    /* @__PURE__ */ jsx("ul", { className: "list-none container-snap max-h-56 overflow-x-hidden", children: /* @__PURE__ */ jsxs("li", { className: "flex uppercase gap-1 flex-row w-full items-center rounded-t-md text-xs border justify-start bg-lightBlue-600 border-blueGray-400 px-2 py-2  text-lightBlue-50 font-semibold", children: [
      /* @__PURE__ */ jsx("div", { className: "w-[5%]", children: "No" }),
      /* @__PURE__ */ jsx("div", { className: "w-[55%] md:w-[35%]", children: "Nama Kegiatan" }),
      /* @__PURE__ */ jsx("div", { className: "hidden md:block w-[40%]", children: "Keterangan" }),
      /* @__PURE__ */ jsx("div", { className: "w-[25%] md:w-[15%] text-right", children: "Jumlah" }),
      /* @__PURE__ */ jsx("div", { className: "w-[15%] md:w-[5%] text-center", children: "Menu" })
    ] }) }),
    /* @__PURE__ */ jsx("ul", { className: "list-none container-snap max-h-80 overflow-x-hidden rounded-b-md shadow-md", children: /* @__PURE__ */ jsx("li", { className: "w-full flex flex-col overflow-hidden bg-lightBlue-200", children: /* @__PURE__ */ jsx("div", { className: "flex w-full gap-1 text-sm text-bold px-2 py-1 items-center justify-start text-lightBlue-900 border-b-2 border-lightBlue-200", children: "PEMASUKAN" }) }) }),
    /* @__PURE__ */ jsx("ul", { className: "list-none container-snap max-h-80 overflow-x-hidden rounded-b-md shadow-md", children: data && data.map((item, index) => {
      if (item.itemrincianbiayaperm.jenis_itemrincianbiayaperm === "pemasukan") {
        return /* @__PURE__ */ jsx(
          "li",
          {
            className: "w-full flex flex-col overflow-hidden bg-lightBlue-300",
            children: /* @__PURE__ */ jsxs("div", { className: "flex w-full gap-1 text-xs px-2 py-0 items-center justify-start text-lightBlue-900 border-b-2 border-lightBlue-200", children: [
              /* @__PURE__ */ jsxs("div", { className: "pb-0 w-[5%]", children: [
                index + 1,
                "."
              ] }),
              /* @__PURE__ */ jsx("div", { className: "pb-0 w-[55%] md:w-[35%]", children: item.itemrincianbiayaperm.nama_itemrincianbiayaperm }),
              /* @__PURE__ */ jsx("div", { className: "pb-0 hidden md:block md:w-[40%]", children: item.ket_biaya }),
              /* @__PURE__ */ jsx("div", { className: "pb-0 w-[25%] md:w-[15%] text-right ", children: item.jumlah_biaya }),
              /* @__PURE__ */ jsx("div", { className: "pb-0 w-[15%] md:w-[5%] flex justify-center items-center", children: /* @__PURE__ */ jsx(
                "button",
                {
                  disabled: rincianbiayaperm.status_rincianbiayaperm == "approved",
                  onClick: (e) => useSwal.confirm({
                    title: "Hapus Data",
                    text: "apakah akan menghapus?"
                  }).then((result) => {
                    if (result.isConfirmed) {
                      handleRemoveData(
                        item.id
                      );
                    }
                  }),
                  className: "text-lightBlue-500 background-transparent text-lg font-bold uppercase px-0 py-0 outline-none focus:outline-none mr-1 mb-1 ease-linear transition-all duration-150",
                  type: "button",
                  children: /* @__PURE__ */ jsx(
                    "i",
                    {
                      className: "fa fa-trash",
                      "aria-hidden": "true"
                    }
                  )
                }
              ) })
            ] })
          },
          item.id
        );
      }
    }) }),
    /* @__PURE__ */ jsx("ul", { className: "list-none container-snap max-h-80 overflow-x-hidden rounded-b-md shadow-md", children: /* @__PURE__ */ jsx("li", { className: "w-full flex flex-col overflow-hidden bg-lightBlue-200", children: /* @__PURE__ */ jsx("div", { className: "flex w-full gap-1 text-sm text-bold px-2 py-1 items-center justify-start text-lightBlue-900 border-b-2 border-lightBlue-200", children: "PENGELUARAN" }) }) }),
    /* @__PURE__ */ jsx("ul", { className: "list-none container-snap max-h-80 overflow-x-hidden rounded-b-md shadow-md", children: data && data.map((item, index) => {
      if (item.itemrincianbiayaperm.jenis_itemrincianbiayaperm === "pengeluaran") {
        return /* @__PURE__ */ jsx(
          "li",
          {
            className: "w-full flex flex-col overflow-hidden bg-lightBlue-300",
            children: /* @__PURE__ */ jsxs("div", { className: "flex w-full gap-1 text-xs px-2 py-0 items-center justify-start text-lightBlue-900 border-b-2 border-lightBlue-200", children: [
              /* @__PURE__ */ jsxs("div", { className: "pb-0 w-[5%]", children: [
                index + 1,
                "."
              ] }),
              /* @__PURE__ */ jsx("div", { className: "pb-0 w-[55%] md:w-[35%]", children: item.itemrincianbiayaperm.nama_itemrincianbiayaperm }),
              /* @__PURE__ */ jsx("div", { className: "pb-0 hidden md:block md:w-[40%]", children: item.ket_biaya }),
              /* @__PURE__ */ jsx("div", { className: "pb-0 w-[25%] md:w-[15%] text-right ", children: item.jumlah_biaya }),
              /* @__PURE__ */ jsx("div", { className: "pb-0 w-[15%] md:w-[5%] flex justify-center items-center", children: /* @__PURE__ */ jsx(
                "button",
                {
                  disabled: rincianbiayaperm.status_rincianbiayaperm == "approved",
                  onClick: (e) => useSwal.confirm({
                    title: "Hapus Data",
                    text: "apakah akan menghapus?"
                  }).then((result) => {
                    if (result.isConfirmed) {
                      handleRemoveData(
                        item.id
                      );
                    }
                  }),
                  className: "text-lightBlue-500 background-transparent text-lg font-bold uppercase px-0 py-0 outline-none focus:outline-none mr-1 mb-1 ease-linear transition-all duration-150",
                  type: "button",
                  children: /* @__PURE__ */ jsx(
                    "i",
                    {
                      className: "fa fa-trash",
                      "aria-hidden": "true"
                    }
                  )
                }
              ) })
            ] })
          },
          item.id
        );
      }
    }) }),
    /* @__PURE__ */ jsx("ul", { className: "list-none container-snap max-h-80 overflow-x-hidden rounded-b-md shadow-md", children: /* @__PURE__ */ jsx("li", { className: "w-full flex flex-col overflow-hidden bg-lightBlue-200", children: /* @__PURE__ */ jsx("div", { className: "flex w-full gap-1 text-sm text-bold px-2 py-1 items-center justify-start text-lightBlue-900 border-b-2 border-lightBlue-200", children: "PIUTANG" }) }) }),
    /* @__PURE__ */ jsx("ul", { className: "list-none container-snap max-h-80 overflow-x-hidden rounded-b-md shadow-md", children: data && data.map((item, index) => {
      if (item.itemrincianbiayaperm.jenis_itemrincianbiayaperm === "piutang") {
        return /* @__PURE__ */ jsx(
          "li",
          {
            className: "w-full flex flex-col overflow-hidden bg-lightBlue-300",
            children: /* @__PURE__ */ jsxs("div", { className: "flex w-full gap-1 text-xs px-2 py-0 items-center justify-start text-lightBlue-900 border-b-2 border-lightBlue-200", children: [
              /* @__PURE__ */ jsxs("div", { className: "pb-0 w-[5%]", children: [
                index + 1,
                "."
              ] }),
              /* @__PURE__ */ jsx("div", { className: "pb-0 w-[55%] md:w-[35%]", children: item.itemrincianbiayaperm.nama_itemrincianbiayaperm }),
              /* @__PURE__ */ jsx("div", { className: "pb-0 hidden md:block md:w-[40%]", children: item.ket_biaya }),
              /* @__PURE__ */ jsx("div", { className: "pb-0 w-[25%] md:w-[15%] text-right ", children: item.jumlah_biaya }),
              /* @__PURE__ */ jsx("div", { className: "pb-0 w-[15%] md:w-[5%] flex justify-center items-center", children: /* @__PURE__ */ jsx(
                "button",
                {
                  disabled: rincianbiayaperm.status_rincianbiayaperm == "approved",
                  onClick: (e) => useSwal.confirm({
                    title: "Hapus Data",
                    text: "apakah akan menghapus?"
                  }).then((result) => {
                    if (result.isConfirmed) {
                      handleRemoveData(
                        item.id
                      );
                    }
                  }),
                  className: "text-lightBlue-500 background-transparent text-lg font-bold uppercase px-0 py-0 outline-none focus:outline-none mr-1 mb-1 ease-linear transition-all duration-150",
                  type: "button",
                  children: /* @__PURE__ */ jsx(
                    "i",
                    {
                      className: "fa fa-trash",
                      "aria-hidden": "true"
                    }
                  )
                }
              ) })
            ] })
          },
          item.id
        );
      }
    }) }),
    /* @__PURE__ */ jsx("ul", { className: "list-none container-snap max-h-80 overflow-x-hidden rounded-b-md shadow-md", children: /* @__PURE__ */ jsxs("li", { className: "w-full flex flex-col overflow-hidden bg-lightBlue-600 px-2 py-1  font-semibold text-lightBlue-50", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex w-full gap-1 text-xs px-2 py-1 items-center justify-start border-b-2 border-lightBlue-500", children: [
        /* @__PURE__ */ jsx("div", { className: "w-[10%] md:w-[60%]" }),
        /* @__PURE__ */ jsx("div", { className: "w-[40%] md:w-[20%] text-right", children: "Total Pemasukan" }),
        /* @__PURE__ */ jsx("div", { className: "w-[35%] md:w-[15%] text-right", children: toRupiah(rincianbiayaperm.total_pemasukan) }),
        /* @__PURE__ */ jsx("div", { className: "w-[15%] md:w-[5%] flex justify-start items-center gap-2" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex w-full gap-1 text-xs px-2 py-1 items-center justify-start border-b-2 border-lightBlue-500", children: [
        /* @__PURE__ */ jsx("div", { className: "w-[10%] md:w-[60%]" }),
        /* @__PURE__ */ jsx("div", { className: "w-[40%] md:w-[20%] text-right", children: "Total Pengeluaran" }),
        /* @__PURE__ */ jsx("div", { className: "w-[35%] md:w-[15%] text-right", children: toRupiah(rincianbiayaperm.total_pengeluaran) }),
        /* @__PURE__ */ jsx("div", { className: "w-[15%] md:w-[5%] flex justify-start items-center gap-2" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex w-full gap-1 text-xs px-2 py-1 items-center justify-start border-b-2 border-lightBlue-500", children: [
        /* @__PURE__ */ jsx("div", { className: "w-[10%] md:w-[60%]" }),
        /* @__PURE__ */ jsx("div", { className: "w-[40%] md:w-[20%] text-right", children: "Total Piutang" }),
        /* @__PURE__ */ jsx("div", { className: "w-[35%] md:w-[15%] text-right", children: toRupiah(rincianbiayaperm.total_piutang) }),
        /* @__PURE__ */ jsx("div", { className: "w-[15%] md:w-[5%] flex justify-start items-center gap-2" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex w-full gap-1 text-xs px-2 py-1 items-center justify-start border-b-2 border-lightBlue-500", children: [
        /* @__PURE__ */ jsx("div", { className: "w-[10%] md:w-[60%]" }),
        /* @__PURE__ */ jsx("div", { className: "w-[40%] md:w-[20%] text-right", children: "Total Bayar" }),
        /* @__PURE__ */ jsx("div", { className: "w-[35%] md:w-[15%] text-right", children: toRupiah(rincianbiayaperm.sisa_saldo) }),
        /* @__PURE__ */ jsx("div", { className: "w-[15%] md:w-[5%] flex justify-start items-center gap-2" })
      ] })
    ] }) }),
    /* @__PURE__ */ jsx(Pagination, { links: meta.links, labelLinks: links })
  ] });
};
export {
  CardDrincianbiayapermList as C
};
