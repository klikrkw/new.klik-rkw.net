import { jsx, Fragment, jsxs } from "react/jsx-runtime";
import { N as NotificationDropdown, U as UserDropdown, a as Navbar, H as HeaderBlank, T as ToastMessages } from "./NotificationDropdown-abde11b8.js";
import React from "react";
import { usePage, Link } from "@inertiajs/react";
import { M as MenuItem } from "./MenuItem-f3c50e94.js";
function Sidebar() {
  const [collapseShow, setCollapseShow] = React.useState("hidden");
  const currentRoute = route().current();
  const isTransaksiRoute = currentRoute ? currentRoute.includes("transaksi") : false;
  const isInformasiRoute = currentRoute ? currentRoute.includes("informasi") : false;
  currentRoute ? currentRoute.includes("utils") : false;
  const {
    auth: { user }
  } = usePage().props;
  return /* @__PURE__ */ jsx(Fragment, { children: /* @__PURE__ */ jsx("nav", { className: "container-snap md:left-0 md:block md:fixed md:top-0 md:bottom-0 md:overflow-y-auto md:flex-row md:flex-nowrap md:overflow-hidden shadow-xl bg-white flex flex-wrap items-center justify-between relative md:w-64 z-[55] py-4 px-6", children: /* @__PURE__ */ jsxs("div", { className: "md:flex-col md:items-stretch md:min-h-full md:flex-nowrap px-0 flex flex-wrap items-center justify-between w-full mx-auto", children: [
    /* @__PURE__ */ jsx(
      "button",
      {
        className: "cursor-pointer text-black opacity-50 md:hidden px-3 py-1 text-xl leading-none bg-transparent rounded border border-solid border-transparent",
        type: "button",
        onClick: () => setCollapseShow("bg-white m-2 py-3 px-6"),
        children: /* @__PURE__ */ jsx("i", { className: "fas fa-bars" })
      }
    ),
    /* @__PURE__ */ jsx(
      Link,
      {
        className: "md:block text-left md:pb-2 text-blueGray-600 mr-0 inline-block whitespace-nowrap text-sm uppercase p-4 px-0",
        href: "/",
        children: /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("div", { className: "text-lg font-bold", children: "PPAT APP" }),
          /* @__PURE__ */ jsx("div", { className: "text-md", children: user.name })
        ] })
      }
    ),
    /* @__PURE__ */ jsxs("ul", { className: "md:hidden items-center flex flex-wrap list-none", children: [
      /* @__PURE__ */ jsx("li", { className: "inline-block relative", children: /* @__PURE__ */ jsx(NotificationDropdown, {}) }),
      /* @__PURE__ */ jsx("li", { className: "inline-block relative", children: /* @__PURE__ */ jsx(UserDropdown, {}) })
    ] }),
    /* @__PURE__ */ jsxs(
      "div",
      {
        className: "md:flex md:flex-col md:items-stretch md:opacity-100 md:relative md:mt-4 md:shadow-none shadow absolute top-0 left-0 right-0 z-50 overflow-y-auto overflow-x-hidden h-auto items-center flex-1 rounded " + collapseShow,
        children: [
          /* @__PURE__ */ jsx("div", { className: "md:min-w-full md:hidden block pb-4 mb-2 border-b border-solid border-blueGray-200", children: /* @__PURE__ */ jsxs("div", { className: "flex flex-wrap", children: [
            /* @__PURE__ */ jsx("div", { className: "w-6/12", children: /* @__PURE__ */ jsx(
              Link,
              {
                className: "md:block text-left md:pb-2 text-blueGray-600 mr-0 inline-block whitespace-nowrap text-sm uppercase font-bold p-4 px-0",
                href: "/",
                children: "PPAT APP"
              }
            ) }),
            /* @__PURE__ */ jsx("div", { className: "w-6/12 flex justify-end", children: /* @__PURE__ */ jsx(
              "button",
              {
                type: "button",
                className: "cursor-pointer text-black opacity-50 md:hidden px-3 py-1 text-xl leading-none bg-transparent rounded border border-solid border-transparent",
                onClick: () => setCollapseShow("hidden"),
                children: /* @__PURE__ */ jsx("i", { className: "fas fa-times" })
              }
            ) })
          ] }) }),
          /* @__PURE__ */ jsx("hr", { className: "my-2 md:min-w-full" }),
          /* @__PURE__ */ jsx("h6", { className: "md:min-w-full text-blueGray-500 text-xs uppercase font-bold block pt-1 pb-4 no-underline", children: "MENU ADMIN" }),
          /* @__PURE__ */ jsxs("ul", { className: "md:flex-col md:min-w-full flex flex-col list-none", children: [
            /* @__PURE__ */ jsx("li", { className: "items-center px-2", children: /* @__PURE__ */ jsxs(
              Link,
              {
                className: "text-xs uppercase py-3 font-bold block " + (currentRoute === "admin.index" ? "text-lightBlue-500 hover:text-lightBlue-600" : "text-blueGray-700 hover:text-blueGray-500"),
                href: route("admin.index"),
                children: [
                  /* @__PURE__ */ jsx(
                    "i",
                    {
                      className: "fas fa-tv mr-2 text-sm" + (window.location.href.indexOf(
                        "/admin"
                      ) !== -1 ? "opacity-75" : "text-blueGray-300")
                    }
                  ),
                  " ",
                  "Dashboard"
                ]
              }
            ) }),
            /* @__PURE__ */ jsxs(
              MenuItem,
              {
                expanded: currentRoute ? currentRoute.includes("admin") && isTransaksiRoute == false && isInformasiRoute == false : false,
                label: "Admin",
                children: [
                  /* @__PURE__ */ jsx("li", { className: "items-center px-2", children: /* @__PURE__ */ jsxs(
                    Link,
                    {
                      className: "text-xs uppercase py-3 font-bold block " + (currentRoute === "admin.users.index" ? " text-lightBlue-500 hover:text-lightBlue-600 " : " text-blueGray-700 hover:text-blueGray-500 "),
                      href: route("admin.users.index"),
                      children: [
                        /* @__PURE__ */ jsx(
                          "i",
                          {
                            className: "fas fa-tv mr-2 text-sm " + (currentRoute === "admin.users.index" ? "opacity-75" : "text-blueGray-300")
                          }
                        ),
                        " ",
                        "Users"
                      ]
                    }
                  ) }),
                  /* @__PURE__ */ jsx("li", { className: "items-center px-2", children: /* @__PURE__ */ jsxs(
                    Link,
                    {
                      className: "text-xs uppercase py-3 font-bold block " + (currentRoute === "admin.pengaturans.index" ? " text-lightBlue-500 hover:text-lightBlue-600 " : " text-blueGray-700 hover:text-blueGray-500 "),
                      href: route("admin.pengaturans.index"),
                      children: [
                        /* @__PURE__ */ jsx(
                          "i",
                          {
                            className: "fas fa-cogs mr-2 text-sm " + (currentRoute === "admin.pengaturans.index" ? "opacity-75" : "text-blueGray-300")
                          }
                        ),
                        " ",
                        "Pengaturans"
                      ]
                    }
                  ) }),
                  /* @__PURE__ */ jsx("li", { className: "items-center px-2", children: /* @__PURE__ */ jsxs(
                    Link,
                    {
                      className: "text-xs uppercase py-3 font-bold block " + (currentRoute === "admin.permissions.index" ? "text-lightBlue-500 hover:text-lightBlue-600" : "text-blueGray-700 hover:text-blueGray-500"),
                      href: route("admin.permissions.index"),
                      children: [
                        /* @__PURE__ */ jsx(
                          "i",
                          {
                            className: "fas fa-tv mr-2 text-sm " + (currentRoute === "admin.permissions.index" ? "opacity-75" : "text-blueGray-300")
                          }
                        ),
                        " ",
                        "Permissions"
                      ]
                    }
                  ) }),
                  /* @__PURE__ */ jsx("li", { className: "items-center px-2", children: /* @__PURE__ */ jsxs(
                    Link,
                    {
                      className: "text-xs uppercase py-3 font-bold block " + (currentRoute === "admin.roles.index" ? "text-lightBlue-500 hover:text-lightBlue-600" : "text-blueGray-700 hover:text-blueGray-500"),
                      href: route("admin.roles.index"),
                      children: [
                        /* @__PURE__ */ jsx(
                          "i",
                          {
                            className: "fas fa-tv mr-2 text-sm " + (currentRoute === "admin.roles.index" ? "opacity-75" : "text-blueGray-300")
                          }
                        ),
                        " ",
                        "Roles"
                      ]
                    }
                  ) }),
                  /* @__PURE__ */ jsx("li", { className: "items-center px-2", children: /* @__PURE__ */ jsxs(
                    Link,
                    {
                      className: "text-xs uppercase py-3 font-bold block " + (currentRoute === "admin.permohonans.index" ? "text-lightBlue-500 hover:text-lightBlue-600" : "text-blueGray-700 hover:text-blueGray-500"),
                      href: route("admin.permohonans.index"),
                      children: [
                        /* @__PURE__ */ jsx(
                          "i",
                          {
                            className: "fas fa-tv mr-2 text-sm " + (currentRoute === "admin.permohonans.index" ? "opacity-75" : "text-blueGray-300")
                          }
                        ),
                        " ",
                        "Permohonans"
                      ]
                    }
                  ) }),
                  /* @__PURE__ */ jsx("li", { className: "items-center px-2", children: /* @__PURE__ */ jsxs(
                    Link,
                    {
                      className: "text-xs uppercase py-3 font-bold flex items-center " + (currentRoute === "admin.permohonans.qrcode.create" ? "text-lightBlue-500 hover:text-lightBlue-600" : "text-blueGray-700 hover:text-blueGray-500"),
                      href: route(
                        "admin.permohonans.qrcode.create"
                      ),
                      children: [
                        /* @__PURE__ */ jsx(
                          "i",
                          {
                            className: "fas fa-tv mr-2 text-sm " + (currentRoute === "admin.permohonans.qrcode.create" ? "opacity-75" : "text-blueGray-300")
                          }
                        ),
                        " ",
                        /* @__PURE__ */ jsxs("span", { className: "flex flex-col", children: [
                          /* @__PURE__ */ jsx("span", { children: "Label Berkas" }),
                          /* @__PURE__ */ jsx("span", { children: "Qr Code" })
                        ] })
                      ]
                    }
                  ) }),
                  /* @__PURE__ */ jsx("li", { className: "items-center px-2", children: /* @__PURE__ */ jsxs(
                    Link,
                    {
                      className: "text-xs uppercase py-3 font-bold block " + (currentRoute === "admin.jenispermohonans.index" ? "text-lightBlue-500 hover:text-lightBlue-600" : "text-blueGray-700 hover:text-blueGray-500"),
                      href: route(
                        "admin.jenispermohonans.index"
                      ),
                      children: [
                        /* @__PURE__ */ jsx(
                          "i",
                          {
                            className: "fas fa-tv mr-2 text-sm " + (currentRoute === "admin.jenispermohonans.index" ? "opacity-75" : "text-blueGray-300")
                          }
                        ),
                        " ",
                        "Jenis Permohonan"
                      ]
                    }
                  ) }),
                  /* @__PURE__ */ jsx("li", { className: "items-center px-2", children: /* @__PURE__ */ jsxs(
                    Link,
                    {
                      className: "text-xs uppercase py-3 font-bold block " + (currentRoute === "admin.itemprosesperms.index" ? "text-lightBlue-500 hover:text-lightBlue-600" : "text-blueGray-700 hover:text-blueGray-500"),
                      href: route(
                        "admin.itemprosesperms.index"
                      ),
                      children: [
                        /* @__PURE__ */ jsx(
                          "i",
                          {
                            className: "fas fa-tv mr-2 text-sm " + (currentRoute === "admin.itemprosesperms.index" ? "opacity-75" : "text-blueGray-300")
                          }
                        ),
                        " ",
                        "Item Proses"
                      ]
                    }
                  ) }),
                  /* @__PURE__ */ jsx("li", { className: "items-center px-2", children: /* @__PURE__ */ jsxs(
                    Link,
                    {
                      className: "text-xs uppercase py-3 font-bold block " + (currentRoute === "admin.statusprosesperms.index" ? "text-lightBlue-500 hover:text-lightBlue-600" : "text-blueGray-700 hover:text-blueGray-500"),
                      href: route(
                        "admin.statusprosesperms.index"
                      ),
                      children: [
                        /* @__PURE__ */ jsx(
                          "i",
                          {
                            className: "fas fa-tv mr-2 text-sm " + (currentRoute === "admin.statusprosesperms.index" ? "opacity-75" : "text-blueGray-300")
                          }
                        ),
                        " ",
                        "Status Proses"
                      ]
                    }
                  ) }),
                  /* @__PURE__ */ jsx("li", { className: "items-center px-2", children: /* @__PURE__ */ jsxs(
                    Link,
                    {
                      className: "text-xs uppercase py-3 font-bold block " + (currentRoute === "admin.akuns.index" ? "text-lightBlue-500 hover:text-lightBlue-600" : "text-blueGray-700 hover:text-blueGray-500"),
                      href: route("admin.akuns.index"),
                      children: [
                        /* @__PURE__ */ jsx(
                          "i",
                          {
                            className: "fas fa-tv mr-2 text-sm " + (currentRoute === "admin.akuns.index" ? "opacity-75" : "text-blueGray-300")
                          }
                        ),
                        " ",
                        "Akun"
                      ]
                    }
                  ) }),
                  /* @__PURE__ */ jsx("li", { className: "items-center px-2", children: /* @__PURE__ */ jsxs(
                    Link,
                    {
                      className: "text-xs uppercase py-3 font-bold block " + (currentRoute === "admin.itemkegiatans.index" ? "text-lightBlue-500 hover:text-lightBlue-600" : "text-blueGray-700 hover:text-blueGray-500"),
                      href: route(
                        "admin.itemkegiatans.index"
                      ),
                      children: [
                        /* @__PURE__ */ jsx(
                          "i",
                          {
                            className: "fas fa-tv mr-2 text-sm " + (currentRoute === "admin.itemkegiatans.index" ? "opacity-75" : "text-blueGray-300")
                          }
                        ),
                        " ",
                        "Item Kegiatan"
                      ]
                    }
                  ) }),
                  /* @__PURE__ */ jsx("li", { className: "items-center px-2", children: /* @__PURE__ */ jsxs(
                    Link,
                    {
                      className: "text-xs uppercase py-3 font-bold block " + (currentRoute === "admin.rekenings.index" ? "text-lightBlue-500 hover:text-lightBlue-600" : "text-blueGray-700 hover:text-blueGray-500"),
                      href: route("admin.rekenings.index"),
                      children: [
                        /* @__PURE__ */ jsx(
                          "i",
                          {
                            className: "fas fa-tv mr-2 text-sm " + (currentRoute === "admin.rekenings.index" ? "opacity-75" : "text-blueGray-300")
                          }
                        ),
                        " ",
                        "Rekening"
                      ]
                    }
                  ) }),
                  /* @__PURE__ */ jsx("li", { className: "items-center px-2", children: /* @__PURE__ */ jsxs(
                    Link,
                    {
                      className: "text-xs uppercase py-3 font-bold block " + (currentRoute === "admin.itemrincianbiayaperms.index" ? "text-lightBlue-500 hover:text-lightBlue-600" : "text-blueGray-700 hover:text-blueGray-500"),
                      href: route(
                        "admin.itemrincianbiayaperms.index"
                      ),
                      children: [
                        /* @__PURE__ */ jsx(
                          "i",
                          {
                            className: "fas fa-tv mr-2 text-sm " + (currentRoute === "admin.itemrincianbiayaperms.index" ? "opacity-75" : "text-blueGray-300")
                          }
                        ),
                        " ",
                        "Item Rincian Biaya"
                      ]
                    }
                  ) }),
                  /* @__PURE__ */ jsxs(MenuItem, { expanded: true, label: "Arsip", children: [
                    /* @__PURE__ */ jsx("li", { className: "items-center px-2", children: /* @__PURE__ */ jsxs(
                      Link,
                      {
                        className: "text-xs uppercase py-3 font-bold block " + (currentRoute === "admin.kantors.index" ? " text-lightBlue-500 hover:text-lightBlue-600" : " text-blueGray-700 hover:text-blueGray-500"),
                        href: route("admin.kantors.index"),
                        children: [
                          /* @__PURE__ */ jsx(
                            "i",
                            {
                              className: "fas fa-building mr-2 text-sm " + (currentRoute === "admin.kantors.index" ? "opacity-75" : "text-blueGray-300")
                            }
                          ),
                          " ",
                          "Kantor"
                        ]
                      }
                    ) }),
                    /* @__PURE__ */ jsx("li", { className: "items-center px-2", children: /* @__PURE__ */ jsxs(
                      Link,
                      {
                        className: "text-xs uppercase py-3 font-bold block " + (currentRoute === "admin.ruangs.index" ? " text-lightBlue-500 hover:text-lightBlue-600" : " text-blueGray-700 hover:text-blueGray-500"),
                        href: route("admin.ruangs.index"),
                        children: [
                          /* @__PURE__ */ jsx(
                            "i",
                            {
                              className: "fas fa-building mr-2 text-sm " + (currentRoute === "admin.ruangs.index" ? "opacity-75" : "text-blueGray-300")
                            }
                          ),
                          " ",
                          "Ruang"
                        ]
                      }
                    ) }),
                    /* @__PURE__ */ jsx("li", { className: "items-center px-2", children: /* @__PURE__ */ jsxs(
                      Link,
                      {
                        className: "text-xs uppercase py-3 font-bold block " + (currentRoute === "admin.tempatberkas.index" ? " text-lightBlue-500 hover:text-lightBlue-600" : " text-blueGray-700 hover:text-blueGray-500"),
                        href: route(
                          "admin.tempatberkas.index"
                        ),
                        children: [
                          /* @__PURE__ */ jsx(
                            "i",
                            {
                              className: "fas fa-building mr-2 text-sm " + (currentRoute === "admin.tempatberkas.index" ? "opacity-75" : "text-blueGray-300")
                            }
                          ),
                          " ",
                          "Tempat Berkas"
                        ]
                      }
                    ) })
                  ] })
                ]
              }
            ),
            /* @__PURE__ */ jsxs(
              MenuItem,
              {
                expanded: currentRoute ? currentRoute.includes("transaksi") : false,
                label: "Transaksi",
                children: [
                  /* @__PURE__ */ jsx("li", { className: "items-center px-2", children: /* @__PURE__ */ jsxs(
                    Link,
                    {
                      className: "text-xs uppercase py-3 font-bold block " + (currentRoute === "admin.transaksi.prosespermohonans.create" ? " text-lightBlue-500 hover:text-lightBlue-600 " : " text-blueGray-700 hover:text-blueGray-500 "),
                      href: route(
                        "admin.transaksi.prosespermohonans.create"
                      ),
                      children: [
                        /* @__PURE__ */ jsx(
                          "i",
                          {
                            className: "fas fa-tv mr-2 text-sm " + (currentRoute === "admin.transaksi.prosespermohonans.create" ? "opacity-75" : "text-blueGray-300")
                          }
                        ),
                        " ",
                        "Proses Permohonan"
                      ]
                    }
                  ) }),
                  /* @__PURE__ */ jsx("li", { className: "items-center px-2 flex flex-row gap-2", children: /* @__PURE__ */ jsxs(
                    Link,
                    {
                      className: "text-xs uppercase py-3 font-bold flex items-center " + (currentRoute === "admin.transaksi.transpermohonans.posisiberkas.create" ? " text-lightBlue-500 hover:text-lightBlue-600 " : " text-blueGray-700 hover:text-blueGray-500 "),
                      href: route(
                        "admin.transaksi.transpermohonans.posisiberkas.create"
                      ),
                      children: [
                        /* @__PURE__ */ jsx(
                          "i",
                          {
                            className: "fas fa-tv mr-2 text-sm " + (currentRoute === "admin.transaksi.transpermohonans.posisiberkas.create" ? "opacity-75" : "text-blueGray-300")
                          }
                        ),
                        /* @__PURE__ */ jsxs("span", { children: [
                          /* @__PURE__ */ jsx("span", { className: "inline-block", children: "Tempat Berkas" }),
                          /* @__PURE__ */ jsx("span", { className: "inline-block", children: "Permohonan" })
                        ] })
                      ]
                    }
                  ) }),
                  /* @__PURE__ */ jsx("li", { className: "items-center px-2", children: /* @__PURE__ */ jsxs(
                    Link,
                    {
                      className: "text-xs uppercase py-3 font-bold block " + (currentRoute === "admin.transaksi.rincianbiayaperms.index" ? " text-lightBlue-500 hover:text-lightBlue-600 " : " text-blueGray-700 hover:text-blueGray-500 "),
                      href: route(
                        "admin.transaksi.rincianbiayaperms.index"
                      ),
                      children: [
                        /* @__PURE__ */ jsx(
                          "i",
                          {
                            className: "fas fa-tv mr-2 text-sm " + (currentRoute === "admin.transaksi.rincianbiayaperms.index" ? "opacity-75" : "text-blueGray-300")
                          }
                        ),
                        " ",
                        "Rincian Biaya"
                      ]
                    }
                  ) }),
                  /* @__PURE__ */ jsx("li", { className: "items-center px-2", children: /* @__PURE__ */ jsxs(
                    Link,
                    {
                      className: "text-xs uppercase py-3 font-bold block " + (currentRoute === "admin.transaksi.biayaperms.create" ? " text-lightBlue-500 hover:text-lightBlue-600 " : " text-blueGray-700 hover:text-blueGray-500 "),
                      href: route(
                        "admin.transaksi.biayaperms.create"
                      ),
                      children: [
                        /* @__PURE__ */ jsx(
                          "i",
                          {
                            className: "fas fa-tv mr-2 text-sm " + (currentRoute === "admin.transaksi.biayaperms.create" ? "opacity-75" : "text-blueGray-300")
                          }
                        ),
                        " ",
                        "Biaya Permohonan"
                      ]
                    }
                  ) }),
                  /* @__PURE__ */ jsx("li", { className: "items-center px-2", children: /* @__PURE__ */ jsxs(
                    Link,
                    {
                      className: "text-xs uppercase py-3 font-bold block " + (currentRoute === "admin.transaksi.kasbons.index" ? " text-lightBlue-500 hover:text-lightBlue-600 " : " text-blueGray-700 hover:text-blueGray-500 "),
                      href: route(
                        "admin.transaksi.kasbons.index"
                      ),
                      children: [
                        /* @__PURE__ */ jsx(
                          "i",
                          {
                            className: "fas fa-tv mr-2 text-sm " + (currentRoute === "admin.transaksi.kasbons.index" ? "opacity-75" : "text-blueGray-300")
                          }
                        ),
                        " ",
                        "Kasbon"
                      ]
                    }
                  ) }),
                  /* @__PURE__ */ jsx("li", { className: "items-center px-2 flex flex-row gap-2", children: /* @__PURE__ */ jsxs(
                    Link,
                    {
                      className: "text-xs uppercase py-3 font-bold flex items-center " + (currentRoute === "admin.transaksi.keluarbiayapermusers.index" ? " text-lightBlue-500 hover:text-lightBlue-600 " : " text-blueGray-700 hover:text-blueGray-500 "),
                      href: route(
                        "admin.transaksi.keluarbiayapermusers.index"
                      ),
                      children: [
                        /* @__PURE__ */ jsx(
                          "i",
                          {
                            className: "fas fa-tv mr-2 text-sm " + (currentRoute === "admin.transaksi.keluarbiayapermusers.index" ? "opacity-75" : "text-blueGray-300")
                          }
                        ),
                        /* @__PURE__ */ jsxs("span", { children: [
                          /* @__PURE__ */ jsx("span", { className: "inline-block", children: "Pengeluaran" }),
                          /* @__PURE__ */ jsx("span", { className: "inline-block", children: "Biaya Permohonan" })
                        ] })
                      ]
                    }
                  ) }),
                  /* @__PURE__ */ jsx("li", { className: "items-center px-2", children: /* @__PURE__ */ jsxs(
                    Link,
                    {
                      className: "text-xs uppercase py-3 font-bold flex items-center " + (currentRoute === "admin.transaksi.keluarbiayas.index" ? " text-lightBlue-500 hover:text-lightBlue-600 " : " text-blueGray-700 hover:text-blueGray-500 "),
                      href: route(
                        "admin.transaksi.keluarbiayas.index"
                      ),
                      children: [
                        /* @__PURE__ */ jsx(
                          "i",
                          {
                            className: "fas fa-tv mr-2 text-sm " + (currentRoute === "admin.transaksi.keluarbiayas.index" ? "opacity-75" : "text-blueGray-300")
                          }
                        ),
                        /* @__PURE__ */ jsx("span", { className: "inline-block", children: "Pengeluaran Biaya" })
                      ]
                    }
                  ) }),
                  /* @__PURE__ */ jsx("li", { className: "items-center px-2", children: /* @__PURE__ */ jsxs(
                    Link,
                    {
                      className: "text-xs uppercase py-3 font-bold flex items-center " + (currentRoute === "admin.transaksi.postingjurnals.index" ? " text-lightBlue-500 hover:text-lightBlue-600 " : " text-blueGray-700 hover:text-blueGray-500 "),
                      href: route(
                        "admin.transaksi.postingjurnals.index"
                      ),
                      children: [
                        /* @__PURE__ */ jsx(
                          "i",
                          {
                            className: "fas fa-tv mr-2 text-sm " + (currentRoute === "admin.transaksi.postingjurnals.index" ? "opacity-75" : "text-blueGray-300")
                          }
                        ),
                        /* @__PURE__ */ jsx("span", { className: "inline-block", children: "Posting Jurnal" })
                      ]
                    }
                  ) }),
                  /* @__PURE__ */ jsx("li", { className: "items-center px-2", children: /* @__PURE__ */ jsxs(
                    Link,
                    {
                      className: "text-xs uppercase py-3 font-bold flex items-center " + (currentRoute === "admin.transaksi.events.index" ? " text-lightBlue-500 hover:text-lightBlue-600 " : " text-blueGray-700 hover:text-blueGray-500 "),
                      href: route(
                        "admin.transaksi.events.index"
                      ),
                      children: [
                        /* @__PURE__ */ jsx(
                          "i",
                          {
                            className: "fas fa-tv mr-2 text-sm " + (currentRoute === "admin.transaksi.events.index" ? "opacity-75" : "text-blueGray-300")
                          }
                        ),
                        /* @__PURE__ */ jsx("span", { className: "inline-block", children: "Event" })
                      ]
                    }
                  ) })
                ]
              }
            ),
            /* @__PURE__ */ jsxs(
              MenuItem,
              {
                expanded: currentRoute ? currentRoute.includes("informasi") : false,
                label: "Informasi",
                children: [
                  /* @__PURE__ */ jsx("li", { className: "items-center px-2", children: /* @__PURE__ */ jsxs(
                    Link,
                    {
                      className: "text-xs uppercase py-3 font-bold block " + (currentRoute === "admin.informasi.prosespermohonans.index" ? " text-lightBlue-500 hover:text-lightBlue-600" : " text-blueGray-700 hover:text-blueGray-500"),
                      href: route(
                        "admin.informasi.prosespermohonans.index"
                      ),
                      children: [
                        /* @__PURE__ */ jsx(
                          "i",
                          {
                            className: "fas fa-tv mr-2 text-sm " + (currentRoute === "admin.informasi.prosespermohonans.index" ? "opacity-75" : "text-blueGray-300")
                          }
                        ),
                        " ",
                        "Proses Permohonan"
                      ]
                    }
                  ) }),
                  /* @__PURE__ */ jsxs("li", { className: "items-center px-2", children: [
                    /* @__PURE__ */ jsxs(
                      Link,
                      {
                        className: "text-xs uppercase py-3 font-bold block " + (currentRoute === "admin.informasi.prosespermohonans.bypermohonan" ? " text-lightBlue-500 hover:text-lightBlue-600" : " text-blueGray-700 hover:text-blueGray-500"),
                        href: route(
                          "admin.informasi.prosespermohonans.bypermohonan"
                        ),
                        children: [
                          /* @__PURE__ */ jsx(
                            "i",
                            {
                              className: "fas fa-tv mr-2 text-sm " + (currentRoute === "admin.informasi.prosespermohonans.bypermohonan" ? "opacity-75" : "text-blueGray-300")
                            }
                          ),
                          " ",
                          "Proses By Permohonan"
                        ]
                      }
                    ),
                    /* @__PURE__ */ jsxs(
                      Link,
                      {
                        className: "text-xs uppercase py-3 font-bold block " + (currentRoute === "admin.informasi.keuangans.keluarbiayas" ? " text-lightBlue-500 hover:text-lightBlue-600" : " text-blueGray-700 hover:text-blueGray-500"),
                        href: route(
                          "admin.informasi.keuangans.keluarbiayas"
                        ),
                        children: [
                          /* @__PURE__ */ jsx(
                            "i",
                            {
                              className: "fas fa-tv mr-2 text-sm " + (currentRoute === "admin.informasi.keuangans.keluarbiayas" ? "opacity-75" : "text-blueGray-300")
                            }
                          ),
                          " ",
                          "Pengeluaran Biaya"
                        ]
                      }
                    ),
                    /* @__PURE__ */ jsxs(
                      Link,
                      {
                        className: "text-xs uppercase py-3 font-bold flex items-center" + (currentRoute === "admin.informasi.keuangans.keluarbiayapermusers" ? " text-lightBlue-500 hover:text-lightBlue-600" : " text-blueGray-700 hover:text-blueGray-500"),
                        href: route(
                          "admin.informasi.keuangans.keluarbiayapermusers"
                        ),
                        children: [
                          /* @__PURE__ */ jsx(
                            "i",
                            {
                              className: "fas fa-tv mr-2 text-sm " + (currentRoute === "admin.informasi.keuangans.keluarbiayapermusers" ? "opacity-75" : "text-blueGray-300")
                            }
                          ),
                          " ",
                          /* @__PURE__ */ jsxs("span", { className: "flex flex-col", children: [
                            /* @__PURE__ */ jsx("span", { children: "Pengeluaran" }),
                            /* @__PURE__ */ jsx("span", { children: "Biaya Permohonan" })
                          ] })
                        ]
                      }
                    )
                  ] }),
                  /* @__PURE__ */ jsxs(MenuItem, { expanded: true, label: "Keuangan", children: [
                    /* @__PURE__ */ jsx("li", { className: "items-center px-2", children: /* @__PURE__ */ jsxs(
                      Link,
                      {
                        className: "text-xs uppercase py-3 font-bold block " + (currentRoute === "admin.informasi.keuangans.bukubesar" ? " text-lightBlue-500 hover:text-lightBlue-600" : " text-blueGray-700 hover:text-blueGray-500"),
                        href: route(
                          "admin.informasi.keuangans.bukubesar"
                        ),
                        children: [
                          /* @__PURE__ */ jsx(
                            "i",
                            {
                              className: "fas fa-tv mr-2 text-sm " + (currentRoute === "admin.informasi.keuangans.bukubesar" ? "opacity-75" : "text-blueGray-300")
                            }
                          ),
                          " ",
                          "Buku Besar"
                        ]
                      }
                    ) }),
                    /* @__PURE__ */ jsx("li", { className: "items-center px-2", children: /* @__PURE__ */ jsxs(
                      Link,
                      {
                        className: "text-xs uppercase py-3 font-bold block " + (currentRoute === "admin.informasi.keuangans.neraca" ? " text-lightBlue-500 hover:text-lightBlue-600" : " text-blueGray-700 hover:text-blueGray-500"),
                        href: route(
                          "admin.informasi.keuangans.neraca"
                        ),
                        children: [
                          /* @__PURE__ */ jsx(
                            "i",
                            {
                              className: "fas fa-tv mr-2 text-sm " + (currentRoute === "admin.informasi.keuangans.neraca" ? "opacity-75" : "text-blueGray-300")
                            }
                          ),
                          " ",
                          "Neraca"
                        ]
                      }
                    ) }),
                    /* @__PURE__ */ jsx("li", { className: "items-center px-2", children: /* @__PURE__ */ jsxs(
                      Link,
                      {
                        className: "text-xs uppercase py-3 font-bold block " + (currentRoute === "admin.informasi.statusbiayaperms" ? " text-lightBlue-500 hover:text-lightBlue-600" : " text-blueGray-700 hover:text-blueGray-500"),
                        href: route(
                          "admin.informasi.statusbiayaperms"
                        ),
                        children: [
                          /* @__PURE__ */ jsx(
                            "i",
                            {
                              className: "fas fa-tv mr-2 text-sm " + (currentRoute === "admin.informasi.statusbiayaperms" ? "opacity-75" : "text-blueGray-300")
                            }
                          ),
                          " ",
                          "Biaya Permohonan"
                        ]
                      }
                    ) })
                  ] })
                ]
              }
            ),
            /* @__PURE__ */ jsx(
              MenuItem,
              {
                expanded: currentRoute ? currentRoute.includes("utils") : false,
                label: "Utility",
                children: /* @__PURE__ */ jsx("li", { className: "items-center px-2", children: /* @__PURE__ */ jsxs(
                  Link,
                  {
                    className: "text-xs uppercase py-3 font-bold block " + (currentRoute === "admin.utils.backupdb" ? " text-lightBlue-500 hover:text-lightBlue-600" : " text-blueGray-700 hover:text-blueGray-500"),
                    href: route("admin.utils.backupdb"),
                    children: [
                      /* @__PURE__ */ jsx(
                        "i",
                        {
                          className: "fas fa-tv mr-2 text-sm " + (currentRoute === "admin.utils.backupdb" ? "opacity-75" : "text-blueGray-300")
                        }
                      ),
                      " ",
                      "Backup Database"
                    ]
                  }
                ) })
              }
            )
          ] })
        ]
      }
    )
  ] }) }) });
}
const AdminLayout = ({
  children
}) => {
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx(Sidebar, {}),
    /* @__PURE__ */ jsxs("div", { className: "relative md:ml-64 ", children: [
      /* @__PURE__ */ jsx(Navbar, {}),
      /* @__PURE__ */ jsx(HeaderBlank, {}),
      /* @__PURE__ */ jsxs("div", { className: "px-4 md:px-10 mx-auto w-full -m-40 relative h-full", children: [
        /* @__PURE__ */ jsx(ToastMessages, {}),
        children
      ] })
    ] })
  ] });
};
const AdminLayout$1 = AdminLayout;
export {
  AdminLayout$1 as A
};
