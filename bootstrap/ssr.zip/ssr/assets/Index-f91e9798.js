import { jsx, Fragment, jsxs } from "react/jsx-runtime";
import { A as AdminLayout } from "./AdminLayout-4bc80775.js";
import { useState, useEffect } from "react";
import { twMerge } from "tailwind-merge";
import { usePage, router, Link } from "@inertiajs/react";
import { usePrevious } from "react-use";
import { pickBy } from "lodash";
import { u as useSwal } from "./useSwal-5d61a319.js";
import { P as Pagination } from "./Pagination-30af682d.js";
import { L as LinkButton } from "./LinkButton-a291522b.js";
import { A as AsyncSelectSearch } from "./AsyncSelectSearch-23c2f5cb.js";
import { P as PopupMenu } from "./PopupMenu-b5bc7ace.js";
import { S as SelectSearch } from "./SelectSearch-22ab8168.js";
import { M as MonthRangeInput, I as InputWithSelect } from "./MonthRangeInput-91eefd29.js";
import moment from "moment";
import { M as MenuDropdown } from "./MenuDropdown-419bd59d.js";
import { c as copyToClipboard } from "./index-d9460823.js";
import { Tooltip } from "react-tooltip";
import "./NotificationDropdown-abde11b8.js";
import "@popperjs/core";
import "./ResponsiveNavLink-41b4fa07.js";
import "react-hot-toast";
import "./AuthContext-5300e6b5.js";
import "firebase/app";
import "firebase/auth";
import "firebase/firestore";
import "firebase/storage";
import "./bootstrap-b9d9b211.js";
import "axios";
import "firebase/messaging";
import "./MenuItem-f3c50e94.js";
import "sweetalert2";
import "classnames";
import "react-select/async";
import "@headlessui/react";
import "@heroicons/react/20/solid";
import "react-select";
import "react-datepicker";
/* empty css                           */import "./Button-e2b11bd9.js";
function CardTablePermohonans({
  color = "light",
  jenishaks,
  permohonans,
  className = "",
  meta,
  labelLinks
}) {
  const params = new URLSearchParams(window.location.search);
  const {
    jenistanahs,
    jenispermohonans,
    desa,
    inactive,
    date1,
    date2,
    userOpts
  } = usePage().props;
  const [values, setValues] = useState({
    date1: params.get("date1") ? params.get("date1") : date1,
    date2: params.get("date2") ? params.get("date2") : date2,
    inactive: params.get("inactive"),
    search_key: params.get("search_key"),
    jenis_tanah: params.get("jenis_tanah"),
    search: params.get("search"),
    jenishak_id: params.get("jenishak_id"),
    jenispermohonan_id: params.get("jenispermohonan_id"),
    sortBy: params.get("sortBy"),
    sortDir: params.get("sortDir"),
    user_id: params.get("user_id")
  });
  const xuser = userOpts.find((usr) => usr.value == values.user_id);
  const [cuser, setCuser] = useState(xuser);
  const prevValues = usePrevious(values);
  function handleSortLinkClick({
    sortBy,
    sortDir
  }) {
    setValues((values2) => ({ ...values2, sortBy, sortDir }));
  }
  const IconSort = ({
    sortBy,
    sortDir
  }) => {
    if (values.sortBy === sortBy && sortDir === "asc") {
      return /* @__PURE__ */ jsx("i", { className: "fa-solid fa-sort-up" });
    } else if (values.sortBy === sortBy && sortDir === "desc") {
      return /* @__PURE__ */ jsx("i", { className: "fa-solid fa-sort-down" });
    }
    return /* @__PURE__ */ jsx("i", { className: "fa-solid fa-sort" });
  };
  const jenishak = jenishaks.find((e) => e.value === values.jenishak_id);
  const selectedDesa = desa ? desa : {};
  jenispermohonans.find(
    (e) => e.value === values.jenispermohonan_id
  );
  const jenistanah = jenistanahs.find(
    (e) => e.value === values.jenis_tanah
  );
  const handleRemoveData = (id) => {
    router.delete(route("admin.permohonans.destroy", id));
  };
  const [isChecked, setIsChecked] = useState(inactive);
  const handleDateChange = (dates) => {
    setValues((v) => ({ ...v, date1: dates.date1, date2: dates.date2 }));
  };
  useEffect(() => {
    if (prevValues) {
      const query = Object.keys(pickBy(values)).length ? pickBy(values) : {};
      router.get(
        route(route().current() ? route().current() + "" : ""),
        query,
        {
          replace: true,
          preserveState: true
        }
      );
    }
  }, [values]);
  return /* @__PURE__ */ jsx(Fragment, { children: /* @__PURE__ */ jsxs(
    "div",
    {
      className: twMerge(
        "relative flex flex-col min-w-0 break-words w-full mb-6 shadow-lg shadow-slate-700 rounded-md py-1 ",
        color === "light" ? "bg-white" : "bg-lightBlue-900 text-white",
        className
      ),
      children: [
        /* @__PURE__ */ jsx("div", { className: "rounded-full mb-0 px-4 py-3 border-0 ", children: /* @__PURE__ */ jsxs("div", { className: "flex justify-between w-full flex-col md:flex-row gap-1", children: [
          /* @__PURE__ */ jsx("div", { className: "relative w-full max-w-full flex-grow flex-1 ", children: /* @__PURE__ */ jsx(
            "h3",
            {
              className: "font-semibold text-lg " + (color === "light" ? "text-blueGray-700" : "text-white"),
              children: "Permohonan List"
            }
          ) }),
          /* @__PURE__ */ jsxs("div", { className: "flex flex-col md:flex-row justify-center gap-1 items-start", children: [
            /* @__PURE__ */ jsxs("div", { className: "mb-2 w-full flex flex-row items-center", children: [
              /* @__PURE__ */ jsxs(PopupMenu, { caption: "Filter", children: [
                /* @__PURE__ */ jsx(
                  MonthRangeInput,
                  {
                    label: "Rentang Waktu",
                    onDataChange: (d) => handleDateChange(d),
                    value: {
                      date1: values.date1 ? values.date1 : moment().format("YYYY-MM-DD"),
                      date2: values.date2 ? values.date2 : moment().format("YYYY-MM-DD")
                    }
                  }
                ),
                /* @__PURE__ */ jsx(
                  SelectSearch,
                  {
                    className: "text-blueGray-900",
                    isClearable: true,
                    value: jenishak ? jenishak : "",
                    options: jenishaks,
                    label: "Jenis Hak",
                    onChange: (e) => setValues((v) => ({
                      ...v,
                      jenishak_id: e ? e.value : ""
                    }))
                  }
                ),
                /* @__PURE__ */ jsx(
                  SelectSearch,
                  {
                    className: "text-blueGray-900",
                    isClearable: true,
                    value: jenistanah,
                    options: jenistanahs,
                    label: "Jenis Tanah",
                    onChange: (e) => setValues((v) => ({
                      ...v,
                      jenis_tanah: e ? e.value : ""
                    }))
                  }
                ),
                /* @__PURE__ */ jsx(
                  AsyncSelectSearch,
                  {
                    url: "/admin/desas/api/list",
                    className: "text-blueGray-900",
                    value: selectedDesa,
                    optionLabels: [
                      "nama_desa",
                      "nama_kecamatan"
                    ],
                    optionValue: "id",
                    isClearable: true,
                    label: "Letak Obyek",
                    onChange: (e) => setValues((v) => ({
                      ...v,
                      desa_id: e ? e.value : ""
                    }))
                  }
                )
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "p-1 flex items-center text-blueGray-200 gap-1", children: [
                /* @__PURE__ */ jsx("span", { children: "Active" }),
                /* @__PURE__ */ jsx(
                  "input",
                  {
                    type: "checkbox",
                    name: "inactive",
                    checked: isChecked,
                    onChange: (e) => setValues((v) => {
                      setIsChecked(!isChecked);
                      return {
                        ...v,
                        inactive: isChecked
                      };
                    })
                  }
                )
              ] })
            ] }),
            /* @__PURE__ */ jsx(
              SelectSearch,
              {
                name: "user_id",
                value: cuser,
                options: userOpts,
                placeholder: "Pilih Petugas",
                className: "text-gray-800",
                onChange: (e) => {
                  setValues((v) => ({
                    ...v,
                    user_id: e ? e.value : ""
                  }));
                  setCuser(e);
                }
              }
            ),
            /* @__PURE__ */ jsx(
              InputWithSelect,
              {
                comboboxValue: values.search_key ? values.search_key : "",
                onSelecChange: (e) => setValues((v) => ({
                  ...v,
                  search_key: e.value,
                  search: ""
                })),
                value: values.search ? values.search : "",
                onInputChange: (e, s) => {
                  setValues((v) => ({
                    ...v,
                    search_key: s,
                    search: e.target.value
                  }));
                }
              }
            ),
            /* @__PURE__ */ jsx(
              LinkButton,
              {
                theme: "blue",
                href: route("admin.permohonans.create"),
                children: /* @__PURE__ */ jsxs("span", { className: "flex items-center gap-1", children: [
                  /* @__PURE__ */ jsx("i", { className: "fa-solid fa-plus" }),
                  " New"
                ] })
              }
            )
          ] })
        ] }) }),
        /* @__PURE__ */ jsx("div", { className: "block w-full overflow-x-auto", children: /* @__PURE__ */ jsxs("table", { className: "items-center w-full bg-transparent border-collapse", children: [
          /* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", { children: [
            /* @__PURE__ */ jsx(
              "th",
              {
                className: "px-2 align-middle border border-solid py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left " + (color === "light" ? "bg-blueGray-50 text-blueGray-500 border-blueGray-100" : "bg-lightBlue-800 text-lightBlue-300 border-lightBlue-700"),
                children: /* @__PURE__ */ jsx(
                  Link,
                  {
                    href: "#",
                    onClick: (e) => handleSortLinkClick({
                      sortBy: "id",
                      sortDir: values.sortDir === "asc" ? "desc" : "asc"
                    }),
                    children: /* @__PURE__ */ jsxs("div", { className: "flex flex-row justify-between", children: [
                      /* @__PURE__ */ jsx("span", { children: "No Daftar" }),
                      /* @__PURE__ */ jsx(
                        IconSort,
                        {
                          sortBy: "id",
                          sortDir: values.sortDir || ""
                        }
                      )
                    ] })
                  }
                )
              }
            ),
            /* @__PURE__ */ jsx(
              "th",
              {
                className: "px-2 align-middle border border-solid py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left " + (color === "light" ? "bg-blueGray-50 text-blueGray-500 border-blueGray-100" : "bg-lightBlue-800 text-lightBlue-300 border-lightBlue-700"),
                children: /* @__PURE__ */ jsx(
                  Link,
                  {
                    href: "#",
                    onClick: (e) => handleSortLinkClick({
                      sortBy: "nama_pelepas",
                      sortDir: values.sortDir === "asc" ? "desc" : "asc"
                    }),
                    children: /* @__PURE__ */ jsxs("div", { className: "flex flex-row justify-between", children: [
                      /* @__PURE__ */ jsx("span", { children: "Nama Pelepas" }),
                      /* @__PURE__ */ jsx(
                        IconSort,
                        {
                          sortBy: "nama_pelepas",
                          sortDir: values.sortDir || ""
                        }
                      )
                    ] })
                  }
                )
              }
            ),
            /* @__PURE__ */ jsx(
              "th",
              {
                className: "px-2 align-middle border border-solid py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left " + (color === "light" ? "bg-blueGray-50 text-blueGray-500 border-blueGray-100" : "bg-lightBlue-800 text-lightBlue-300 border-lightBlue-700"),
                children: /* @__PURE__ */ jsx(
                  Link,
                  {
                    href: "#",
                    onClick: (e) => handleSortLinkClick({
                      sortBy: "nama_penerima",
                      sortDir: values.sortDir === "asc" ? "desc" : "asc"
                    }),
                    children: /* @__PURE__ */ jsxs("div", { className: "flex flex-row justify-between", children: [
                      /* @__PURE__ */ jsx("span", { children: "Nama Penerima" }),
                      /* @__PURE__ */ jsx(
                        IconSort,
                        {
                          sortBy: "nama_penerima",
                          sortDir: values.sortDir || ""
                        }
                      )
                    ] })
                  }
                )
              }
            ),
            /* @__PURE__ */ jsx(
              "th",
              {
                className: "px-2 align-middle border border-solid py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left " + (color === "light" ? "bg-blueGray-50 text-blueGray-500 border-blueGray-100" : "bg-lightBlue-800 text-lightBlue-300 border-lightBlue-700"),
                children: "No Hak"
              }
            ),
            /* @__PURE__ */ jsx(
              "th",
              {
                className: "px-2 align-middle border border-solid py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left " + (color === "light" ? "bg-blueGray-50 text-blueGray-500 border-blueGray-100" : "bg-lightBlue-800 text-lightBlue-300 border-lightBlue-700"),
                children: "Luas M2"
              }
            ),
            /* @__PURE__ */ jsx(
              "th",
              {
                className: "px-2 align-middle border border-solid py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left " + (color === "light" ? "bg-blueGray-50 text-blueGray-500 border-blueGray-100" : "bg-lightBlue-800 text-lightBlue-300 border-lightBlue-700"),
                children: "Letak Obyek"
              }
            ),
            /* @__PURE__ */ jsx(
              "th",
              {
                className: "px-2 align-middle border border-solid py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left " + (color === "light" ? "bg-blueGray-50 text-blueGray-500 border-blueGray-100" : "bg-lightBlue-800 text-lightBlue-300 border-lightBlue-700"),
                children: "Transaksi"
              }
            ),
            /* @__PURE__ */ jsx(
              "th",
              {
                className: "px-2 align-middle border border-solid py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left " + (color === "light" ? "bg-blueGray-50 text-blueGray-500 border-blueGray-100" : "bg-lightBlue-800 text-lightBlue-300 border-lightBlue-700"),
                children: "Menu"
              }
            )
          ] }) }),
          /* @__PURE__ */ jsx("tbody", { children: permohonans.map(
            ({
              id,
              no_daftar,
              tgl_daftar,
              nama_pelepas,
              nama_penerima,
              nomor_hak,
              letak_obyek,
              luas_tanah,
              transpermohonans
            }, index) => /* @__PURE__ */ jsxs("tr", { children: [
              /* @__PURE__ */ jsxs("td", { className: "border-t-2 px-2 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-1", children: [
                /* @__PURE__ */ jsx("span", { children: no_daftar }),
                /* @__PURE__ */ jsx("div", { className: "text-xs italic text-yellow-500", children: tgl_daftar })
              ] }),
              /* @__PURE__ */ jsx("td", { className: "border-t-2 px-2 align-middle border-l-0 border-r-0 text-xs whitespace-pre-wrap p-1", children: nama_pelepas }),
              /* @__PURE__ */ jsx("td", { className: "border-t-2 px-2 align-middle border-l-0 border-r-0 text-xs whitespace-pre-wrap p-1", children: nama_penerima }),
              /* @__PURE__ */ jsx("td", { className: "border-t-2 px-2 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-1", children: nomor_hak }),
              /* @__PURE__ */ jsx("td", { className: "border-t-2 px-2 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-1", children: luas_tanah }),
              /* @__PURE__ */ jsx("td", { className: "border-t-2 px-2 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-1", children: letak_obyek }),
              /* @__PURE__ */ jsx("td", { className: "border-t-2 px-2 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-1", children: /* @__PURE__ */ jsx("ol", { children: transpermohonans.map(
                (tp, idx) => /* @__PURE__ */ jsxs(
                  "li",
                  {
                    className: "rounded-full bg-white/50 text-center mb-1",
                    children: [
                      /* @__PURE__ */ jsx(
                        Tooltip,
                        {
                          id: `tooltip_${idx}`
                        }
                      ),
                      /* @__PURE__ */ jsxs(
                        "span",
                        {
                          "data-tooltip-id": `tooltip_${idx}`,
                          "data-tooltip-content": "Copy No Daftar",
                          "data-tooltip-place": "top",
                          onClick: () => copyToClipboard(
                            tp.no_daftar
                          ),
                          className: "hover:cursor-pointer hover:text-lightBlue-300",
                          children: [
                            tp.no_daftar,
                            " -",
                            " ",
                            tp.jenispermohonan.nama_jenispermohonan
                          ]
                        }
                      )
                    ]
                  },
                  idx
                )
              ) }) }),
              /* @__PURE__ */ jsx("td", { className: "border-t-2 px-2 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap py-3 ", children: /* @__PURE__ */ jsxs(MenuDropdown, { children: [
                /* @__PURE__ */ jsxs(
                  Link,
                  {
                    href: route(
                      "admin.permohonans.edit",
                      id
                    ),
                    className: "text-sm py-2 px-4 font-normal block w-full whitespace-nowrap bg-transparent text-blueGray-700 hover:text-blue-400 transition hover:scale-110 origin-top-left ",
                    type: "button",
                    children: [
                      /* @__PURE__ */ jsx("i", { className: "fas fa-edit" }),
                      /* @__PURE__ */ jsx("span", { children: " Edit" })
                    ]
                  }
                ),
                /* @__PURE__ */ jsxs(
                  "a",
                  {
                    href: "#",
                    onClick: (e) => {
                      e.preventDefault();
                      useSwal.confirm({
                        title: "Hapus Data",
                        text: "apakah akan menghapus?"
                      }).then((result) => {
                        if (result.isConfirmed) {
                          handleRemoveData(
                            id
                          );
                        }
                      });
                    },
                    className: "text-sm py-2 px-4 font-normal block w-full whitespace-nowrap bg-transparent text-blueGray-700 hover:text-blue-400 transition hover:scale-110 origin-top-left",
                    children: [
                      /* @__PURE__ */ jsx("i", { className: "fas fa-trash" }),
                      /* @__PURE__ */ jsx("span", { children: " Hapus" })
                    ]
                  }
                ),
                /* @__PURE__ */ jsxs(
                  Link,
                  {
                    href: route(
                      "admin.permohonans.qrcode.create",
                      id
                    ),
                    className: "text-sm py-2 px-4 font-normal block w-full whitespace-nowrap bg-transparent text-blueGray-700 hover:text-blue-400 transition hover:scale-110 origin-top-left ",
                    type: "button",
                    children: [
                      /* @__PURE__ */ jsx("i", { className: "fas fa-qrcode" }),
                      /* @__PURE__ */ jsx("span", { children: " Buat Qrcode" })
                    ]
                  }
                )
              ] }) })
            ] }, index)
          ) })
        ] }) }),
        meta.total > meta.per_page ? /* @__PURE__ */ jsx(
          "div",
          {
            className: "flex justify-end px-2 py-1  " + (color === "light" ? "bg-blueGray-50 text-blueGray-500 border-blueGray-100" : "bg-lightBlue-800 text-lightBlue-300 border-lightBlue-700"),
            children: /* @__PURE__ */ jsx(
              Pagination,
              {
                links: meta.links,
                labelLinks
              }
            )
          }
        ) : null
      ]
    }
  ) });
}
const Index = ({
  jenishaks,
  permohonans
}) => {
  const { data, meta, links } = permohonans;
  return /* @__PURE__ */ jsx(AdminLayout, { children: /* @__PURE__ */ jsx(
    CardTablePermohonans,
    {
      color: "dark",
      jenishaks,
      permohonans: data,
      meta,
      labelLinks: links
    }
  ) });
};
export {
  Index as default
};
