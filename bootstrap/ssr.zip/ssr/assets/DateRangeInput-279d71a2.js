import { jsxs, jsx } from "react/jsx-runtime";
import moment from "moment";
import { useState, useCallback } from "react";
import ReactDatePicker from "react-datepicker";
import { twMerge } from "tailwind-merge";
/* empty css                           */import { B as Button } from "./Button-e2b11bd9.js";
const DateRangeInput = ({
  onDataChange,
  className,
  errors,
  label,
  value
}) => {
  const renderMonthContent = (month = 0, shortMonth = "", longMonth = "", day = 0) => {
    const fullYear = new Date(day).getFullYear();
    const tooltipText = `Tooltip for month: ${longMonth} ${fullYear}`;
    return /* @__PURE__ */ jsx("span", { title: tooltipText, children: shortMonth });
  };
  const [dates, setDates] = useState({
    date1: value.date1 ? value.date1 : moment().format("YYYY-MM-DD"),
    date2: value.date2 ? value.date2 : moment().format("YYYY-MM-DD")
  });
  const handleChange = useCallback(
    (field, value2) => {
      setDates((d) => ({
        ...d,
        [field]: moment(value2).format("YYYY-MM-DD")
      }));
    },
    [dates]
  );
  return /* @__PURE__ */ jsxs("div", { className: twMerge("relative w-full text-black", className), children: [
    label && /* @__PURE__ */ jsx(
      "label",
      {
        className: `block uppercase text-blueGray-600 text-sm font-bold ${errors ? "text-red-500" : ""} `,
        children: label
      }
    ),
    /* @__PURE__ */ jsxs("div", { className: "flex flex-row gap-0 ", children: [
      /* @__PURE__ */ jsx(
        ReactDatePicker,
        {
          selected: moment(dates.date1).toDate(),
          value: moment(dates.date1).format("DD-MMM-YYYY"),
          renderMonthContent,
          dateFormat: "DD/MM/yyyy",
          className: " px-3 py-2 placeholder-blueGray-300 text-blueGray-600 border-blueGray-300 bg-white rounded-l-md text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150",
          onChange: (e) => handleChange("date1", moment(e).toISOString())
        }
      ),
      /* @__PURE__ */ jsx(
        ReactDatePicker,
        {
          selected: moment(dates.date2).toDate(),
          value: moment(dates.date2).format("DD-MMM-YYYY"),
          renderMonthContent,
          dateFormat: "DD/MM/yyyy",
          className: "px-3 py-2 placeholder-blueGray-300 text-blueGray-600 border-blueGray-300 bg-white text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150",
          onChange: (e) => handleChange("date2", moment(e).toISOString())
        }
      ),
      /* @__PURE__ */ jsx(
        Button,
        {
          theme: "blue",
          className: "text-sm rounded-r-md py-2",
          onClick: (e) => onDataChange(dates),
          children: /* @__PURE__ */ jsx("i", { className: "fa-solid fa-magnifying-glass" })
        }
      )
    ] })
  ] });
};
export {
  DateRangeInput as D
};
