import { jsxs, jsx } from "react/jsx-runtime";
import React, { useRef, useState, useEffect } from "react";
import { B as Button } from "./Button-e2b11bd9.js";
import { ref, uploadBytesResumable, getDownloadURL, deleteObject } from "firebase/storage";
import { u as useAuth, s as storage } from "./AuthContext-5300e6b5.js";
import Resizer from "react-image-file-resizer";
import { usePage } from "@inertiajs/react";
import { M as Modal } from "./Modal-d06b3568.js";
import { L as LinkButton } from "./LinkButton-a291522b.js";
function resizeImage(file, newWidth, newHeight) {
  return new Promise((resolve, reject) => {
    Resizer.imageFileResizer(
      file,
      newWidth,
      newHeight,
      "jpeg",
      100,
      0,
      (uri) => {
        resolve(uri);
      },
      "file"
    );
  });
}
const CameraWithCapture = ({ uploadImage, getMediaStream }) => {
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const [imageData, setImageData] = useState(null);
  const [videoStream, setVideoStream] = useState();
  const [columns, setColumns] = useState([]);
  const [selectedDeviceId, setSelectedDeviceId] = useState(
    null
  );
  async function startCamera(deviceId) {
    const stream = await navigator.mediaDevices.getUserMedia({
      video: {
        deviceId
      },
      audio: false
    });
    if (videoRef.current) {
      videoRef.current.srcObject = stream;
      getMediaStream(stream);
      setVideoStream(stream);
    }
  }
  async function getDevices(devices) {
    const cols = [];
    devices.forEach((device) => {
      if (device.kind === "videoinput") {
        cols.push({
          label: device.label,
          deviceId: device.deviceId
        });
      }
    });
    setColumns(cols);
    if (!selectedDeviceId) {
      setSelectedDeviceId(cols[0].deviceId);
    }
    return cols;
  }
  useEffect(() => {
    (async () => {
      await navigator.mediaDevices.getUserMedia({
        audio: false,
        video: true
      });
      let devices = await navigator.mediaDevices.enumerateDevices();
      getDevices(devices);
    })();
    if (selectedDeviceId) {
      startCamera(selectedDeviceId);
    }
    return () => {
    };
  }, [selectedDeviceId]);
  const capturePhoto = () => {
    if (!canvasRef.current || !videoRef.current)
      return;
    const context = canvasRef.current.getContext("2d");
    if (context) {
      context.drawImage(videoRef.current, 0, 0, 640, 480);
      const dataUrl = canvasRef.current.toDataURL("image/png");
      const byteString = atob(dataUrl.split(",")[1]);
      const mimeString = dataUrl.split(",")[0].split(":")[1].split(";")[0];
      const ab = new ArrayBuffer(byteString.length);
      const ia = new Uint8Array(ab);
      for (let i = 0; i < byteString.length; i++) {
        ia[i] = byteString.charCodeAt(i);
      }
      const blob = new Blob([ab], { type: mimeString });
      const imgfile = blobToFile(blob, "photo.png");
      uploadImage(imgfile);
    }
  };
  function blobToFile(blob, fileName) {
    return new File([blob], fileName, { type: blob.type });
  }
  const handleUploadImage = () => {
    if (!imageData)
      return;
    const byteString = atob(imageData.split(",")[1]);
    const mimeString = imageData.split(",")[0].split(":")[1].split(";")[0];
    const ab = new ArrayBuffer(byteString.length);
    const ia = new Uint8Array(ab);
    for (let i = 0; i < byteString.length; i++) {
      ia[i] = byteString.charCodeAt(i);
    }
    const blob = new Blob([ab], { type: mimeString });
    const imgfile = blobToFile(blob, "photo.png");
    uploadImage(imgfile);
  };
  return /* @__PURE__ */ jsxs("div", { children: [
    /* @__PURE__ */ jsx(
      "video",
      {
        ref: videoRef,
        autoPlay: true,
        playsInline: true,
        className: "object-cover border-2 border-black w-full h-full"
      }
    ),
    /* @__PURE__ */ jsxs("div", { className: "p-2 flex flex-col md:flex-row justify-between gap-2", children: [
      /* @__PURE__ */ jsx(
        "select",
        {
          className: "block w-full md:w-2/3 appearance-none text-sm bg-white border border-gray-400 hover:border-gray-500 px-4 py-2 pr-8 rounded shadow leading-tight focus:outline-none focus:shadow-outline",
          value: selectedDeviceId ?? "",
          onChange: (e) => setSelectedDeviceId(e.target.value),
          children: columns && columns.map((col) => /* @__PURE__ */ jsx("option", { value: col.deviceId, children: col.label }, col.deviceId))
        }
      ),
      /* @__PURE__ */ jsx(
        Button,
        {
          theme: "black",
          className: "w-full md:w-1/3",
          onClick: capturePhoto,
          children: "Ambil Foto"
        }
      )
    ] }),
    /* @__PURE__ */ jsx(
      "canvas",
      {
        ref: canvasRef,
        width: 640,
        height: 480,
        style: { display: "none" }
      }
    ),
    imageData && /* @__PURE__ */ jsx("div", { style: { marginTop: "20px" }, children: /* @__PURE__ */ jsx("div", { style: { marginTop: "10px" }, children: /* @__PURE__ */ jsx(
      "button",
      {
        onClick: handleUploadImage,
        style: { marginLeft: "10px" },
        children: "☁️ Upload"
      }
    ) }) })
  ] });
};
const ModalTakePicture = ({ showModal, setShowModal, uploadImage }) => {
  const [videoStream, setVideoStream] = useState();
  const getMediaStream = (vs) => {
    setVideoStream(vs);
  };
  const stopCamera = async () => {
    if (videoStream) {
      videoStream.getTracks().forEach((track) => {
        if (track.readyState === "live") {
          track.stop();
        }
      });
    }
  };
  const handleClose = () => {
    stopCamera();
    setShowModal(false);
  };
  return /* @__PURE__ */ jsx(
    Modal,
    {
      show: showModal,
      maxWidth: "md",
      closeable: true,
      onClose: handleClose,
      children: /* @__PURE__ */ jsxs("div", { className: "p-2 bg-blueGray-100 rounded-md ", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex flex-col justify-between items-start", children: [
          /* @__PURE__ */ jsx("h1", { className: "font-bold text-sm text-blueGray-700 mb-2", children: "Capture Image" }),
          /* @__PURE__ */ jsx("div", { className: "w-full h-auto flex justify-between items-center p-1 flex-wrap gap-1 border border-gray-300 rounded-md bg-gray-100 ", children: /* @__PURE__ */ jsx(
            CameraWithCapture,
            {
              getMediaStream,
              uploadImage: (f) => {
                stopCamera();
                setShowModal(false);
                uploadImage(f);
              }
            }
          ) })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "mt-2 w-full flex justify-start items-center", children: [
          /* @__PURE__ */ jsx("span", {}),
          /* @__PURE__ */ jsx(
            LinkButton,
            {
              href: "#",
              theme: "blue",
              onClick: (e) => {
                e.preventDefault();
                handleClose();
              },
              children: /* @__PURE__ */ jsx("span", { children: "Close" })
            }
          )
        ] })
      ] })
    }
  );
};
const UploadImage = React.forwardRef(
  ({ label, errors, name, image, setImage, imagePath, ...props }, ref$1) => {
    const [imageUpload, setImageUpload] = useState(null);
    const [uploadProgress, setUploadProgress] = useState();
    const [showTakePicture, setShowTakePicture] = useState(false);
    const uploadFile = async () => {
      if (imageUpload == null)
        return;
      const newImg = await resizeImage(imageUpload, 500, 500);
      let rand = Math.random() * 1e5;
      const imageRef = ref(
        storage,
        `${imagePath}${rand.toFixed()}_${imageUpload.name}`
      );
      const uploadTask = uploadBytesResumable(imageRef, newImg);
      uploadTask.on(
        "state_changed",
        (snapshot) => {
          const progress = snapshot.bytesTransferred / snapshot.totalBytes * 100;
          setUploadProgress(progress);
          switch (snapshot.state) {
            case "paused":
              console.log("Upload is paused");
              break;
            case "running":
              console.log("Upload is running");
              break;
          }
        },
        (error) => {
        },
        () => {
          getDownloadURL(uploadTask.snapshot.ref).then(
            (downloadURL) => {
              setImage(downloadURL);
              setUploadProgress(null);
              setImageUpload(null);
            }
          );
        }
      );
    };
    const deleteFile = async (imageUrl) => {
      const imageRef = ref(storage, imageUrl);
      deleteObject(imageRef).then(() => {
        setImageUpload(null);
        setImage("");
        console.log("image deleted from firebase");
      }).catch((error) => {
        console.log("error delete : ", error);
      });
    };
    const { currentUser, login, logout } = useAuth();
    const { fbtoken } = usePage().props;
    useEffect(() => {
      if (!currentUser) {
        login(fbtoken);
      }
      return () => {
        if (currentUser) {
          console.log("logout firebase");
          logout();
        }
      };
    }, []);
    return /* @__PURE__ */ jsxs("div", { className: "w-full grid grid-cols-2 grid-rows-1 gap-2 row-span-2 mb-2", children: [
      /* @__PURE__ */ jsx(
        "input",
        {
          type: "file",
          ref: ref$1,
          tabIndex: -1,
          name: "imageUpload",
          className: "h-9 w-full text-gray-400 font-semibold text-sm bg-white border file:cursor-pointer cursor-pointer file:border-0 file:py-0 file:px-3 file:mr-4 file:bg-gray-100 file:hover:bg-gray-200 file:text-gray-500 rounded file:h-full",
          onChange: (e) => setImageUpload(e.target.files[0])
        }
      ),
      /* @__PURE__ */ jsxs("div", { className: "flex flex-col justify-start gap-1 items-start ", children: [
        /* @__PURE__ */ jsx(
          Button,
          {
            tabIndex: -1,
            name: "takePictureBtn",
            type: "button",
            theme: "blueGrey",
            className: "h-9",
            onClick: () => setShowTakePicture(true),
            children: /* @__PURE__ */ jsx("i", { className: "fas fa-camera" })
          }
        ),
        imageUpload ? /* @__PURE__ */ jsx(
          Button,
          {
            tabIndex: -1,
            name: "upload",
            type: "button",
            theme: "blueGrey",
            className: "h-9",
            onClick: uploadFile,
            children: /* @__PURE__ */ jsx("i", { className: "fas fa-upload" })
          }
        ) : null,
        image ? /* @__PURE__ */ jsxs("div", { className: "flex flex-col justify-between items-start", children: [
          /* @__PURE__ */ jsx("div", { className: "flex flex-wrap justify-center", children: /* @__PURE__ */ jsx("div", { className: "w-full group rounded-lg bg-gray-400 overflow-hidden border-2 cursor-pointer", children: /* @__PURE__ */ jsx(
            "img",
            {
              src: image,
              alt: "...",
              className: "shadow rounded max-w-full h-auto align-middle border-none transition-all group-hover:scale-110 group-hover:bg-gray-600"
            }
          ) }) }),
          /* @__PURE__ */ jsx(
            Button,
            {
              name: "upload",
              type: "button",
              tabIndex: -1,
              className: "h-9 mt-2 absolute ml-2",
              theme: "black",
              onClick: () => deleteFile(image),
              children: /* @__PURE__ */ jsx("i", { className: "fas fa-trash" })
            }
          )
        ] }) : null
      ] }),
      uploadProgress && /* @__PURE__ */ jsxs("progress", { value: uploadProgress, max: "100", children: [
        uploadProgress,
        "%"
      ] }),
      /* @__PURE__ */ jsx(
        ModalTakePicture,
        {
          showModal: showTakePicture,
          setShowModal: setShowTakePicture,
          uploadImage: setImageUpload
        }
      )
    ] });
  }
);
export {
  UploadImage as U
};
