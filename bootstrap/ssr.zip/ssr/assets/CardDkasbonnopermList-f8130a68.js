import { jsxs, jsx } from "react/jsx-runtime";
import { P as Pagination } from "./Pagination-30af682d.js";
import { u as useSwal } from "./useSwal-5d61a319.js";
import { usePage, router } from "@inertiajs/react";
const CardDkasbonList = ({ kasbon }) => {
  const {
    dkasbons: { data, links, meta },
    base_route
  } = usePage().props;
  const handleRemoveData = (id) => {
    router.delete(route(base_route + "transaksi.dkasbons.destroy", id));
  };
  return /* @__PURE__ */ jsxs("div", { className: "w-full mt-4 flex flex-col mb-2", children: [
    /* @__PURE__ */ jsx("ul", { className: "list-none container-snap max-h-56 overflow-x-hidden", children: /* @__PURE__ */ jsxs("li", { className: "flex uppercase gap-1 flex-row w-full items-center rounded-t-md text-xs border justify-start bg-lightBlue-600 border-blueGray-400 px-2 py-2  text-lightBlue-50 font-semibold", children: [
      /* @__PURE__ */ jsx("div", { className: "w-[5%]", children: "No" }),
      /* @__PURE__ */ jsx("div", { className: "w-[35%]", children: "Permohonan" }),
      /* @__PURE__ */ jsx("div", { className: "w-[35%] md:w-[20%]", children: "Nama Kegiatan" }),
      /* @__PURE__ */ jsx("div", { className: "hidden md:block w-[20%]", children: "Keterangan" }),
      /* @__PURE__ */ jsx("div", { className: "w-[15%] text-right pr-2", children: "Jumlah" }),
      /* @__PURE__ */ jsx("div", { className: "w-[5%] text-center", children: "Menu" })
    ] }) }),
    /* @__PURE__ */ jsx("ul", { className: "list-none container-snap max-h-80 overflow-x-hidden rounded-b-md shadow-md", children: data && data.map((item, index) => /* @__PURE__ */ jsx(
      "li",
      {
        className: "w-full flex flex-col overflow-hidden bg-lightBlue-300",
        children: /* @__PURE__ */ jsxs("div", { className: "flex w-full gap-1 text-xs px-2 py-0 items-center justify-start text-lightBlue-900 border-b-2 border-lightBlue-200", children: [
          /* @__PURE__ */ jsxs("div", { className: "pb-1 w-[5%]", children: [
            index + 1,
            "."
          ] }),
          /* @__PURE__ */ jsx("div", { className: "pb-1 w-[35%]", children: item.permohonan }),
          /* @__PURE__ */ jsx("div", { className: "pb-1 w-[35%] md:w-[20%]", children: item.nama_itemkegiatan }),
          /* @__PURE__ */ jsx("div", { className: "pb-1 hidden md:block md:w-[20%]", children: item.ket_biaya }),
          /* @__PURE__ */ jsx("div", { className: "pb-1 w-[15%] text-right pr-2", children: item.jumlah_biaya }),
          /* @__PURE__ */ jsx("div", { className: "pb-1 w-[5%] flex justify-center items-center gap-2", children: /* @__PURE__ */ jsx(
            "button",
            {
              disabled: kasbon.status_kasbon == "approved",
              onClick: (e) => useSwal.confirm({
                title: "Hapus Data",
                text: "apakah akan menghapus?"
              }).then((result) => {
                if (result.isConfirmed) {
                  handleRemoveData(
                    item.id
                  );
                }
              }),
              className: "text-lightBlue-500 background-transparent text-lg font-bold uppercase px-0 py-0 outline-none focus:outline-none mr-1 mb-1 ease-linear transition-all duration-150",
              type: "button",
              children: /* @__PURE__ */ jsx(
                "i",
                {
                  className: "fa fa-trash",
                  "aria-hidden": "true"
                }
              )
            }
          ) })
        ] })
      },
      item.id
    )) }),
    /* @__PURE__ */ jsx("ul", { className: "list-none container-snap max-h-80 overflow-x-hidden rounded-b-md shadow-md", children: /* @__PURE__ */ jsxs("li", { className: "w-full flex flex-col overflow-hidden bg-lightBlue-600 px-2 py-1  font-semibold text-lightBlue-50", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex w-full gap-1 text-xs px-2 py-1 items-center justify-start border-b-2 border-lightBlue-500", children: [
        /* @__PURE__ */ jsx("div", { className: "w-[60%]" }),
        /* @__PURE__ */ jsx("div", { className: "hidden md:block md:w-[20%] text-right", children: "Total Kasbon" }),
        /* @__PURE__ */ jsx("div", { className: "w-[15%] text-right", children: kasbon.jumlah_kasbon }),
        /* @__PURE__ */ jsx("div", { className: "w-[5%] flex justify-start items-center gap-2" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex w-full gap-1 text-xs px-2 py-1 items-center justify-start border-b-2 border-lightBlue-500", children: [
        /* @__PURE__ */ jsx("div", { className: "w-[60%]" }),
        /* @__PURE__ */ jsx("div", { className: "hidden md:block md:w-[20%] text-right", children: "Penggunaan" }),
        /* @__PURE__ */ jsx("div", { className: "w-[15%] text-right", children: kasbon.jumlah_penggunaan }),
        /* @__PURE__ */ jsx("div", { className: "w-[5%] flex justify-start items-center gap-2" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex w-full gap-1 text-xs px-2 py-1 items-center justify-start border-b-2 border-lightBlue-500", children: [
        /* @__PURE__ */ jsx("div", { className: "w-[60%]" }),
        /* @__PURE__ */ jsx("div", { className: "hidden md:block md:w-[20%] text-right", children: "Sisa Penggunaan" }),
        /* @__PURE__ */ jsx("div", { className: "w-[15%] text-right", children: kasbon.sisa_penggunaan }),
        /* @__PURE__ */ jsx("div", { className: "w-[5%] flex justify-start items-center gap-2" })
      ] })
    ] }) }),
    /* @__PURE__ */ jsx(Pagination, { links: meta.links, labelLinks: links })
  ] });
};
const CardDkasbonnopermList = ({ kasbon }) => {
  const {
    dkasbons: { data, links, meta },
    base_route
  } = usePage().props;
  const handleRemoveData = (id) => {
    router.delete(
      route(base_route + "transaksi.dkasbonnoperms.destroy", id)
    );
  };
  return /* @__PURE__ */ jsxs("div", { className: "w-full mt-4 flex flex-col mb-2", children: [
    /* @__PURE__ */ jsx("ul", { className: "list-none container-snap max-h-56 overflow-x-hidden", children: /* @__PURE__ */ jsxs("li", { className: "flex uppercase gap-1 flex-row w-full items-center rounded-t-md text-xs border justify-start bg-lightBlue-600 border-blueGray-400 px-2 py-2  text-lightBlue-50 font-semibold", children: [
      /* @__PURE__ */ jsx("div", { className: "w-[5%]", children: "No" }),
      /* @__PURE__ */ jsx("div", { className: "w-[55%] md:w-[20%]", children: "Nama Kegiatan" }),
      /* @__PURE__ */ jsx("div", { className: "hidden md:block w-[40%]", children: "Keterangan" }),
      /* @__PURE__ */ jsx("div", { className: "w-[35%] text-right pr-2", children: "Jumlah" }),
      /* @__PURE__ */ jsx("div", { className: "w-[5%] text-center", children: "Menu" })
    ] }) }),
    /* @__PURE__ */ jsx("ul", { className: "list-none container-snap max-h-80 overflow-x-hidden rounded-b-md shadow-md", children: data && data.map((item, index) => /* @__PURE__ */ jsx(
      "li",
      {
        className: "w-full flex flex-col overflow-hidden bg-lightBlue-300",
        children: /* @__PURE__ */ jsxs("div", { className: "flex w-full gap-1 text-xs px-2 py-0 items-center justify-start text-lightBlue-900 border-b-2 border-lightBlue-200", children: [
          /* @__PURE__ */ jsxs("div", { className: "pb-1 w-[5%]", children: [
            index + 1,
            "."
          ] }),
          /* @__PURE__ */ jsx("div", { className: "pb-1 w-[55%] md:w-[20%]", children: item.nama_itemkegiatan }),
          /* @__PURE__ */ jsx("div", { className: "pb-1 hidden md:block md:w-[40%]", children: item.ket_biaya }),
          /* @__PURE__ */ jsx("div", { className: "pb-1 w-[35%] text-right pr-2", children: item.jumlah_biaya }),
          /* @__PURE__ */ jsx("div", { className: "pb-1 w-[5%] flex justify-center items-center gap-2", children: /* @__PURE__ */ jsx(
            "button",
            {
              disabled: kasbon.status_kasbon == "approved",
              onClick: (e) => useSwal.confirm({
                title: "Hapus Data",
                text: "apakah akan menghapus?"
              }).then((result) => {
                if (result.isConfirmed) {
                  handleRemoveData(
                    item.id
                  );
                }
              }),
              className: "text-lightBlue-500 background-transparent text-lg font-bold uppercase px-0 py-0 outline-none focus:outline-none mr-1 mb-1 ease-linear transition-all duration-150",
              type: "button",
              children: /* @__PURE__ */ jsx(
                "i",
                {
                  className: "fa fa-trash",
                  "aria-hidden": "true"
                }
              )
            }
          ) })
        ] })
      },
      item.id
    )) }),
    /* @__PURE__ */ jsx("ul", { className: "list-none container-snap max-h-80 overflow-x-hidden rounded-b-md shadow-md", children: /* @__PURE__ */ jsxs("li", { className: "w-full flex flex-col overflow-hidden bg-lightBlue-600 px-2 py-1  font-semibold text-lightBlue-50", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex w-full gap-1 text-xs px-2 py-1 items-center justify-start border-b-2 border-lightBlue-500", children: [
        /* @__PURE__ */ jsx("div", { className: "w-[60%]" }),
        /* @__PURE__ */ jsx("div", { className: "hidden md:block md:w-[20%] text-right", children: "Total Kasbon" }),
        /* @__PURE__ */ jsx("div", { className: "w-[15%] text-right", children: kasbon.jumlah_kasbon }),
        /* @__PURE__ */ jsx("div", { className: "w-[5%] flex justify-start items-center gap-2" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex w-full gap-1 text-xs px-2 py-1 items-center justify-start border-b-2 border-lightBlue-500", children: [
        /* @__PURE__ */ jsx("div", { className: "w-[60%]" }),
        /* @__PURE__ */ jsx("div", { className: "hidden md:block md:w-[20%] text-right", children: "Penggunaan" }),
        /* @__PURE__ */ jsx("div", { className: "w-[15%] text-right", children: kasbon.jumlah_penggunaan }),
        /* @__PURE__ */ jsx("div", { className: "w-[5%] flex justify-start items-center gap-2" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex w-full gap-1 text-xs px-2 py-1 items-center justify-start border-b-2 border-lightBlue-500", children: [
        /* @__PURE__ */ jsx("div", { className: "w-[60%]" }),
        /* @__PURE__ */ jsx("div", { className: "hidden md:block md:w-[20%] text-right", children: "Sisa Penggunaan" }),
        /* @__PURE__ */ jsx("div", { className: "w-[15%] text-right", children: kasbon.sisa_penggunaan }),
        /* @__PURE__ */ jsx("div", { className: "w-[5%] flex justify-start items-center gap-2" })
      ] })
    ] }) }),
    /* @__PURE__ */ jsx(Pagination, { links: meta.links, labelLinks: links })
  ] });
};
export {
  CardDkasbonList as C,
  CardDkasbonnopermList as a
};
