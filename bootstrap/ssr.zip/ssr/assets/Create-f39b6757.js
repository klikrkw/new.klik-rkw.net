import { jsx, jsxs } from "react/jsx-runtime";
import { I as Input } from "./Input-72be4948.js";
import { L as LinkButton } from "./LinkButton-a291522b.js";
import { L as LoadingButton } from "./LoadingButton-c9189101.js";
import { useForm } from "@inertiajs/react";
import { M as MoneyInput } from "./MoneyInput-87a36109.js";
import { S as SelectSearch } from "./SelectSearch-22ab8168.js";
import { A as AsyncSelectSearch } from "./AsyncSelectSearch-23c2f5cb.js";
import { S as StafLayout } from "./StafLayout-f28c615d.js";
import "react";
import "tailwind-merge";
import "classnames";
import "react-number-format";
import "lodash";
import "react-select";
import "react-select/async";
import "./bootstrap-b9d9b211.js";
import "axios";
import "./NotificationDropdown-abde11b8.js";
import "@popperjs/core";
import "./ResponsiveNavLink-41b4fa07.js";
import "react-hot-toast";
import "./AuthContext-5300e6b5.js";
import "firebase/app";
import "firebase/auth";
import "firebase/firestore";
import "firebase/storage";
import "firebase/messaging";
import "./MenuItem-f3c50e94.js";
const Create = ({
  statuskasbonOpts,
  instansiOpts,
  jeniskasbonOpts,
  isAdmin,
  base_route
}) => {
  const { data, setData, errors, post, processing } = useForm({
    jumlah_kasbon: "0",
    jumlah_penggunaan: "0",
    sisa_penggunaan: "0",
    keperluan: "",
    status_kasbon: statuskasbonOpts[0].value,
    statuskabonOpt: statuskasbonOpts[0] || void 0,
    instansiOpt: instansiOpts[0] || void 0,
    user: void 0,
    user_id: "",
    instansi_id: instansiOpts.length > 0 ? instansiOpts[0].value : "",
    jenis_kasbon: jeniskasbonOpts[0].value,
    jeniskabonOpt: jeniskasbonOpts[0] || void 0,
    _method: "POST"
  });
  const getSisaPenggunaan = (jmlKasbon, jmlPenggunaan) => {
    let xsisaPenggunaan = jmlKasbon > jmlPenggunaan ? jmlKasbon - jmlPenggunaan : 0;
    return xsisaPenggunaan.toString();
  };
  function handleSubmit(e) {
    e.preventDefault();
    post(route("transaksi.kasbons.store"));
  }
  return /* @__PURE__ */ jsx(StafLayout, { children: /* @__PURE__ */ jsx("div", { className: "flex content-center items-center justify-center h-full", children: /* @__PURE__ */ jsx("div", { className: "w-full lg:w-2/4 px-4", children: /* @__PURE__ */ jsxs("div", { className: "relative flex flex-col min-w-0 break-words w-full mb-2 shadow-lg shadow-slate-400 rounded-lg bg-blueGray-100 border-0", children: [
    /* @__PURE__ */ jsxs("div", { className: "rounded-t mb-0 px-4 py-2", children: [
      /* @__PURE__ */ jsx("div", { className: "text-center mb-2", children: /* @__PURE__ */ jsx("h6", { className: "text-blueGray-500 text-lg font-bold", children: "New Kasbon" }) }),
      /* @__PURE__ */ jsx("hr", { className: "mt-4 border-b-1 border-blueGray-300" })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "flex-auto px-4 lg:px-10 py-10 pt-0", children: /* @__PURE__ */ jsxs("form", { onSubmit: handleSubmit, children: [
      /* @__PURE__ */ jsx(
        MoneyInput,
        {
          name: "jumlah_kasbon",
          label: "Jumlah Kasbon",
          disabled: true,
          errors: errors.jumlah_kasbon,
          autoComplete: "off",
          value: data.jumlah_kasbon,
          onValueChange: (e) => setData((prev) => ({
            ...prev,
            jumlah_kasbon: e.value,
            sisa_penggunaan: getSisaPenggunaan(
              Number.parseInt(e.value),
              Number.parseInt(
                data.jumlah_penggunaan
              )
            )
          }))
        }
      ),
      /* @__PURE__ */ jsx(
        MoneyInput,
        {
          name: "jumlah_penggunaan",
          label: "Jumlah Penggunaan",
          errors: errors.jumlah_penggunaan,
          autoComplete: "off",
          disabled: true,
          value: data.jumlah_penggunaan,
          onValueChange: (e) => setData((prev) => ({
            ...prev,
            jumlah_penggunaan: e.value,
            sisa_penggunaan: getSisaPenggunaan(
              Number.parseInt(
                data.jumlah_kasbon
              ),
              Number.parseInt(e.value)
            )
          }))
        }
      ),
      /* @__PURE__ */ jsx(
        MoneyInput,
        {
          name: "sisa_penggunaan",
          label: "Sisa Penggunaan",
          errors: errors.sisa_penggunaan,
          autoComplete: "off",
          disabled: true,
          value: data.sisa_penggunaan,
          onValueChange: (e) => setData((prev) => ({
            ...prev,
            sisa_penggunaan: e.value
          }))
        }
      ),
      /* @__PURE__ */ jsx(
        Input,
        {
          name: "keperluan",
          label: "Keperluan",
          errors: errors.keperluan,
          value: data.keperluan,
          onChange: (e) => setData("keperluan", e.target.value)
        }
      ),
      /* @__PURE__ */ jsx(
        SelectSearch,
        {
          name: "instansi_id",
          label: "Instansi",
          value: data.instansiOpt,
          options: instansiOpts,
          onChange: (e) => setData({
            ...data,
            instansiOpt: e ? e : {},
            instansi_id: e ? e.value : ""
          }),
          errors: errors.instansi_id
        }
      ),
      isAdmin ? /* @__PURE__ */ jsx(
        AsyncSelectSearch,
        {
          placeholder: "Pilih User",
          label: "User",
          value: data.user,
          name: "users",
          url: "/admin/users/api/list/",
          errors: errors.user_id,
          onChange: (e) => setData((v) => ({
            ...v,
            user: e,
            user_id: e ? e.value : ""
          })),
          isClearable: true,
          optionLabels: ["name"],
          optionValue: "id",
          className: "text-blueGray-900"
        }
      ) : null,
      /* @__PURE__ */ jsx(
        Input,
        {
          name: "status_kasbon",
          label: "Status Kasbon",
          errors: errors.status_kasbon,
          value: data.status_kasbon,
          disabled: true
        }
      ),
      /* @__PURE__ */ jsx(
        SelectSearch,
        {
          name: "jenis_kasbon",
          label: "Jenis Kasbon",
          value: data.jeniskabonOpt,
          options: jeniskasbonOpts,
          onChange: (e) => setData({
            ...data,
            jeniskabonOpt: e ? e : {},
            jenis_kasbon: e ? e.value : ""
          }),
          errors: errors.jenis_kasbon
        }
      ),
      /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between mt-2", children: [
        /* @__PURE__ */ jsx(
          LinkButton,
          {
            theme: "blueGrey",
            href: route(
              base_route + "transaksi.kasbons.index"
            ),
            children: /* @__PURE__ */ jsx("span", { children: "Kembali" })
          }
        ),
        /* @__PURE__ */ jsx(
          LoadingButton,
          {
            theme: "black",
            loading: processing,
            type: "submit",
            children: /* @__PURE__ */ jsx("span", { children: "Simpan" })
          }
        )
      ] })
    ] }) })
  ] }) }) }) });
};
export {
  Create as default
};
