import { jsx, jsxs } from "react/jsx-runtime";
import { I as Input } from "./Input-72be4948.js";
import { L as LinkButton } from "./LinkButton-a291522b.js";
import { L as LoadingButton } from "./LoadingButton-c9189101.js";
import { M as MoneyInput } from "./MoneyInput-87a36109.js";
import { S as SelectSearch } from "./SelectSearch-22ab8168.js";
import { A as AdminLayout } from "./AdminLayout-4bc80775.js";
import { usePage, useForm } from "@inertiajs/react";
import "react";
import "tailwind-merge";
import "classnames";
import "react-number-format";
import "lodash";
import "react-select";
import "./NotificationDropdown-abde11b8.js";
import "@popperjs/core";
import "./ResponsiveNavLink-41b4fa07.js";
import "react-hot-toast";
import "./AuthContext-5300e6b5.js";
import "firebase/app";
import "firebase/auth";
import "firebase/firestore";
import "firebase/storage";
import "./bootstrap-b9d9b211.js";
import "axios";
import "firebase/messaging";
import "./MenuItem-f3c50e94.js";
const Edit = () => {
  const { itemrincianbiayaperm, jenisitemrincianbiayapermOpts } = usePage().props;
  const jenisitemrincianbiayapermOpt = jenisitemrincianbiayapermOpts.find(
    (item) => item.value === itemrincianbiayaperm.jenis_itemrincianbiayaperm
  );
  const { data, setData, errors, post, processing } = useForm({
    id: itemrincianbiayaperm.id,
    nama_itemrincianbiayaperm: itemrincianbiayaperm.nama_itemrincianbiayaperm || "",
    min_value: itemrincianbiayaperm.min_value || "0",
    command_itemrincianbiayaperm: itemrincianbiayaperm.command_itemrincianbiayaperm || "",
    jenis_itemrincianbiayaperm: itemrincianbiayaperm.jenis_itemrincianbiayaperm || "",
    jenisitemrincianbiayapermOpt,
    _method: "PUT"
  });
  function handleSubmit(e) {
    e.preventDefault();
    post(
      route("admin.itemrincianbiayaperms.update", itemrincianbiayaperm.id)
    );
  }
  return /* @__PURE__ */ jsx(AdminLayout, { children: /* @__PURE__ */ jsx("div", { className: "flex content-center items-center justify-center h-full", children: /* @__PURE__ */ jsx("div", { className: "w-full lg:w-1/2 px-4", children: /* @__PURE__ */ jsxs("div", { className: "relative flex flex-col min-w-0 break-words w-full mb-6 shadow-lg rounded-lg bg-blueGray-200 border-0", children: [
    /* @__PURE__ */ jsxs("div", { className: "rounded-t mb-0 px-6 py-6", children: [
      /* @__PURE__ */ jsx("div", { className: "text-center mb-3", children: /* @__PURE__ */ jsx("h6", { className: "text-blueGray-500 text-lg font-bold", children: "Tambah Item Rincian Biaya" }) }),
      /* @__PURE__ */ jsx("hr", { className: "mt-6 border-b-1 border-blueGray-300" })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "flex-auto px-4 lg:px-10 py-10 pt-0", children: /* @__PURE__ */ jsxs("form", { onSubmit: handleSubmit, children: [
      /* @__PURE__ */ jsx(
        Input,
        {
          name: "nama_itemrincianbiayaperm",
          label: "Nama Item Biaya Permohonan",
          errors: errors.nama_itemrincianbiayaperm,
          value: data.nama_itemrincianbiayaperm,
          onChange: (e) => setData(
            "nama_itemrincianbiayaperm",
            e.target.value
          )
        }
      ),
      /* @__PURE__ */ jsx(
        MoneyInput,
        {
          name: "min_value",
          label: "Minimal Value",
          errors: errors.min_value,
          autoComplete: "off",
          value: data.min_value,
          onValueChange: (e) => setData("min_value", e.value)
        }
      ),
      /* @__PURE__ */ jsx(
        Input,
        {
          name: "command_itemrincianbiayaperm",
          label: "Command Item Rincian Biaya",
          errors: errors.command_itemrincianbiayaperm,
          value: data.command_itemrincianbiayaperm,
          onChange: (e) => setData(
            "command_itemrincianbiayaperm",
            e.target.value
          )
        }
      ),
      /* @__PURE__ */ jsx(
        SelectSearch,
        {
          name: "jenis_itemrincianbiayaperm",
          label: "Jenis Item",
          value: data.jenisitemrincianbiayapermOpt,
          options: jenisitemrincianbiayapermOpts,
          onChange: (e) => setData({
            ...data,
            jenisitemrincianbiayapermOpt: e ? e : {},
            jenis_itemrincianbiayaperm: e ? e.value : ""
          }),
          errors: errors.jenis_itemrincianbiayaperm
        }
      ),
      /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between ", children: [
        /* @__PURE__ */ jsx(
          LinkButton,
          {
            theme: "blueGrey",
            href: route(
              "admin.itemrincianbiayaperms.index"
            ),
            children: /* @__PURE__ */ jsx("span", { children: "Kembali" })
          }
        ),
        /* @__PURE__ */ jsx(
          LoadingButton,
          {
            theme: "black",
            loading: processing,
            type: "submit",
            children: /* @__PURE__ */ jsx("span", { children: "Simpan" })
          }
        )
      ] })
    ] }) })
  ] }) }) }) });
};
export {
  Edit as default
};
