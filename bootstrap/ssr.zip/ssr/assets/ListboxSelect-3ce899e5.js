import { jsx, jsxs, Fragment as Fragment$1 } from "react/jsx-runtime";
import { useState, Fragment } from "react";
import { Listbox, Transition } from "@headlessui/react";
import { ChevronUpDownIcon } from "@heroicons/react/20/solid";
import { twMerge } from "tailwind-merge";
function ListboxSelect({
  className,
  listOptions,
  onListChange
}) {
  const [selectedItem, setSelectedItem] = useState(
    listOptions[0]
  );
  const onChange = (e) => {
    setSelectedItem(e);
    onListChange(e);
  };
  return /* @__PURE__ */ jsx("div", { className: twMerge("relative w-full", className), children: /* @__PURE__ */ jsx(Listbox, { value: selectedItem, onChange, children: /* @__PURE__ */ jsxs("div", { className: "relative", children: [
    /* @__PURE__ */ jsxs(Listbox.Button, { className: "relative w-full cursor-default rounded-l-lg bg-white py-2 pl-3 pr-10 text-left shadow-md focus:outline-none focus-visible:border-indigo-500 focus-visible:ring-2 focus-visible:ring-white/75 focus-visible:ring-offset-2 focus-visible:ring-offset-orange-300 sm:text-sm", children: [
      /* @__PURE__ */ jsx("span", { className: "block truncate", children: selectedItem.label }),
      /* @__PURE__ */ jsx("span", { className: "pointer-events-none absolute inset-y-0 right-0 flex items-center pr-2", children: /* @__PURE__ */ jsx(
        ChevronUpDownIcon,
        {
          className: "h-5 w-5 text-gray-400",
          "aria-hidden": "true"
        }
      ) })
    ] }),
    /* @__PURE__ */ jsx(
      Transition,
      {
        as: Fragment,
        leave: "transition ease-in duration-100",
        leaveFrom: "opacity-100",
        leaveTo: "opacity-0",
        children: /* @__PURE__ */ jsx(Listbox.Options, { className: "absolute mt-1 max-h-60 w-full overflow-auto rounded-md bg-white py-1 text-base shadow-lg ring-1 ring-black/5 focus:outline-none sm:text-sm", children: listOptions.map(
          (listOption, listOptionIdx) => /* @__PURE__ */ jsx(
            Listbox.Option,
            {
              className: ({ active }) => `relative cursor-default select-none py-2 pl-4 pr-4 ${active ? "bg-amber-100 text-amber-900" : "text-gray-900"}`,
              value: listOption,
              children: ({ selected }) => /* @__PURE__ */ jsx(Fragment$1, { children: /* @__PURE__ */ jsx(
                "span",
                {
                  className: `block truncate ${selected ? "font-bold" : "font-normal"}`,
                  children: listOption.label
                }
              ) })
            },
            listOptionIdx
          )
        ) })
      }
    )
  ] }) }) });
}
export {
  ListboxSelect as L
};
