import { jsx } from "react/jsx-runtime";
import { A as AdminLayout } from "./AdminLayout-4bc80775.js";
import { C as CardTableTempatarsips } from "./CardTableTempatarsips-8c206ae8.js";
import "./NotificationDropdown-abde11b8.js";
import "react";
import "@popperjs/core";
import "./ResponsiveNavLink-41b4fa07.js";
import "@inertiajs/react";
import "react-hot-toast";
import "./AuthContext-5300e6b5.js";
import "firebase/app";
import "firebase/auth";
import "firebase/firestore";
import "firebase/storage";
import "./bootstrap-b9d9b211.js";
import "axios";
import "firebase/messaging";
import "./MenuItem-f3c50e94.js";
import "tailwind-merge";
import "react-use";
import "lodash";
import "./useSwal-5d61a319.js";
import "sweetalert2";
import "./Pagination-30af682d.js";
import "classnames";
import "./InputSearch-6032da7e.js";
import "./LinkButton-a291522b.js";
const Index = ({
  tempatarsips
}) => {
  const { data, meta, links } = tempatarsips;
  return /* @__PURE__ */ jsx(AdminLayout, { children: /* @__PURE__ */ jsx(
    CardTableTempatarsips,
    {
      color: "dark",
      tempatarsips: data,
      meta,
      labelLinks: links
    }
  ) });
};
export {
  Index as default
};
