import { jsx, jsxs } from "react/jsx-runtime";
import { C as CardPermohonanEditable } from "./CardPermohonanEditable-d1f1f0c5.js";
import { C as CardTempatberkas } from "./CardTempatberkas-796a686b.js";
import { L as LoadingButton } from "./LoadingButton-c9189101.js";
import { S as SelectSearch } from "./SelectSearch-22ab8168.js";
import { T as TranspermohonanSelect } from "./TranspermohonanSelect-e6be2ec6.js";
import { S as StafLayout } from "./StafLayout-f28c615d.js";
import { u as useSwal } from "./useSwal-5d61a319.js";
import { useForm, router } from "@inertiajs/react";
import { pickBy } from "lodash";
import { useState, useRef, useEffect } from "react";
import { usePrevious } from "react-use";
import "./ModalAddPermohonan-72cf984e.js";
import "./bootstrap-b9d9b211.js";
import "axios";
import "react-loader-spinner";
import "@headlessui/react";
import "classnames";
import "react-select";
import "tailwind-merge";
import "@heroicons/react/20/solid";
import "swr";
import "./ListboxSelect-3ce899e5.js";
import "./Modal-d06b3568.js";
import "./LinkButton-a291522b.js";
import "@zxing/browser";
import "./useScreenSize-4351026c.js";
import "./NotificationDropdown-abde11b8.js";
import "@popperjs/core";
import "./ResponsiveNavLink-41b4fa07.js";
import "react-hot-toast";
import "./AuthContext-5300e6b5.js";
import "firebase/app";
import "firebase/auth";
import "firebase/firestore";
import "firebase/storage";
import "firebase/messaging";
import "./MenuItem-f3c50e94.js";
import "sweetalert2";
const Create = ({
  baseRoute,
  ctranspermohonan,
  ctempatberkas,
  cposisiberkas,
  tempatberkasOpts,
  tempatberkasOpt
}) => {
  const [transpermohonan, setTranspermohonan] = useState(ctranspermohonan);
  const [posisiberkas, setPosisiberkas] = useState(cposisiberkas);
  const [values, setValues] = useState({
    transpermohonan_id: ctranspermohonan ? ctranspermohonan.id : ""
    // tempatberkas_id: ctempatberkas ? ctempatberkas.id : "",
  });
  const { data, setData, errors, post, processing } = useForm({
    posisiberkas_id: posisiberkas ? posisiberkas.id : "",
    transpermohonan_id: transpermohonan ? transpermohonan.id : "",
    _method: "PUT"
  });
  function handleSubmit(e) {
    e.preventDefault();
    useSwal.confirm({
      title: "Simpan Data",
      text: "apakah akan menyimpan?"
    }).then((result) => {
      if (result.isConfirmed) {
        post(
          route(
            baseRoute + "transaksi.transpermohonans.posisiberkas.store",
            transpermohonan ? transpermohonan.id : ""
          )
        );
      }
    });
  }
  const setCtranspermohonan = (transperm) => {
    if (transperm) {
      setData({
        ...data,
        transpermohonan_id: transperm.id
      });
      setTranspermohonan(transperm);
      setValues((prev) => ({
        ...prev,
        transpermohonan_id: transperm.id
      }));
    } else {
      setValues((prev) => ({
        ...prev,
        transpermohonan_id: ""
      }));
    }
  };
  const setPermohonan = (permohonan) => {
    if (permohonan) {
      setData({
        ...data,
        transpermohonan_id: permohonan.transpermohonan.id
      });
      setValues((prev) => ({
        ...prev,
        transpermohonan_id: permohonan.transpermohonan.id
      }));
    } else {
      setValues((prev) => ({
        ...prev,
        transpermohonan_id: ""
      }));
    }
  };
  const setCTempatberkas = (tempatberkas_id) => {
    if (tempatberkas_id) {
      setValues((prev) => ({
        ...prev,
        tempatberkas_id
      }));
    } else {
      setValues((prev) => ({
        ...prev,
        tempatberkas_id: ""
      }));
    }
  };
  const setCPosisiberkas = (posisiberkas2) => {
    if (posisiberkas2) {
      setData({
        ...data,
        posisiberkas_id: posisiberkas2.id
      });
      setPosisiberkas(posisiberkas2);
    } else {
      setPosisiberkas(null);
    }
  };
  const prevValues = usePrevious(values);
  const transpermohonanRef = useRef(null);
  const [ctempatberkasOpt, setCTempatberkasOpt] = useState(
    tempatberkasOpt ? tempatberkasOpt : { value: "", label: "" }
  );
  useEffect(() => {
    if (prevValues) {
      const query = Object.keys(pickBy(values)).length ? pickBy(values) : {};
      router.get(
        route(route().current() ? route().current() + "" : ""),
        query,
        {
          replace: true,
          preserveState: false
        }
      );
      setPosisiberkas(cposisiberkas ? cposisiberkas : null);
    }
  }, [values]);
  return /* @__PURE__ */ jsx(StafLayout, { children: /* @__PURE__ */ jsx("div", { className: "flex content-center items-center justify-center h-full", children: /* @__PURE__ */ jsx("div", { className: "w-full md:w-[80%] px-4 ", children: /* @__PURE__ */ jsxs("div", { className: "relative flex flex-col min-w-0 break-words w-full mb-6 shadow-lg rounded-lg bg-blueGray-200 border-0", children: [
    /* @__PURE__ */ jsxs("div", { className: "rounded-t mb-0 px-4 py-4", children: [
      /* @__PURE__ */ jsx("div", { className: "text-center mb-3", children: /* @__PURE__ */ jsx("h6", { className: "text-blueGray-500 text-lg font-bold", children: "Tempat Berkas" }) }),
      /* @__PURE__ */ jsx("hr", { className: "mt-4 border-b-1 border-blueGray-300" })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "flex-auto px-4 lg:px-10 py-10 pt-0", children: /* @__PURE__ */ jsxs("form", { onSubmit: handleSubmit, children: [
      /* @__PURE__ */ jsx(
        TranspermohonanSelect,
        {
          inputRef: transpermohonanRef,
          isStaf: false,
          onValueChange: (transperm, opt) => setCtranspermohonan(transperm),
          value: transpermohonan,
          errors: errors.transpermohonan_id
        }
      ),
      transpermohonan && transpermohonan.permohonan ? /* @__PURE__ */ jsx(
        CardPermohonanEditable,
        {
          permohonan: transpermohonan.permohonan,
          base_route: baseRoute,
          setPermohonan
        }
      ) : null,
      /* @__PURE__ */ jsx(
        SelectSearch,
        {
          name: "tempatberkas",
          label: "Tempat Berkas",
          value: ctempatberkasOpt,
          options: tempatberkasOpts,
          className: "w-full mt-4",
          onChange: (e) => {
            if (e) {
              setCTempatberkasOpt(e);
              setCTempatberkas(e.value);
            }
          }
        }
      ),
      ctempatberkas && /* @__PURE__ */ jsx(
        CardTempatberkas,
        {
          ctempatberkas,
          cposisiberkas: posisiberkas,
          onSelectPosisiberkas: setCPosisiberkas
        }
      ),
      /* @__PURE__ */ jsx(
        LoadingButton,
        {
          disabled: posisiberkas === null || transpermohonan === null,
          className: [
            "mt-2",
            posisiberkas === null && transpermohonan === null ? "bg-gray-400" : ""
          ].join(" "),
          theme: "black",
          loading: processing,
          type: "submit",
          children: /* @__PURE__ */ jsx("span", { children: "Simpan" })
        }
      )
    ] }) })
  ] }) }) }) });
};
export {
  Create as default
};
