import { jsxs, jsx } from "react/jsx-runtime";
import { C as CardPermohonanEditable } from "./CardPermohonanEditable-d1f1f0c5.js";
import { M as Modal } from "./Modal-d06b3568.js";
import { I as Input } from "./Input-72be4948.js";
import { L as LinkButton } from "./LinkButton-a291522b.js";
import { L as LoadingButton } from "./LoadingButton-c9189101.js";
import { S as SelectSearch } from "./SelectSearch-22ab8168.js";
import { useForm, Link, usePage, router } from "@inertiajs/react";
import moment from "moment";
import { useState, lazy, useEffect, useRef } from "react";
import "./bootstrap-b9d9b211.js";
import { D as DateInput } from "./DateInput-8d13eeac.js";
import { M as ModalSendNotif } from "./ModalSendNotif-e8219254.js";
import { M as ModalAddPermohonan } from "./ModalAddPermohonan-72cf984e.js";
import { T as TranspermohonanSelect } from "./TranspermohonanSelect-e6be2ec6.js";
import { S as StafLayout } from "./StafLayout-f28c615d.js";
import { u as useSwal } from "./useSwal-5d61a319.js";
import { pickBy } from "lodash";
import { usePrevious } from "react-use";
import "@headlessui/react";
import "tailwind-merge";
import "classnames";
import "react-select";
import "axios";
import "react-datepicker";
/* empty css                           */import "react-loader-spinner";
import "@heroicons/react/20/solid";
import "swr";
import "./ListboxSelect-3ce899e5.js";
import "@zxing/browser";
import "./useScreenSize-4351026c.js";
import "./NotificationDropdown-abde11b8.js";
import "@popperjs/core";
import "./ResponsiveNavLink-41b4fa07.js";
import "react-hot-toast";
import "./AuthContext-5300e6b5.js";
import "firebase/app";
import "firebase/auth";
import "firebase/firestore";
import "firebase/storage";
import "firebase/messaging";
import "./MenuItem-f3c50e94.js";
import "sweetalert2";
function CardTableProsespermohonans({
  prosespermohonans,
  statusprosesperms,
  transpermohonan,
  userOpts
}) {
  const { data, setData, errors, post, processing, reset } = useForm({
    prosespermohonan_id: "",
    prosespermohonan: null,
    statusprosesperm_id: "",
    statusprosesperm: null,
    catatan_statusprosesperm: "",
    is_alert: false,
    start: moment().format("YYYY-MM-DD HH:mm"),
    end: moment().format("YYYY-MM-DD HH:mm"),
    _method: "POST"
  });
  const [statuspermOpts, setstatusPermOpts] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [showModalMessage, setShowModalMessage] = useState(false);
  const [statusprosesperm, setStatusprosesperm] = useState();
  const [prosesperm, setProsesperm] = useState(null);
  function handleSubmit(e) {
    e.preventDefault();
    post(
      route(
        "staf.transaksi.prosespermohonans.statusprosesperms.store",
        data.prosespermohonan_id
      ),
      {
        onSuccess: () => {
          reset(
            "prosespermohonan_id",
            "statusprosesperm_id",
            "catatan_statusprosesperm"
          );
          setShowModal(false);
        }
      }
    );
  }
  const [showModalSendNotif, setShowModalSendNotif] = useState(false);
  const handleShowModalEdit = (e, statusprosesperm2, prosespermohonan_id, prosespermohonan) => {
    e.preventDefault();
    setData({
      ...data,
      prosespermohonan_id,
      catatan_statusprosesperm: statusprosesperm2.pivot.catatan_statusprosesperm,
      statusprosesperm_id: statusprosesperm2.id,
      is_alert: prosespermohonan.is_alert,
      start: moment(prosespermohonan.start).format("YYYY-MM-DD hh:mm:ss"),
      end: moment(prosespermohonan.end).format("YYYY-MM-DD hh:mm:ss"),
      statusprosesperm: {
        value: statusprosesperm2.id,
        label: statusprosesperm2.nama_statusprosesperm
      }
    });
    setstatusPermOpts(statusprosesperms);
    setShowModal(true);
  };
  return /* @__PURE__ */ jsxs("div", { className: "w-full mt-4 flex flex-col", children: [
    /* @__PURE__ */ jsx("ul", { className: "list-none container-snap max-h-56 overflow-x-hidden", children: /* @__PURE__ */ jsxs("li", { className: "flex relative flex-row w-full items-center rounded-t-md text-sm border justify-start bg-lightBlue-600 border-blueGray-400 px-2 py-2 gap-1 text-lightBlue-50", children: [
      /* @__PURE__ */ jsx("div", { className: "w-[40%] md:w-[25%]", children: "Nama Proses" }),
      /* @__PURE__ */ jsx("div", { className: "w-[30%] md:w-[15%]", children: "Tanggal" }),
      /* @__PURE__ */ jsx("div", { className: "hidden md:block w-[25%]", children: "Catatan" }),
      /* @__PURE__ */ jsx("div", { className: "w-[20%]", children: "User" })
    ] }) }),
    /* @__PURE__ */ jsx("ul", { className: "list-none container-snap max-h-80 overflow-x-hidden rounded-b-md shadow-md", children: prosespermohonans && prosespermohonans.map(
      (prosesperm2, index) => /* @__PURE__ */ jsxs(
        "li",
        {
          className: "w-full flex flex-col overflow-hidden bg-lightBlue-200",
          children: [
            /* @__PURE__ */ jsxs("div", { className: "flex w-full text-sm px-2 py-2 items-center justify-start gap-1 text-lightBlue-600 ", children: [
              /* @__PURE__ */ jsx("div", { className: "w-[40%] md:w-[25%]", children: prosesperm2.itemprosesperm.nama_itemprosesperm }),
              /* @__PURE__ */ jsx("div", { className: "w-[30%] md:w-[15%]", children: prosesperm2.tgl_proses }),
              /* @__PURE__ */ jsx("div", { className: "hidden md:block md:w-[25%]", children: prosesperm2.catatan_prosesperm }),
              /* @__PURE__ */ jsxs("div", { className: "w-[20%]", children: [
                prosesperm2.user.name,
                " "
              ] })
            ] }),
            prosesperm2.statusprosesperms.length > 0 ? /* @__PURE__ */ jsx("div", { className: "w-full flex flex-col text-sm ", children: /* @__PURE__ */ jsx("div", { className: "list-none w-full px-2 bg-lightBlue-100  text-lightBlue-700", children: prosesperm2.statusprosesperms.map(
              (statusprosesperm2, idx) => {
                if (statusprosesperm2.pivot.active) {
                  return /* @__PURE__ */ jsxs(
                    "div",
                    {
                      className: "w-full flex flex-row items-center justify-between gap-1",
                      children: [
                        /* @__PURE__ */ jsxs("ol", { className: "flex flex-row w-4/5 md:w-9/12 items-center text-xs gap-1 justify-start  ", children: [
                          /* @__PURE__ */ jsx("li", { className: "py-2", children: /* @__PURE__ */ jsx(
                            "img",
                            {
                              src: statusprosesperm2.image_statusprosesperm,
                              className: "h-5 w-auto ",
                              "aria-hidden": true,
                              alt: ""
                            }
                          ) }),
                          /* @__PURE__ */ jsx("li", { className: "font-semibold", children: statusprosesperm2.nama_statusprosesperm }),
                          /* @__PURE__ */ jsx("li", { children: statusprosesperm2.pivot.catatan_statusprosesperm ? "(" + statusprosesperm2.pivot.catatan_statusprosesperm + ")" : "" }),
                          /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx("span", { className: "font-semibold", children: statusprosesperm2.user.name }) }),
                          /* @__PURE__ */ jsx("li", { className: "italic ", children: moment(
                            statusprosesperm2.pivot.created_at
                          ).format(
                            "DD MMM YYYY"
                          ) })
                        ] }),
                        /* @__PURE__ */ jsxs("div", { className: "flex gap-1 justify-end ", children: [
                          /* @__PURE__ */ jsxs(
                            Link,
                            {
                              className: "rounded-full bg-white/80 px-2 py-1 shadow-lg font-bold text-lightBlue-500",
                              href: "#",
                              onClick: (e) => handleShowModalEdit(
                                e,
                                statusprosesperm2,
                                prosesperm2.id,
                                prosesperm2
                              ),
                              children: [
                                /* @__PURE__ */ jsx("i", { className: "fas fa-edit" }),
                                " ",
                                /* @__PURE__ */ jsx("span", { className: "hidden md:inline", children: "Ubah" })
                              ]
                            },
                            index
                          ),
                          /* @__PURE__ */ jsxs(
                            "a",
                            {
                              className: "rounded-full bg-white/80 px-2 py-1 shadow-lg font-bold text-lightBlue-500",
                              href: "#",
                              onClick: () => {
                                setStatusprosesperm(
                                  statusprosesperm2
                                );
                                setProsesperm(
                                  prosesperm2
                                );
                                setShowModalSendNotif(
                                  true
                                );
                              },
                              children: [
                                /* @__PURE__ */ jsx("i", { className: "fas fa-message" }),
                                " ",
                                /* @__PURE__ */ jsx("span", { className: "hidden md:inline", children: "Pesan" })
                              ]
                            }
                          )
                        ] })
                      ]
                    },
                    idx
                  );
                } else {
                  return null;
                }
              }
            ) }) }) : null
          ]
        },
        index
      )
    ) }),
    /* @__PURE__ */ jsx(
      Modal,
      {
        show: showModalMessage,
        maxWidth: "md",
        closeable: true,
        onClose: () => alert("modal close"),
        children: /* @__PURE__ */ jsx("div", { className: "p-4 flex flex-col", children: /* @__PURE__ */ jsx("div", { className: "flex flex-row justify-between", children: /* @__PURE__ */ jsx(
          "a",
          {
            href: "#",
            className: "bg-white/80 shadow-lg text-lightBlue-500 text-sm",
            onClick: () => setShowModalMessage(true),
            children: /* @__PURE__ */ jsx("i", { className: "fas fa-close" })
          }
        ) }) })
      }
    ),
    /* @__PURE__ */ jsx(
      Modal,
      {
        show: showModal,
        maxWidth: "md",
        closeable: false,
        onClose: () => alert("modal close"),
        children: /* @__PURE__ */ jsx("div", { className: "p-4", children: /* @__PURE__ */ jsxs("form", { onSubmit: handleSubmit, children: [
          /* @__PURE__ */ jsx(
            SelectSearch,
            {
              name: "itemprosesperm_id",
              label: "Status Proses",
              value: data.statusprosesperm,
              options: statuspermOpts,
              onChange: (e) => setData({
                ...data,
                statusprosesperm_id: e ? e.value : "",
                statusprosesperm: e ? e : {}
              }),
              errors: errors.statusprosesperm_id
            }
          ),
          /* @__PURE__ */ jsx(
            Input,
            {
              name: "catatan_statusprosesperm",
              label: "Catatan",
              errors: errors.catatan_statusprosesperm,
              value: data.catatan_statusprosesperm,
              onChange: (e) => setData(
                "catatan_statusprosesperm",
                e.target.value
              )
            }
          ),
          /* @__PURE__ */ jsx("div", { className: "relative h-full mr-4 mt-2", children: /* @__PURE__ */ jsxs("label", { className: "inline-flex items-center cursor-pointer", children: [
            /* @__PURE__ */ jsx(
              "input",
              {
                id: "customCheckAlert",
                type: "checkbox",
                className: "form-checkbox border-0 rounded text-blueGray-700 ml-1 w-5 h-5 ease-linear transition-all duration-150",
                checked: data.is_alert,
                onChange: (e) => setData("is_alert", e.target.checked)
              }
            ),
            /* @__PURE__ */ jsx("span", { className: "ml-2 text-sm font-semibold text-blueGray-600", children: "Ingatkan" })
          ] }) }),
          data.is_alert ? /* @__PURE__ */ jsxs("div", { className: "w-full flex flex-col gap-2 mb-4", children: [
            /* @__PURE__ */ jsx(
              DateInput,
              {
                label: "Start",
                selected: data.start,
                value: data.start,
                name: "start",
                errors: errors.start,
                showTimeSelect: true,
                customDateFormat: "DD-MMM-YYYY HH:mm",
                onChange: (e) => setData(
                  "start",
                  moment(e).format("YYYY-MM-DD HH:mm")
                )
              }
            ),
            /* @__PURE__ */ jsx(
              DateInput,
              {
                label: "End",
                selected: data.end,
                value: data.end,
                name: "end",
                errors: errors.end,
                customDateFormat: "DD-MMM-YYYY HH:mm",
                showTimeSelect: true,
                onChange: (e) => setData(
                  "end",
                  moment(e).format("YYYY-MM-DD HH:mm")
                )
              }
            )
          ] }) : null,
          /* @__PURE__ */ jsxs("div", { className: "mt-4 w-full flex justify-between items-center", children: [
            /* @__PURE__ */ jsx(
              LoadingButton,
              {
                theme: "black",
                loading: processing,
                type: "submit",
                children: /* @__PURE__ */ jsx("span", { children: "Simpan" })
              }
            ),
            /* @__PURE__ */ jsx(
              LinkButton,
              {
                href: "#",
                theme: "blue",
                onClick: (e) => {
                  e.preventDefault();
                  setShowModal(false);
                },
                children: /* @__PURE__ */ jsx("span", { children: "Close" })
              }
            )
          ] })
        ] }) })
      }
    ),
    showModalSendNotif && statusprosesperm && /* @__PURE__ */ jsx(
      ModalSendNotif,
      {
        showModal: showModalSendNotif,
        userOpts,
        setShowModal: setShowModalSendNotif,
        statusprosesperm: statusprosesperm ? statusprosesperm : null,
        transpermohonan,
        prosesperm
      }
    )
  ] });
}
lazy(
  () => import("./CardPermohonan-c73242e8.js")
);
const Create = () => {
  const {
    transpermohonan,
    itemprosesperms,
    prosespermohonans,
    statusprosesperms,
    base_route,
    allPermohonan,
    userOpts
  } = usePage().props;
  const { data, setData, errors, post, processing, reset } = useForm({
    transpermohonan_id: transpermohonan ? transpermohonan.id : "",
    permohonan: null,
    itemprosesperm_id: "",
    itemprosesperm: void 0,
    statusprosesperm_id: "",
    statusprosesperm: void 0,
    catatan_prosesperm: "",
    active: true,
    is_alert: false,
    start: moment().format("YYYY-MM-DD HH:mm"),
    end: moment().format("YYYY-MM-DD HH:mm"),
    _method: "POST"
  });
  const [AddMode, setAddMode] = useState(false);
  function handleSubmit(e) {
    e.preventDefault();
    useSwal.confirm({
      title: "Simpan Data",
      text: "akan menyimpan perubahan?"
    }).then((result) => {
      if (result.isConfirmed) {
        post(route("staf.transaksi.prosespermohonans.store"), {
          onSuccess: () => {
            reset(
              "itemprosesperm",
              "itemprosesperm_id",
              "statusprosesperm_id",
              "statusprosesperm",
              "catatan_prosesperm",
              "active"
            );
            setAddMode(false);
          }
        });
      }
    });
  }
  const setPermohonan = (permohonan) => {
    if (permohonan) {
      setData({
        ...data,
        transpermohonan_id: permohonan.transpermohonan.id,
        permohonan
      });
      setValues((prev) => ({
        ...prev,
        transpermohonan_id: permohonan.transpermohonan.id
      }));
    } else {
      setValues((prev) => ({
        ...prev,
        transpermohonan_id: ""
      }));
    }
  };
  const params = new URLSearchParams(window.location.search);
  const [values2, setValues] = useState({
    transpermohonan_id: params.get("transpermohonan_id"),
    itemprosesperm_id: params.get("itemprosesperm_id")
  });
  const [showModalAddPermohonan, setShowModalAddPermohonan] = useState(false);
  const prevValues = usePrevious(values2);
  const itemprosesId = itemprosesperms.find(
    (e) => e.value === values2.itemprosesperm_id
  );
  useEffect(() => {
    if (prevValues) {
      const query = Object.keys(pickBy(values2)).length ? pickBy(values2) : {};
      router.get(
        route(route().current() ? route().current() + "" : ""),
        query,
        {
          replace: true,
          preserveState: true
        }
      );
    }
  }, [values2]);
  const firstInput = useRef();
  useEffect(() => {
    if (AddMode) {
      firstInput.current.focus();
    }
  }, [AddMode]);
  const transpermSelectRef = useRef(null);
  return /* @__PURE__ */ jsxs(StafLayout, { children: [
    /* @__PURE__ */ jsxs("div", { className: "flex content-center items-center justify-center h-full", children: [
      /* @__PURE__ */ jsx("div", { className: "w-full lg:w-3/4 md:px-4", children: /* @__PURE__ */ jsxs("div", { className: "relative flex flex-col min-w-0 break-words w-full mb-2 shadow-lg shadow-slate-400 rounded-lg bg-blueGray-200 border-0", children: [
        /* @__PURE__ */ jsx("div", { className: "rounded-t mt-2 px-4", children: /* @__PURE__ */ jsx("div", { className: "text-center", children: /* @__PURE__ */ jsx("h6", { className: "text-blueGray-500 text-lg font-bold", children: "PROSES PERMOHONAN" }) }) }),
        /* @__PURE__ */ jsxs("div", { className: "flex-auto p-4 ", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex flex-col md:flex-row items-center w-full", children: [
            /* @__PURE__ */ jsxs("div", { className: "flex flex-row justify-between items-center w-full", children: [
              /* @__PURE__ */ jsx(
                TranspermohonanSelect,
                {
                  inputRef: transpermSelectRef,
                  className: `w-full mr-1 ${AddMode ? "z-10" : ""}`,
                  value: transpermohonan,
                  onValueChange: (p) => setPermohonan(p == null ? void 0 : p.permohonan),
                  errors: errors.transpermohonan_id,
                  isChecked: true,
                  isStaf: !allPermohonan
                }
              ),
              /* @__PURE__ */ jsx(
                "a",
                {
                  tabIndex: -1,
                  href: "#",
                  className: "w-8 h-8 px-2 py-1 rounded-full bg-blue-600/20 shadow-xl mb-1",
                  onClick: (e) => {
                    e.preventDefault();
                    setShowModalAddPermohonan(true);
                  },
                  children: /* @__PURE__ */ jsx("i", { className: "fas fa-add text-md text-center text-gray-700" })
                }
              )
            ] }),
            /* @__PURE__ */ jsx(
              SelectSearch,
              {
                className: "z-20 w-full mb-0 md:w-1/3 text-sm",
                options: itemprosesperms,
                value: itemprosesId,
                onChange: (e) => setValues((prev) => ({
                  ...prev,
                  itemprosesperm_id: e.value
                }))
              }
            )
          ] }),
          transpermohonan && transpermohonan.permohonan ? /* @__PURE__ */ jsx(
            CardPermohonanEditable,
            {
              permohonan: transpermohonan.permohonan,
              base_route,
              setPermohonan
            }
          ) : null,
          transpermohonan && transpermohonan.permohonan ? /* @__PURE__ */ jsx("div", { className: "z-10 w-full flex justify-end items-center bg-blueGray-400 py-2 px-1 rounded-md shadow-md mb-0 relative", children: AddMode ? /* @__PURE__ */ jsx(
            LinkButton,
            {
              href: "#",
              theme: "black",
              onClick: (e) => {
                e.preventDefault();
                setAddMode(false);
              },
              children: /* @__PURE__ */ jsx("span", { children: "Tutup" })
            }
          ) : /* @__PURE__ */ jsx(
            LinkButton,
            {
              href: "#",
              theme: "black",
              onClick: (e) => {
                e.preventDefault();
                setAddMode(true);
              },
              children: /* @__PURE__ */ jsx("span", { children: "Tambah" })
            }
          ) }) : null,
          /* @__PURE__ */ jsx("form", { onSubmit: handleSubmit, children: transpermohonan && transpermohonan.permohonan ? /* @__PURE__ */ jsxs(
            "div",
            {
              className: `w-[95%] z-10 gap-2 flex flex-row justify-start flex-wrap lg:items-start transition-all transform ease-linear duration-150 origin-top m-auto absolute shadow-slate-500 shadow-lg bg-blueGray-300 rounded-b-md ring-blueGray-400 ring-2 p-2 md:p-4 ${AddMode ? "scale-y-100 translate-y-1 opacity-100 " : "scale-y-0 -translate-y-1 opacity-0"}`,
              children: [
                /* @__PURE__ */ jsx("div", { className: "w-full lg:w-1/3", children: /* @__PURE__ */ jsx(
                  SelectSearch,
                  {
                    xref: firstInput,
                    focused: true,
                    name: "itemprosesperm_id",
                    label: "Nama Proses",
                    value: data.itemprosesperm,
                    options: itemprosesperms,
                    onChange: (e) => setData({
                      ...data,
                      itemprosesperm_id: e ? e.value : "",
                      itemprosesperm: e ? e : {}
                    }),
                    errors: errors.itemprosesperm_id
                  }
                ) }),
                /* @__PURE__ */ jsx("div", { className: "w-full lg:w-1/3", children: /* @__PURE__ */ jsx(
                  SelectSearch,
                  {
                    name: "statusprosesperm_id",
                    label: "Status Proses",
                    value: data.statusprosesperm,
                    options: statusprosesperms,
                    onChange: (e) => setData({
                      ...data,
                      statusprosesperm_id: e ? e.value : "",
                      statusprosesperm: e ? e : {}
                    }),
                    errors: errors.statusprosesperm_id
                  }
                ) }),
                /* @__PURE__ */ jsx("div", { className: "w-auto", children: /* @__PURE__ */ jsx(
                  Input,
                  {
                    name: "catatan_prosesperm",
                    autoComplete: "off",
                    multiple: true,
                    label: "Catatan",
                    errors: errors.catatan_prosesperm,
                    value: data.catatan_prosesperm,
                    type: "text",
                    onChange: (e) => setData(
                      "catatan_prosesperm",
                      e.target.value
                    )
                  }
                ) }),
                /* @__PURE__ */ jsxs("div", { className: "flex flex-row", children: [
                  /* @__PURE__ */ jsx("div", { className: "relative h-full mr-4 mt-2", children: /* @__PURE__ */ jsxs("label", { className: "inline-flex items-center cursor-pointer", children: [
                    /* @__PURE__ */ jsx(
                      "input",
                      {
                        id: "customCheckLogin",
                        type: "checkbox",
                        className: "form-checkbox border-0 rounded text-blueGray-700 ml-1 w-5 h-5 ease-linear transition-all duration-150",
                        checked: data.active,
                        onChange: (e) => setData(
                          "active",
                          e.target.checked
                        )
                      }
                    ),
                    /* @__PURE__ */ jsx("span", { className: "ml-2 text-sm font-semibold text-blueGray-600", children: "Active" })
                  ] }) }),
                  /* @__PURE__ */ jsx("div", { className: "relative h-full mr-4 mt-2", children: /* @__PURE__ */ jsxs("label", { className: "inline-flex items-center cursor-pointer", children: [
                    /* @__PURE__ */ jsx(
                      "input",
                      {
                        id: "customCheckAlert",
                        type: "checkbox",
                        className: "form-checkbox border-0 rounded text-blueGray-700 ml-1 w-5 h-5 ease-linear transition-all duration-150",
                        checked: data.is_alert,
                        onChange: (e) => setData(
                          "is_alert",
                          e.target.checked
                        )
                      }
                    ),
                    /* @__PURE__ */ jsx("span", { className: "ml-2 text-sm font-semibold text-blueGray-600", children: "Ingatkan" })
                  ] }) })
                ] }),
                data.is_alert ? /* @__PURE__ */ jsxs("div", { className: "flex flex-row gap-2 mb-4 w-full", children: [
                  /* @__PURE__ */ jsx(
                    DateInput,
                    {
                      label: "Start",
                      selected: data.start,
                      value: data.start,
                      name: "start",
                      errors: errors.start,
                      customDateFormat: "DD-MMM-YYYY HH:mm",
                      showTimeSelect: true,
                      onChange: (e) => setData(
                        "start",
                        moment(e).format(
                          "YYYY-MM-DD HH:mm"
                        )
                      )
                    }
                  ),
                  /* @__PURE__ */ jsx(
                    DateInput,
                    {
                      label: "End",
                      selected: data.end,
                      value: data.end,
                      name: "end",
                      errors: errors.end,
                      customDateFormat: "DD-MMM-YYYY HH:mm",
                      showTimeSelect: true,
                      onChange: (e) => setData(
                        "end",
                        moment(e).format(
                          "YYYY-MM-DD HH:mm"
                        )
                      )
                    }
                  )
                ] }) : null,
                /* @__PURE__ */ jsx(
                  LoadingButton,
                  {
                    theme: "black",
                    loading: processing,
                    type: "submit",
                    children: /* @__PURE__ */ jsx("span", { children: "Simpan" })
                  }
                )
              ]
            }
          ) : null }),
          prosespermohonans && prosespermohonans.length > 0 ? /* @__PURE__ */ jsx(
            CardTableProsespermohonans,
            {
              prosespermohonans,
              statusprosesperms,
              transpermohonan,
              userOpts
            }
          ) : null
        ] })
      ] }) }),
      AddMode ? /* @__PURE__ */ jsx("div", { className: "absolute h-full w-full left-0" }) : null
    ] }),
    /* @__PURE__ */ jsx(
      ModalAddPermohonan,
      {
        showModal: showModalAddPermohonan,
        setShowModal: setShowModalAddPermohonan,
        setPermohonan,
        src: route(base_route + "permohonans.modal.create")
      }
    )
  ] });
};
export {
  Create as default
};
