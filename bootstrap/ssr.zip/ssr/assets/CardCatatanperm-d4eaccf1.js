import { jsxs, jsx } from "react/jsx-runtime";
import { useState, useEffect } from "react";
import { a as apputils } from "./bootstrap-b9d9b211.js";
import { I as Input } from "./Input-72be4948.js";
import { S as SelectSearch } from "./SelectSearch-22ab8168.js";
import { usePage, useForm, router } from "@inertiajs/react";
import { u as useSwal } from "./useSwal-5d61a319.js";
import { L as LoadingButton } from "./LoadingButton-c9189101.js";
import { U as UploadImage } from "./UploadImage-dc2b2f0d.js";
import { Lightbox } from "react-modal-image";
const CardCatatanperm = ({ transpermohonan_id }) => {
  const [catatanperms, setCatatanperms] = useState();
  const [isloading, setIsloading] = useState(false);
  useState({ fieldcatatan: null, isi_catatanperm: "", image_catatanperm: "" });
  const { fieldcatatanOpts } = usePage().props;
  const getCatatanperms = async (xtranspermohonan_id) => {
    setIsloading(true);
    if (xtranspermohonan_id.length > 3) {
      let xlink = `/admin/catatanperms/api/list?transpermohonan_id=${xtranspermohonan_id}`;
      const response = await apputils.backend.get(xlink);
      const data2 = response.data;
      setCatatanperms(data2.data);
    }
    setIsloading(false);
  };
  useEffect(() => {
    if (transpermohonan_id) {
      getCatatanperms(transpermohonan_id);
    }
    return () => {
      setCatatanperms([]);
    };
  }, [transpermohonan_id]);
  const { data, setData, errors, post, processing, reset } = useForm({
    fieldcatatan: null,
    fieldcatatan_id: "",
    isi_catatanperm: "",
    image_catatanperm: "",
    transpermohonan_id: transpermohonan_id ?? "",
    _method: "POST"
  });
  const [AddMode, setAddMode] = useState(false);
  function handleSubmit(e) {
    e.preventDefault();
    post(route("admin.catatanperms.store"), {
      onSuccess: () => {
        reset();
        setAddMode(false);
        if (transpermohonan_id) {
          getCatatanperms(transpermohonan_id);
        }
      },
      preserveState: true,
      preserveScroll: true
    });
  }
  const [viewImage, setViewImage] = useState(false);
  const [image, setImage] = useState(null);
  const handleRemoveData = (id) => {
    router.delete(route("admin.catatanperms.destroy", id));
    if (transpermohonan_id) {
      getCatatanperms(transpermohonan_id);
    }
  };
  useEffect(() => {
    if (transpermohonan_id) {
      setData("transpermohonan_id", transpermohonan_id);
    }
  }, [transpermohonan_id]);
  return /* @__PURE__ */ jsxs("div", { className: "relative rounded-md p-2 bg-white/80 hover:bg-gray-100 text-sm shadow-md", children: [
    /* @__PURE__ */ jsxs("div", { className: "w-full font-bold mb-2", children: [
      "CATATAN : ",
      transpermohonan_id
    ] }),
    transpermohonan_id && transpermohonan_id.length > 3 && /* @__PURE__ */ jsx("form", { onSubmit: handleSubmit, children: /* @__PURE__ */ jsxs("div", { className: "w-full flex flex-row gap-1", children: [
      /* @__PURE__ */ jsx(
        SelectSearch,
        {
          name: "jenishak_id",
          value: data.fieldcatatan,
          options: fieldcatatanOpts,
          className: "w-full lg:w-full ",
          onChange: (e) => setData({
            ...data,
            fieldcatatan: e,
            fieldcatatan_id: e ? e.value : ""
          }),
          errors: errors.fieldcatatan_id
        }
      ),
      /* @__PURE__ */ jsx(
        Input,
        {
          name: "Isi Catatan",
          placeholder: "Isi Catatan",
          value: data.isi_catatanperm,
          onChange: (e) => setData({
            ...data,
            isi_catatanperm: e.target.value
          }),
          errors: errors.isi_catatanperm
        }
      ),
      /* @__PURE__ */ jsx(
        UploadImage,
        {
          image: data.image_catatanperm,
          imagePath: "/images/catatanperms/",
          setImage: (image2) => setData("image_catatanperm", image2),
          name: "image_catatanperm"
        }
      ),
      /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx(
        LoadingButton,
        {
          theme: "red",
          loading: processing,
          type: "submit",
          children: /* @__PURE__ */ jsx("span", { children: "ADD" })
        }
      ) })
    ] }) }),
    catatanperms ? /* @__PURE__ */ jsx("div", { className: "p-1 w-full flex-col", children: /* @__PURE__ */ jsxs("table", { className: "w-full", children: [
      /* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", { className: "border-y-2 font-semibold bg-slate-300", children: [
        /* @__PURE__ */ jsx("td", { width: "20%", children: "Nama Catatan" }),
        /* @__PURE__ */ jsx("td", { width: "50%", children: "Isi Catatan" }),
        /* @__PURE__ */ jsx("td", { width: "20%", children: "Image" }),
        /* @__PURE__ */ jsx("td", { width: "10%", children: "Opt" })
      ] }) }),
      /* @__PURE__ */ jsx("tbody", { children: catatanperms.map((catatanperm, i) => /* @__PURE__ */ jsxs("tr", { children: [
        /* @__PURE__ */ jsx("td", { children: catatanperm.fieldcatatan.nama_fieldcatatan }),
        /* @__PURE__ */ jsx("td", { children: catatanperm.isi_catatanperm }),
        /* @__PURE__ */ jsx("td", { children: catatanperm.image_catatanperm && /* @__PURE__ */ jsx(
          "button",
          {
            onClick: () => {
              setImage(
                catatanperm.image_catatanperm
              );
              setViewImage(true);
            },
            children: /* @__PURE__ */ jsx(
              "i",
              {
                className: "fas fa-image mr-2 text-md cursor-pointer"
              }
            )
          }
        ) }),
        /* @__PURE__ */ jsx("td", { children: /* @__PURE__ */ jsx(
          "button",
          {
            onClick: (e) => useSwal.confirm({
              title: "Hapus Data",
              text: "apakah akan menghapus?"
            }).then((result) => {
              if (result.isConfirmed) {
                handleRemoveData(
                  catatanperm.id
                );
              }
            }),
            className: "text-lightBlue-500 background-transparent font-bold px-3 py-1 text-xs outline-none focus:outline-none hover:text-lightBlue-100 hover:scale-105 mr-1 mb-1 ease-linear transition-all duration-150",
            type: "button",
            children: /* @__PURE__ */ jsx(
              "i",
              {
                className: "fas fa-trash mr-2 text-md cursor-pointer"
              }
            )
          }
        ) })
      ] }, i)) })
    ] }) }) : null,
    viewImage && /* @__PURE__ */ jsx(
      Lightbox,
      {
        small: image ? image : "",
        medium: image ? image : "",
        large: image ? image : "",
        alt: "View Image",
        onClose: () => setViewImage(false)
      }
    )
  ] });
};
export {
  CardCatatanperm as C
};
