import { jsx, Fragment, jsxs } from "react/jsx-runtime";
import { N as NotificationDropdown, U as UserDropdown, a as Navbar, H as HeaderBlank, T as ToastMessages } from "./NotificationDropdown-abde11b8.js";
import React from "react";
import { usePage, Link } from "@inertiajs/react";
import { M as MenuItem } from "./MenuItem-f3c50e94.js";
function StafSidebar() {
  const [collapseShow, setCollapseShow] = React.useState("hidden");
  const currentRoute = route().current();
  const {
    auth: { user }
  } = usePage().props;
  return /* @__PURE__ */ jsx(Fragment, { children: /* @__PURE__ */ jsx("nav", { className: "container-snap md:left-0 md:block md:fixed md:top-0 md:bottom-0 md:overflow-y-auto md:flex-row md:flex-nowrap md:overflow-hidden shadow-xl bg-white flex flex-wrap items-center justify-between relative md:w-64 z-[55] py-4 px-6", children: /* @__PURE__ */ jsxs("div", { className: "md:flex-col md:items-stretch md:min-h-full md:flex-nowrap px-0 flex flex-wrap items-center justify-between w-full mx-auto", children: [
    /* @__PURE__ */ jsx(
      "button",
      {
        className: "cursor-pointer text-black opacity-50 md:hidden px-3 py-1 text-xl leading-none bg-transparent rounded border border-solid border-transparent",
        type: "button",
        onClick: () => setCollapseShow("bg-white m-2 py-3 px-6"),
        children: /* @__PURE__ */ jsx("i", { className: "fas fa-bars" })
      }
    ),
    /* @__PURE__ */ jsx(
      Link,
      {
        className: "md:block text-left md:pb-2 text-blueGray-600 mr-0 inline-block whitespace-nowrap text-sm uppercase p-4 px-0",
        href: "/",
        children: /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("div", { className: "text-lg font-bold", children: "PPAT APP" }),
          /* @__PURE__ */ jsx("div", { className: "text-md", children: user.name })
        ] })
      }
    ),
    " ",
    /* @__PURE__ */ jsxs("ul", { className: "md:hidden items-center flex flex-wrap list-none", children: [
      /* @__PURE__ */ jsx("li", { className: "inline-block relative", children: /* @__PURE__ */ jsx(NotificationDropdown, {}) }),
      /* @__PURE__ */ jsx("li", { className: "inline-block relative", children: /* @__PURE__ */ jsx(UserDropdown, {}) })
    ] }),
    /* @__PURE__ */ jsxs(
      "div",
      {
        className: "md:flex md:flex-col md:items-stretch md:opacity-100 md:relative md:mt-4 md:shadow-none shadow absolute top-0 left-0 right-0 z-40 overflow-y-auto overflow-x-hidden h-auto items-center flex-1 rounded " + collapseShow,
        children: [
          /* @__PURE__ */ jsx("div", { className: "md:min-w-full md:hidden block pb-4 mb-4 border-b border-solid border-blueGray-200", children: /* @__PURE__ */ jsxs("div", { className: "flex flex-wrap", children: [
            /* @__PURE__ */ jsx("div", { className: "w-6/12", children: /* @__PURE__ */ jsx(
              Link,
              {
                className: "md:block text-left md:pb-2 text-blueGray-600 mr-0 inline-block whitespace-nowrap text-sm uppercase font-bold p-4 px-0",
                href: "/",
                children: "Ppat App"
              }
            ) }),
            /* @__PURE__ */ jsx("div", { className: "w-6/12 flex justify-end", children: /* @__PURE__ */ jsx(
              "button",
              {
                type: "button",
                className: "cursor-pointer text-black opacity-50 md:hidden px-3 py-1 text-xl leading-none bg-transparent rounded border border-solid border-transparent",
                onClick: () => setCollapseShow("hidden"),
                children: /* @__PURE__ */ jsx("i", { className: "fas fa-times" })
              }
            ) })
          ] }) }),
          /* @__PURE__ */ jsx("hr", { className: "my-4 md:min-w-full" }),
          /* @__PURE__ */ jsx("h6", { className: "md:min-w-full text-blueGray-500 text-xs uppercase font-bold block pt-1 pb-4 no-underline", children: "Staf Menu" }),
          /* @__PURE__ */ jsxs("ul", { className: "md:flex-col md:min-w-full flex flex-col list-none", children: [
            /* @__PURE__ */ jsx("li", { className: "items-center px-2", children: /* @__PURE__ */ jsxs(
              Link,
              {
                className: "text-xs uppercase py-3 font-bold block " + (currentRoute === "staf.index" ? "text-lightBlue-500 hover:text-lightBlue-600" : "text-blueGray-700 hover:text-blueGray-500"),
                href: route("staf.index"),
                children: [
                  /* @__PURE__ */ jsx(
                    "i",
                    {
                      className: "fas fa-tv mr-2 text-sm" + (window.location.href.indexOf(
                        "/staf"
                      ) !== -1 ? "opacity-75" : "text-blueGray-300")
                    }
                  ),
                  " ",
                  "Dashboard"
                ]
              }
            ) }),
            /* @__PURE__ */ jsxs(
              MenuItem,
              {
                expanded: currentRoute ? currentRoute.includes("transaksi") : false,
                label: "Pendataan",
                children: [
                  /* @__PURE__ */ jsx("li", { className: "items-center px-2", children: /* @__PURE__ */ jsxs(
                    Link,
                    {
                      className: "text-xs uppercase py-3 font-bold block " + (currentRoute === "staf.permohonans.index" ? " text-lightBlue-500 hover:text-lightBlue-600 " : " text-blueGray-700 hover:text-blueGray-500 "),
                      href: route("staf.permohonans.index"),
                      children: [
                        /* @__PURE__ */ jsx(
                          "i",
                          {
                            className: "fas fa-tv mr-2 text-sm " + (currentRoute === "staf.permohonans.index" ? "opacity-75" : "text-blueGray-300")
                          }
                        ),
                        " ",
                        "Permohonan"
                      ]
                    }
                  ) }),
                  /* @__PURE__ */ jsx("li", { className: "items-center px-2", children: /* @__PURE__ */ jsxs(
                    Link,
                    {
                      className: "text-xs uppercase py-3 font-bold flex items-center " + (currentRoute === "staf.permohonans.qrcode.create" ? "text-lightBlue-500 hover:text-lightBlue-600" : "text-blueGray-700 hover:text-blueGray-500"),
                      href: route(
                        "staf.permohonans.qrcode.create"
                      ),
                      children: [
                        /* @__PURE__ */ jsx(
                          "i",
                          {
                            className: "fas fa-tv mr-2 text-sm " + (currentRoute === "staf.permohonans.qrcode.create" ? "opacity-75" : "text-blueGray-300")
                          }
                        ),
                        " ",
                        /* @__PURE__ */ jsxs("span", { className: "flex flex-col", children: [
                          /* @__PURE__ */ jsx("span", { children: "Label Berkas" }),
                          /* @__PURE__ */ jsx("span", { children: "Qr Code" })
                        ] })
                      ]
                    }
                  ) })
                ]
              }
            ),
            /* @__PURE__ */ jsxs(
              MenuItem,
              {
                expanded: currentRoute ? currentRoute.includes("transaksi") : false,
                label: "Transaksi",
                children: [
                  /* @__PURE__ */ jsx("li", { className: "items-center px-2", children: /* @__PURE__ */ jsxs(
                    Link,
                    {
                      className: "text-xs uppercase py-3 font-bold block " + (currentRoute === "staf.transaksi.prosespermohonans.create" ? " text-lightBlue-500 hover:text-lightBlue-600 " : " text-blueGray-700 hover:text-blueGray-500 "),
                      href: route(
                        "staf.transaksi.prosespermohonans.create"
                      ),
                      children: [
                        /* @__PURE__ */ jsx(
                          "i",
                          {
                            className: "fas fa-gears mr-2 text-sm " + (currentRoute === "staf.transaksi.prosespermohonans.create" ? "opacity-75" : "text-blueGray-300")
                          }
                        ),
                        " ",
                        "Proses Permohonan"
                      ]
                    }
                  ) }),
                  /* @__PURE__ */ jsx("li", { className: "items-center px-2 flex flex-row gap-2", children: /* @__PURE__ */ jsxs(
                    Link,
                    {
                      className: "text-xs uppercase py-3 font-bold flex items-center " + (currentRoute === "staf.transaksi.transpermohonans.posisiberkas.create" ? " text-lightBlue-500 hover:text-lightBlue-600 " : " text-blueGray-700 hover:text-blueGray-500 "),
                      href: route(
                        "staf.transaksi.transpermohonans.posisiberkas.create"
                      ),
                      children: [
                        /* @__PURE__ */ jsx(
                          "i",
                          {
                            className: "fas fa-tv mr-2 text-sm " + (currentRoute === "staf.transaksi.transpermohonans.posisiberkas.create" ? "opacity-75" : "text-blueGray-300")
                          }
                        ),
                        /* @__PURE__ */ jsxs("span", { children: [
                          /* @__PURE__ */ jsx("span", { className: "inline-block", children: "Tempat Berkas" }),
                          /* @__PURE__ */ jsx("span", { className: "inline-block", children: "Permohonan" })
                        ] })
                      ]
                    }
                  ) }),
                  /* @__PURE__ */ jsx("li", { className: "items-center px-2", children: /* @__PURE__ */ jsxs(
                    Link,
                    {
                      className: "text-xs uppercase py-3 font-bold block " + (currentRoute === "staf.transaksi.rincianbiayaperms.index" ? " text-lightBlue-500 hover:text-lightBlue-600 " : " text-blueGray-700 hover:text-blueGray-500 "),
                      href: route(
                        "staf.transaksi.rincianbiayaperms.index"
                      ),
                      children: [
                        /* @__PURE__ */ jsx(
                          "i",
                          {
                            className: "fas fa-tv mr-2 text-sm " + (currentRoute === "staf.transaksi.rincianbiayaperms.index" ? "opacity-75" : "text-blueGray-300")
                          }
                        ),
                        " ",
                        "Rincian Biaya"
                      ]
                    }
                  ) }),
                  /* @__PURE__ */ jsx("li", { className: "items-center px-2", children: /* @__PURE__ */ jsxs(
                    Link,
                    {
                      className: "text-xs uppercase py-3 font-bold block " + (currentRoute === "staf.transaksi.biayaperms.create" ? " text-lightBlue-500 hover:text-lightBlue-600 " : " text-blueGray-700 hover:text-blueGray-500 "),
                      href: route(
                        "staf.transaksi.biayaperms.create"
                      ),
                      children: [
                        /* @__PURE__ */ jsx(
                          "i",
                          {
                            className: "fas fa-tv mr-2 text-sm " + (currentRoute === "staf.transaksi.biayaperms.create" ? "opacity-75" : "text-blueGray-300")
                          }
                        ),
                        " ",
                        "Biaya Permohonan"
                      ]
                    }
                  ) }),
                  /* @__PURE__ */ jsx("li", { className: "items-center px-2", children: /* @__PURE__ */ jsxs(
                    Link,
                    {
                      className: "text-xs uppercase py-3 font-bold block " + (currentRoute === "staf.transaksi.kasbons.index" ? " text-lightBlue-500 hover:text-lightBlue-600 " : " text-blueGray-700 hover:text-blueGray-500 "),
                      href: route(
                        "staf.transaksi.kasbons.index"
                      ),
                      children: [
                        /* @__PURE__ */ jsx(
                          "i",
                          {
                            className: "fas fa-tv mr-2 text-sm " + (currentRoute === "staf.transaksi.kasbons.index" ? "opacity-75" : "text-blueGray-300")
                          }
                        ),
                        " ",
                        "Kasbon"
                      ]
                    }
                  ) }),
                  /* @__PURE__ */ jsx("li", { className: "items-center px-2", children: /* @__PURE__ */ jsxs(
                    Link,
                    {
                      className: "text-xs uppercase py-3 font-bold flex items-center " + (currentRoute === "staf.transaksi.keluarbiayapermusers.index" ? " text-lightBlue-500 hover:text-lightBlue-600 " : " text-blueGray-700 hover:text-blueGray-500 "),
                      href: route(
                        "staf.transaksi.keluarbiayapermusers.index"
                      ),
                      children: [
                        /* @__PURE__ */ jsx(
                          "i",
                          {
                            className: "fas fa-tv mr-2 text-sm " + (currentRoute === "staf.transaksi.keluarbiayapermusers.index" ? "opacity-75" : "text-blueGray-300")
                          }
                        ),
                        " ",
                        "Pengeluaran Biaya Permohonan"
                      ]
                    }
                  ) }),
                  /* @__PURE__ */ jsx("li", { className: "items-center px-2", children: /* @__PURE__ */ jsxs(
                    Link,
                    {
                      className: "text-xs uppercase py-3 font-bold flex items-center " + (currentRoute === "staf.transaksi.keluarbiayas.index" ? " text-lightBlue-500 hover:text-lightBlue-600 " : " text-blueGray-700 hover:text-blueGray-500 "),
                      href: route(
                        "staf.transaksi.keluarbiayas.index"
                      ),
                      children: [
                        /* @__PURE__ */ jsx(
                          "i",
                          {
                            className: "fas fa-tv mr-2 text-sm " + (currentRoute === "staf.transaksi.keluarbiayas.index" ? "opacity-75" : "text-blueGray-300")
                          }
                        ),
                        /* @__PURE__ */ jsx("span", { className: "inline-block", children: "Pengeluaran Biaya" })
                      ]
                    }
                  ) }),
                  /* @__PURE__ */ jsx("li", { className: "items-center px-2", children: /* @__PURE__ */ jsxs(
                    Link,
                    {
                      className: "text-xs uppercase py-3 font-bold flex items-center " + (currentRoute === "staf.transaksi.events.index" ? " text-lightBlue-500 hover:text-lightBlue-600 " : " text-blueGray-700 hover:text-blueGray-500 "),
                      href: route(
                        "staf.transaksi.events.index"
                      ),
                      children: [
                        /* @__PURE__ */ jsx(
                          "i",
                          {
                            className: "fas fa-tv mr-2 text-sm " + (currentRoute === "staf.transaksi.events.index" ? "opacity-75" : "text-blueGray-300")
                          }
                        ),
                        /* @__PURE__ */ jsx("span", { className: "inline-block", children: "Event" })
                      ]
                    }
                  ) })
                ]
              }
            ),
            /* @__PURE__ */ jsxs(
              MenuItem,
              {
                expanded: currentRoute ? currentRoute.includes("informasi") : false,
                label: "Informasi",
                children: [
                  /* @__PURE__ */ jsx("li", { className: "items-center px-2", children: /* @__PURE__ */ jsxs(
                    Link,
                    {
                      className: "text-xs uppercase py-3 font-bold block " + (currentRoute === "staf.informasi.prosespermohonans.index" ? " text-lightBlue-500 hover:text-lightBlue-600" : " text-blueGray-700 hover:text-blueGray-500"),
                      href: route(
                        "staf.informasi.prosespermohonans.index"
                      ),
                      children: [
                        /* @__PURE__ */ jsx(
                          "i",
                          {
                            className: "fas fa-book mr-2 text-sm " + (currentRoute === "staf.informasi.prosespermohonans.index" ? "opacity-75" : "text-blueGray-300")
                          }
                        ),
                        " ",
                        "Proses Permohonan"
                      ]
                    }
                  ) }),
                  /* @__PURE__ */ jsx("li", { className: "items-center px-2", children: /* @__PURE__ */ jsxs(
                    Link,
                    {
                      className: "text-xs uppercase py-3 font-bold block " + (currentRoute === "staf.informasi.prosespermohonans.bypermohonan" ? " text-lightBlue-500 hover:text-lightBlue-600" : " text-blueGray-700 hover:text-blueGray-500"),
                      href: route(
                        "staf.informasi.prosespermohonans.bypermohonan"
                      ),
                      children: [
                        /* @__PURE__ */ jsx(
                          "i",
                          {
                            className: "fas fa-tv mr-2 text-sm " + (currentRoute === "staf.informasi.prosespermohonans.bypermohonan" ? "opacity-75" : "text-blueGray-300")
                          }
                        ),
                        " ",
                        "Proses By Permohonan"
                      ]
                    }
                  ) }),
                  /* @__PURE__ */ jsxs("li", { className: "items-center px-2", children: [
                    /* @__PURE__ */ jsxs(
                      Link,
                      {
                        className: "text-xs uppercase py-3 font-bold block " + (currentRoute === "staf.informasi.keuangans.keluarbiayas" ? " text-lightBlue-500 hover:text-lightBlue-600" : " text-blueGray-700 hover:text-blueGray-500"),
                        href: route(
                          "staf.informasi.keuangans.keluarbiayas"
                        ),
                        children: [
                          /* @__PURE__ */ jsx(
                            "i",
                            {
                              className: "fas fa-tv mr-2 text-sm " + (currentRoute === "staf.informasi.keuangans.keluarbiayas" ? "opacity-75" : "text-blueGray-300")
                            }
                          ),
                          " ",
                          "Pengeluaran Biaya"
                        ]
                      }
                    ),
                    /* @__PURE__ */ jsxs(
                      Link,
                      {
                        className: "text-xs uppercase py-3 font-bold flex items-center" + (currentRoute === "staf.informasi.keuangans.keluarbiayapermusers" ? " text-lightBlue-500 hover:text-lightBlue-600" : " text-blueGray-700 hover:text-blueGray-500"),
                        href: route(
                          "staf.informasi.keuangans.keluarbiayapermusers"
                        ),
                        children: [
                          /* @__PURE__ */ jsx(
                            "i",
                            {
                              className: "fas fa-tv mr-2 text-sm " + (currentRoute === "staf.informasi.keuangans.keluarbiayapermusers" ? "opacity-75" : "text-blueGray-300")
                            }
                          ),
                          " ",
                          /* @__PURE__ */ jsxs("span", { className: "flex flex-col", children: [
                            /* @__PURE__ */ jsx("span", { children: "Pengeluaran" }),
                            /* @__PURE__ */ jsx("span", { children: "Biaya Permohonan" })
                          ] })
                        ]
                      }
                    )
                  ] })
                ]
              }
            )
          ] })
        ]
      }
    )
  ] }) }) });
}
const StafLayout = ({
  children
}) => {
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx(StafSidebar, {}),
    /* @__PURE__ */ jsxs("div", { className: "relative md:ml-64 ", children: [
      /* @__PURE__ */ jsx(Navbar, {}),
      /* @__PURE__ */ jsx(HeaderBlank, {}),
      /* @__PURE__ */ jsxs("div", { className: "px-4 md:px-10 mx-auto w-full -m-40 relative h-full", children: [
        /* @__PURE__ */ jsx(ToastMessages, {}),
        children
      ] })
    ] })
  ] });
};
const StafLayout$1 = StafLayout;
export {
  StafLayout$1 as S
};
