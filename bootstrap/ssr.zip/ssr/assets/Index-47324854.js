import { jsx, Fragment, jsxs } from "react/jsx-runtime";
import { A as AdminLayout } from "./AdminLayout-4bc80775.js";
import { useState, useEffect } from "react";
import { twMerge } from "tailwind-merge";
import { usePage, router, Link } from "@inertiajs/react";
import { usePrevious } from "react-use";
import { pickBy } from "lodash";
import { u as useSwal } from "./useSwal-5d61a319.js";
import { P as Pagination } from "./Pagination-30af682d.js";
import { I as InputSearch } from "./InputSearch-6032da7e.js";
import { L as LinkButton } from "./LinkButton-a291522b.js";
import { S as SelectSearch } from "./SelectSearch-22ab8168.js";
import { D as DateRangeInput } from "./DateRangeInput-279d71a2.js";
import moment from "moment";
import { Lightbox } from "react-modal-image";
import "./NotificationDropdown-abde11b8.js";
import "@popperjs/core";
import "./ResponsiveNavLink-41b4fa07.js";
import "react-hot-toast";
import "./AuthContext-5300e6b5.js";
import "firebase/app";
import "firebase/auth";
import "firebase/firestore";
import "firebase/storage";
import "./bootstrap-b9d9b211.js";
import "axios";
import "firebase/messaging";
import "./MenuItem-f3c50e94.js";
import "sweetalert2";
import "classnames";
import "react-select";
import "react-datepicker";
/* empty css                           */import "./Button-e2b11bd9.js";
function CardTablePostingjurnals({
  color = "light",
  postingjurnals,
  className = "",
  meta,
  labelLinks
}) {
  const { periodOpts, period, date1, date2 } = usePage().props;
  const params = new URLSearchParams(window.location.search);
  const [values, setValues] = useState({
    search: params.get("search"),
    sortBy: params.get("sortBy"),
    sortDir: params.get("sortDir"),
    period,
    date1: params.get("date1") ? params.get("date1") : date1,
    date2: params.get("date2") ? params.get("date2") : date2
  });
  const prevValues = usePrevious(values);
  function handleSortLinkClick({
    sortBy,
    sortDir
  }) {
    setValues((values2) => ({ ...values2, sortBy, sortDir }));
  }
  const IconSort = ({
    sortBy,
    sortDir
  }) => {
    if (values.sortBy === sortBy && sortDir === "asc") {
      return /* @__PURE__ */ jsx("i", { className: "fa-solid fa-sort-up" });
    } else if (values.sortBy === sortBy && sortDir === "desc") {
      return /* @__PURE__ */ jsx("i", { className: "fa-solid fa-sort-down" });
    }
    return /* @__PURE__ */ jsx("i", { className: "fa-solid fa-sort" });
  };
  const handleRemoveData = (id) => {
    router.delete(route("admin.transaksi.postingjurnals.destroy", id));
  };
  useEffect(() => {
    if (prevValues) {
      const query = Object.keys(pickBy(values)).length ? pickBy(values) : {};
      router.get(
        route(route().current() ? route().current() + "" : ""),
        query,
        {
          replace: true,
          preserveState: true
        }
      );
    }
  }, [values]);
  const handleDateChange = (dates) => {
    setValues((v) => ({ ...v, date1: dates.date1, date2: dates.date2 }));
  };
  const cperiod = periodOpts.find((e) => e.value == values.period);
  const [periode, setPeriode] = useState(
    cperiod ? cperiod : null
  );
  const [viewImage, setViewImage] = useState(false);
  const [image, setImage] = useState(null);
  return /* @__PURE__ */ jsx(Fragment, { children: /* @__PURE__ */ jsxs(
    "div",
    {
      className: twMerge(
        "relative flex flex-col min-w-0 break-words w-full mb-6 shadow-lg shadow-slate-700 rounded-md py-1 ",
        color === "light" ? "bg-white" : "bg-lightBlue-900 text-white",
        className
      ),
      children: [
        /* @__PURE__ */ jsx("div", { className: "rounded-full mb-0 px-4 py-3 border-0 ", children: /* @__PURE__ */ jsxs("div", { className: "flex justify-between w-full flex-col md:flex-row", children: [
          /* @__PURE__ */ jsx("div", { className: "relative w-full md:w-1/3 max-w-full flex-grow flex-1 ", children: /* @__PURE__ */ jsx(
            "h3",
            {
              className: "font-semibold text-lg " + (color === "light" ? "text-blueGray-700" : "text-white"),
              children: "Posting Jurnal List"
            }
          ) }),
          /* @__PURE__ */ jsxs("div", { className: "flex flex-col justify-center gap-2 md:flex-row items-start w-full md:w-2/3", children: [
            /* @__PURE__ */ jsxs("div", { className: "w-full md:w-4/5  text-blueGray-800 flex flex-col md:flex-row justify-between items-center gap-2", children: [
              period === "tanggal" ? /* @__PURE__ */ jsx(
                DateRangeInput,
                {
                  className: "w-3/5",
                  onDataChange: (d) => handleDateChange(d),
                  value: {
                    date1: values.date1 ? values.date1 : moment().format("YYYY-MM-DD"),
                    date2: values.date2 ? values.date2 : moment().format("YYYY-MM-DD")
                  }
                }
              ) : /* @__PURE__ */ jsx("div", { className: "w-4/5" }),
              /* @__PURE__ */ jsx(
                SelectSearch,
                {
                  name: "period",
                  className: "w-full md:w-1/3",
                  value: periode,
                  options: periodOpts,
                  placeholder: "Periode",
                  onChange: (e) => {
                    setValues((prev) => ({
                      ...prev,
                      period: e.value
                    }));
                    setPeriode(e ? e : {});
                  }
                }
              )
            ] }),
            /* @__PURE__ */ jsx(
              InputSearch,
              {
                value: values.search ? values.search : "",
                onChange: (e) => setValues((v) => ({
                  ...v,
                  search: e.target.value
                }))
              }
            ),
            /* @__PURE__ */ jsx(
              LinkButton,
              {
                theme: "blue",
                href: route(
                  "admin.transaksi.postingjurnals.create"
                ),
                children: /* @__PURE__ */ jsxs("span", { className: "flex items-center gap-1", children: [
                  /* @__PURE__ */ jsx("i", { className: "fa-solid fa-plus" }),
                  " New"
                ] })
              }
            )
          ] })
        ] }) }),
        /* @__PURE__ */ jsx("div", { className: "block w-full overflow-x-auto", children: /* @__PURE__ */ jsxs("table", { className: "items-center w-full bg-transparent border-collapse", children: [
          /* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", { children: [
            /* @__PURE__ */ jsx(
              "th",
              {
                className: "px-6 align-middle border border-solid py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left " + (color === "light" ? "bg-blueGray-50 text-blueGray-500 border-blueGray-100" : "bg-lightBlue-800 text-lightBlue-300 border-lightBlue-700"),
                children: /* @__PURE__ */ jsx(
                  Link,
                  {
                    href: "#",
                    onClick: (e) => handleSortLinkClick({
                      sortBy: "id",
                      sortDir: values.sortDir === "asc" ? "desc" : "asc"
                    }),
                    children: /* @__PURE__ */ jsxs("div", { className: "flex flex-row justify-between", children: [
                      /* @__PURE__ */ jsx("span", { children: "Id" }),
                      /* @__PURE__ */ jsx(
                        IconSort,
                        {
                          sortBy: "id",
                          sortDir: values.sortDir || ""
                        }
                      )
                    ] })
                  }
                )
              }
            ),
            /* @__PURE__ */ jsx(
              "th",
              {
                className: "px-6 align-middle border border-solid py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left " + (color === "light" ? "bg-blueGray-50 text-blueGray-500 border-blueGray-100" : "bg-lightBlue-800 text-lightBlue-300 border-lightBlue-700"),
                children: /* @__PURE__ */ jsx(
                  Link,
                  {
                    href: "#",
                    onClick: (e) => handleSortLinkClick({
                      sortBy: "created_at",
                      sortDir: values.sortDir === "asc" ? "desc" : "asc"
                    }),
                    children: /* @__PURE__ */ jsxs("div", { className: "flex flex-row justify-between", children: [
                      /* @__PURE__ */ jsx("span", { children: "Tanggal" }),
                      /* @__PURE__ */ jsx(
                        IconSort,
                        {
                          sortBy: "created_at",
                          sortDir: values.sortDir || ""
                        }
                      )
                    ] })
                  }
                )
              }
            ),
            /* @__PURE__ */ jsx(
              "th",
              {
                className: "px-6 align-middle border border-solid py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left " + (color === "light" ? "bg-blueGray-50 text-blueGray-500 border-blueGray-100" : "bg-lightBlue-800 text-lightBlue-300 border-lightBlue-700"),
                children: /* @__PURE__ */ jsx(
                  Link,
                  {
                    href: "#",
                    onClick: (e) => handleSortLinkClick({
                      sortBy: "uraian",
                      sortDir: values.sortDir === "asc" ? "desc" : "asc"
                    }),
                    children: /* @__PURE__ */ jsxs("div", { className: "flex flex-row justify-between", children: [
                      /* @__PURE__ */ jsx("span", { children: "Uraian" }),
                      /* @__PURE__ */ jsx(
                        IconSort,
                        {
                          sortBy: "uraian",
                          sortDir: values.sortDir || ""
                        }
                      )
                    ] })
                  }
                )
              }
            ),
            /* @__PURE__ */ jsx(
              "th",
              {
                className: "px-6 align-middle border border-solid py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left " + (color === "light" ? "bg-blueGray-50 text-blueGray-500 border-blueGray-100" : "bg-lightBlue-800 text-lightBlue-300 border-lightBlue-700"),
                children: /* @__PURE__ */ jsx("div", { className: "flex flex-row justify-between", children: /* @__PURE__ */ jsx("span", { children: "Jumlah" }) })
              }
            ),
            /* @__PURE__ */ jsx(
              "th",
              {
                className: "px-6 align-middle border border-solid py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left " + (color === "light" ? "bg-blueGray-50 text-blueGray-500 border-blueGray-100" : "bg-lightBlue-800 text-lightBlue-300 border-lightBlue-700"),
                children: /* @__PURE__ */ jsx("div", { className: "flex flex-row justify-between", children: /* @__PURE__ */ jsx("span", { children: "User" }) })
              }
            ),
            /* @__PURE__ */ jsx(
              "th",
              {
                className: "px-6 align-middle border border-solid py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left " + (color === "light" ? "bg-blueGray-50 text-blueGray-500 border-blueGray-100" : "bg-lightBlue-800 text-lightBlue-300 border-lightBlue-700"),
                children: /* @__PURE__ */ jsx("div", { className: "flex flex-row justify-between", children: /* @__PURE__ */ jsx("span", { children: "Image" }) })
              }
            ),
            /* @__PURE__ */ jsx(
              "th",
              {
                className: "px-6 align-middle border border-solid py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left " + (color === "light" ? "bg-blueGray-50 text-blueGray-500 border-blueGray-100" : "bg-lightBlue-800 text-lightBlue-300 border-lightBlue-700"),
                children: "Options"
              }
            )
          ] }) }),
          /* @__PURE__ */ jsx("tbody", { children: postingjurnals.map(
            ({
              id,
              uraian,
              user,
              jumlah,
              created_at,
              image: image2
            }, index) => /* @__PURE__ */ jsxs("tr", { children: [
              /* @__PURE__ */ jsx("td", { className: "border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-2", children: id }),
              /* @__PURE__ */ jsx("td", { className: "border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-2", children: created_at }),
              /* @__PURE__ */ jsxs("td", { className: "border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-2", children: [
                /* @__PURE__ */ jsx("i", { className: "fas fa-circle text-orange-500 mr-2" }),
                " ",
                uraian
              ] }),
              /* @__PURE__ */ jsx("td", { className: "border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-2", children: jumlah }),
              /* @__PURE__ */ jsx("td", { className: "border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-2", children: user.name }),
              /* @__PURE__ */ jsx("td", { className: "border-t-0 px-3 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap py-2", children: image2 && /* @__PURE__ */ jsx(
                "button",
                {
                  onClick: () => {
                    setImage(image2);
                    setViewImage(true);
                  },
                  children: /* @__PURE__ */ jsx(
                    "i",
                    {
                      className: "fas fa-image mr-2 text-sm cursor-pointer"
                    }
                  )
                }
              ) }),
              /* @__PURE__ */ jsx("td", { className: "border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-2 ", children: /* @__PURE__ */ jsxs("div", { className: "flex justify-start gap-1 ", children: [
                /* @__PURE__ */ jsx(
                  Link,
                  {
                    href: route(
                      "admin.transaksi.postingjurnals.edit",
                      id
                    ),
                    className: "text-lightBlue-500 background-transparent font-bold px-3 py-1 text-xs outline-none focus:outline-none hover:text-lightBlue-100 hover:scale-105 mr-1 mb-1 ease-linear transition-all duration-150",
                    type: "button",
                    children: "Edit"
                  }
                ),
                /* @__PURE__ */ jsx(
                  "button",
                  {
                    onClick: (e) => useSwal.confirm({
                      title: "Hapus Data",
                      text: "apakah akan menghapus?"
                    }).then((result) => {
                      if (result.isConfirmed) {
                        handleRemoveData(
                          id
                        );
                      }
                    }),
                    className: "text-lightBlue-500 background-transparent font-bold px-3 py-1 text-xs outline-none focus:outline-none hover:text-lightBlue-100 hover:scale-105 mr-1 mb-1 ease-linear transition-all duration-150",
                    type: "button",
                    children: "Hapus"
                  }
                )
              ] }) })
            ] }, index)
          ) })
        ] }) }),
        meta.total > meta.per_page ? /* @__PURE__ */ jsx(
          "div",
          {
            className: "flex justify-end px-2 py-1  " + (color === "light" ? "bg-blueGray-50 text-blueGray-500 border-blueGray-100" : "bg-lightBlue-800 text-lightBlue-300 border-lightBlue-700"),
            children: /* @__PURE__ */ jsx(
              Pagination,
              {
                links: meta.links,
                labelLinks
              }
            )
          }
        ) : null,
        viewImage && /* @__PURE__ */ jsx(
          Lightbox,
          {
            small: image ? image : "",
            medium: image ? image : "",
            large: image ? image : "",
            alt: "View Image",
            onClose: () => setViewImage(false)
          }
        )
      ]
    }
  ) });
}
const Index = ({ postingjurnals }) => {
  const {
    data,
    meta,
    links
  } = postingjurnals;
  return /* @__PURE__ */ jsx(AdminLayout, { children: /* @__PURE__ */ jsx(CardTablePostingjurnals, { color: "dark", postingjurnals: data, meta, labelLinks: links }) });
};
export {
  Index as default
};
