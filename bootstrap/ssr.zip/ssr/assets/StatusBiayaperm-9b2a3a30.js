import { jsxs, jsx } from "react/jsx-runtime";
import { M as ModalCetakLaporan } from "./ModalCetakLaporan-767963a0.js";
import { S as SelectSearch } from "./SelectSearch-22ab8168.js";
import { A as AdminLayout } from "./AdminLayout-4bc80775.js";
import { router, Link } from "@inertiajs/react";
import { pickBy } from "lodash";
import { useState, useEffect } from "react";
import { usePrevious } from "react-use";
import "./Modal-d06b3568.js";
import "@headlessui/react";
import "./bootstrap-b9d9b211.js";
import "axios";
import "react-dom";
import "@emotion/react";
import "@emotion/cache";
import "react-loader-spinner";
import "react-select";
import "tailwind-merge";
import "./NotificationDropdown-abde11b8.js";
import "@popperjs/core";
import "./ResponsiveNavLink-41b4fa07.js";
import "react-hot-toast";
import "./AuthContext-5300e6b5.js";
import "firebase/app";
import "firebase/auth";
import "firebase/firestore";
import "firebase/storage";
import "firebase/messaging";
import "./MenuItem-f3c50e94.js";
const StatusBiayaperm = ({
  biayaperms: {
    data,
    links: { first, last, prev, next }
  },
  lunas,
  lunasOpts,
  user_id,
  userOpts
}) => {
  const [values, setValues] = useState({ lunas, user_id });
  const clunas = lunasOpts.find((e) => e.value == values.lunas);
  const cuser = userOpts.find((e) => e.value == values.user_id);
  const [curLunas, setCurLunas] = useState(
    clunas ? clunas : null
  );
  const [curUser, setCurUser] = useState(
    cuser ? cuser : null
  );
  const [showModalLaporan, setShowModalLaporan] = useState(false);
  const [url, setUrl] = useState();
  const prevValues = usePrevious(values);
  useEffect(() => {
    if (prevValues) {
      const query = Object.keys(pickBy(values)).length ? pickBy(values) : {};
      router.get(
        route(route().current() ? route().current() + "" : ""),
        query,
        {
          replace: true,
          preserveState: true
        }
      );
    }
  }, [values]);
  const handlePrint = () => {
    const params = new URLSearchParams(window.location.search);
    const page = params.get("page") ? params.get("page") : 1;
    const lunas2 = params.get("lunas") ? params.get("lunas") : 0;
    const user_id2 = params.get("user_id") ? params.get("user_id") : null;
    setUrl(
      route(route().current() + "") + `?lunas=${lunas2}&page=${page}&media=print${user_id2 ? "&user_id=" + user_id2 : ""}`
    );
    setShowModalLaporan(true);
  };
  return /* @__PURE__ */ jsxs(AdminLayout, { children: [
    /* @__PURE__ */ jsx("div", { className: "flex content-center items-center justify-center relative -top-2", children: /* @__PURE__ */ jsx("div", { className: "w-full px-2", children: /* @__PURE__ */ jsxs("div", { className: "relative flex flex-col min-w-0 break-words w-full mb-2 shadow-lg shadow-slate-400 rounded-lg bg-blueGray-100 border-0", children: [
      /* @__PURE__ */ jsx("div", { className: "rounded-t mb-2 px-4 pt-4 ", children: /* @__PURE__ */ jsxs("div", { className: "w-full flex flex-col md:flex-row justify-between gap-2 bg-lightBlue-800 text-lightBlue-100 px-2 py-2 shadow-md rounded-lg", children: [
        /* @__PURE__ */ jsx("div", { className: "text-left", children: /* @__PURE__ */ jsx("h1", { className: "font-semibold", children: "BIAYA PERMOHONAN" }) }),
        /* @__PURE__ */ jsxs("div", { className: "w-full md:w-1/2 text-blueGray-800 flex flex-col md:flex-row justify-between items-center gap-2", children: [
          /* @__PURE__ */ jsx(
            SelectSearch,
            {
              name: "lunas",
              value: curUser,
              options: userOpts,
              placeholder: "Pilih Petugas",
              onChange: (e) => {
                setValues((prev2) => ({
                  ...prev2,
                  user_id: e.value
                }));
                setCurUser(e ? e : {});
              }
            }
          ),
          /* @__PURE__ */ jsx(
            SelectSearch,
            {
              name: "lunas",
              value: curLunas,
              options: lunasOpts,
              placeholder: "Pilih Status",
              onChange: (e) => {
                setValues((prev2) => ({
                  ...prev2,
                  lunas: e.value
                }));
                setCurLunas(e ? e : {});
              }
            }
          ),
          /* @__PURE__ */ jsx(
            "button",
            {
              onClick: (e) => {
                handlePrint();
              },
              className: "text-lightBlue-300 background-transparent font-bold uppercase px-3 py-1 outline-none focus:outline-none mr-1 mb-1 ease-linear transition-all duration-150",
              type: "button",
              children: /* @__PURE__ */ jsx("i", { className: "fas fa-print" })
            }
          )
        ] })
      ] }) }),
      /* @__PURE__ */ jsx("div", { className: "flex-auto px-2 lg:px-4 py-6 pt-0", children: data.length > 0 ? /* @__PURE__ */ jsxs("div", { className: "p-1 w-full flex-col overflow-y-auto", children: [
        /* @__PURE__ */ jsxs("table", { className: "w-full", children: [
          /* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", { className: "border-y-2 font-semibold bg-slate-300", children: [
            /* @__PURE__ */ jsx(
              "td",
              {
                className: "pl-2",
                width: "10%",
                children: "No Daftar"
              }
            ),
            /* @__PURE__ */ jsx("td", { width: "10%", children: "Tanggal" }),
            /* @__PURE__ */ jsx("td", { width: "10%", align: "left", children: "Transaksi" }),
            /* @__PURE__ */ jsx("td", { width: "30%", align: "left", children: "Permohonan" }),
            /* @__PURE__ */ jsx(
              "td",
              {
                className: "pl-2",
                width: "10%",
                align: "left",
                children: "Petugas"
              }
            ),
            /* @__PURE__ */ jsx("td", { width: "10%", align: "right", children: "Jumlah Biaya" }),
            /* @__PURE__ */ jsx("td", { width: "10%", align: "right", children: "Jumlah Bayar" }),
            /* @__PURE__ */ jsx(
              "td",
              {
                className: "pr-2 py-2",
                width: "10%",
                align: "right",
                children: "Kurang Bayar"
              }
            )
          ] }) }),
          /* @__PURE__ */ jsx("tbody", { children: data.map((biayaperm, i) => /* @__PURE__ */ jsxs(
            "tr",
            {
              className: "border-b-2",
              children: [
                /* @__PURE__ */ jsx("td", { className: "pl-2", children: biayaperm.no_daftar }),
                /* @__PURE__ */ jsx("td", { children: biayaperm.tgl_biayaperm }),
                /* @__PURE__ */ jsx("td", { children: biayaperm.nama_jenispermohonan }),
                /* @__PURE__ */ jsx("td", { children: biayaperm.permohonan }),
                /* @__PURE__ */ jsx("td", { className: "pl-2", children: biayaperm.users.map(
                  (user, i2) => {
                    return /* @__PURE__ */ jsx(
                      "span",
                      {
                        className: "text-blue-600 bg-sky-200 font-bold text-xs px-2 py-1 rounded-full",
                        children: user.name
                      },
                      i2
                    );
                  }
                ) }),
                /* @__PURE__ */ jsx("td", { align: "right", children: biayaperm.jumlah_biayaperm }),
                /* @__PURE__ */ jsx("td", { align: "right", children: biayaperm.jumlah_bayar }),
                /* @__PURE__ */ jsx(
                  "td",
                  {
                    className: "pr-2",
                    align: "right",
                    children: biayaperm.kurang_bayar
                  }
                )
              ]
            },
            i
          )) })
        ] }),
        /* @__PURE__ */ jsx("div", { className: "w-full mt-4 flex justify-end items-start", children: /* @__PURE__ */ jsxs("div", { className: "w-36 grid grid-cols-2 gap-2 ", children: [
          /* @__PURE__ */ jsxs(
            Link,
            {
              href: prev,
              className: "bg-lightBlue-500 text-white active:bg-lightBlue-600 font-bold uppercase text-xs px-2 py-1 rounded-full shadow hover:shadow-md outline-none focus:outline-none mr-1 mb-1 ease-linear transition-all duration-150",
              type: "Link",
              children: [
                /* @__PURE__ */ jsx(
                  "i",
                  {
                    className: "fa fa-chevron-left",
                    "aria-hidden": "true"
                  }
                ),
                " ",
                "Prev"
              ]
            }
          ),
          /* @__PURE__ */ jsxs(
            Link,
            {
              href: next,
              className: "bg-lightBlue-500 text-white active:bg-lightBlue-600 font-bold uppercase text-xs px-2 py-1 rounded-full shadow hover:shadow-md outline-none focus:outline-none mr-1 mb-1 ease-linear transition-all duration-150",
              type: "Link",
              children: [
                /* @__PURE__ */ jsx(
                  "i",
                  {
                    className: "fa fa-chevron-right",
                    "aria-hidden": "true"
                  }
                ),
                " ",
                "Next"
              ]
            }
          )
        ] }) })
      ] }) : null })
    ] }) }) }),
    /* @__PURE__ */ jsx(
      ModalCetakLaporan,
      {
        showModal: showModalLaporan,
        setShowModal: setShowModalLaporan,
        src: url
      }
    )
  ] });
};
export {
  StatusBiayaperm as default
};
