import { jsxs, jsx, Fragment } from "react/jsx-runtime";
import { useRef, useState, useEffect, Fragment as Fragment$1 } from "react";
import { Combobox, Transition } from "@headlessui/react";
import { XCircleIcon, ChevronUpDownIcon, QrCodeIcon } from "@heroicons/react/20/solid";
import { twMerge } from "tailwind-merge";
import useSWR from "swr";
import { a as apputils } from "./bootstrap-b9d9b211.js";
import { L as ListboxSelect } from "./ListboxSelect-3ce899e5.js";
import { M as Modal } from "./Modal-d06b3568.js";
import { L as LinkButton } from "./LinkButton-a291522b.js";
import { BrowserQRCodeReader } from "@zxing/browser";
import { u as useScreenSize } from "./useScreenSize-4351026c.js";
const QRCodeScanner = ({ onReadQRCode }) => {
  const videoRef = useRef(null);
  const [error, setError] = useState(null);
  const controlsRef = useRef();
  const [columns, setColumns] = useState([]);
  const [selectedDeviceId, setSelectedDeviceId] = useState(
    null
  );
  async function getDevices(devices) {
    const cols = [];
    devices.forEach((device) => {
      if (device.kind === "videoinput") {
        cols.push({
          label: device.label,
          deviceId: device.deviceId
        });
      }
    });
    setColumns(cols);
    if (!selectedDeviceId) {
      setSelectedDeviceId(cols[0].deviceId);
    }
    return cols;
  }
  useEffect(() => {
    const codeReader = new BrowserQRCodeReader();
    let isActive = true;
    const startScanner = async () => {
      try {
        (async () => {
          await navigator.mediaDevices.getUserMedia({
            audio: false,
            video: true
          });
          let devices = await navigator.mediaDevices.enumerateDevices();
          getDevices(devices);
        })();
        if (selectedDeviceId) {
          await codeReader.decodeFromVideoDevice(
            selectedDeviceId,
            videoRef.current,
            (result, err, control) => {
              if (result && isActive) {
                onReadQRCode(result);
              }
              if (err) {
                setError(err.message);
              }
              if (control) {
                controlsRef.current = control;
              }
            }
          );
        }
      } catch (err) {
        setError("Gagal memulai kamera: " + err.message);
      }
    };
    startScanner();
    return () => {
      isActive = false;
      if (controlsRef.current) {
        controlsRef.current.stop();
      }
    };
  }, [selectedDeviceId]);
  return /* @__PURE__ */ jsxs("div", { children: [
    /* @__PURE__ */ jsx(
      "video",
      {
        ref: videoRef,
        style: {
          width: "100%",
          maxWidth: 480,
          border: "1px solid #ccc"
        }
      }
    ),
    error && /* @__PURE__ */ jsxs("div", { style: { marginTop: "10px", color: "red" }, children: [
      "⚠️ ",
      error
    ] }),
    /* @__PURE__ */ jsx("div", { className: "p-2 flex flex-col md:flex-row justify-between gap-2", children: /* @__PURE__ */ jsx(
      "select",
      {
        className: "block w-full md:w-2/3 appearance-none text-sm bg-white border border-gray-400 hover:border-gray-500 px-4 py-2 pr-8 rounded shadow leading-tight focus:outline-none focus:shadow-outline",
        value: selectedDeviceId ?? "",
        onChange: (e) => setSelectedDeviceId(e.target.value),
        children: columns && columns.map((col) => /* @__PURE__ */ jsx("option", { value: col.deviceId, children: col.label }, col.deviceId))
      }
    ) })
  ] });
};
const ModalQRCode = ({ showModal, setShowModal, onReadQRCode }) => {
  return /* @__PURE__ */ jsx(
    Modal,
    {
      show: showModal,
      maxWidth: "sm",
      closeable: true,
      onClose: () => setShowModal(false),
      children: /* @__PURE__ */ jsxs("div", { className: "p-2 bg-blueGray-100 rounded-md ", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex flex-col justify-between items-start", children: [
          /* @__PURE__ */ jsx("h1", { className: "font-bold text-sm text-blueGray-700 mb-2", children: "QRCode Scanner" }),
          /* @__PURE__ */ jsx("div", { className: "w-full h-auto flex justify-between items-center p-1 flex-wrap gap-1 border border-gray-300 rounded-md bg-gray-100 ", children: /* @__PURE__ */ jsx(
            QRCodeScanner,
            {
              onReadQRCode: (result) => {
                onReadQRCode(result);
                setShowModal(false);
              }
            }
          ) })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "mt-2 w-full flex justify-between items-center", children: [
          /* @__PURE__ */ jsx("span", {}),
          /* @__PURE__ */ jsx(
            LinkButton,
            {
              href: "#",
              theme: "blue",
              onClick: (e) => {
                e.preventDefault();
                setShowModal(false);
              },
              children: /* @__PURE__ */ jsx("span", { children: "Close" })
            }
          )
        ] })
      ] })
    }
  );
};
function TranspermohonanSelect({
  className,
  onValueChange,
  value,
  errors,
  inputRef,
  isStaf,
  isChecked = false,
  isDisabledCheck = false,
  isAllPermohonan = false,
  zIndex = "z-50"
}) {
  const [selectedPerson, setSelectedPerson] = useState(value ? value : void 0);
  const listOptions = [
    { label: "ALL", value: "" },
    { label: "PENERIMA", value: "nama_penerima" },
    { label: "PELEPAS", value: "nama_pelepas" },
    { label: "NO HAK", value: "nomor_hak" },
    { label: "NO DAFTAR", value: "nodaftar_permohonan" }
  ];
  const [allPerm, setAllPerm] = useState(isChecked);
  const [searchKey, setSearchKey] = useState("");
  const [showCamera, setshowCamera] = useState(false);
  const screenSize = useScreenSize();
  screenSize.width < 768;
  function LoadingSpinner() {
    return /* @__PURE__ */ jsxs(
      "svg",
      {
        className: "h-5 w-5 animate-spin text-gray-500",
        xmlns: "http://www.w3.org/2000/svg",
        fill: "none",
        viewBox: "0 0 24 24",
        children: [
          /* @__PURE__ */ jsx(
            "circle",
            {
              className: "opacity-25",
              cx: "12",
              cy: "12",
              r: "10",
              stroke: "currentColor",
              strokeWidth: "4"
            }
          ),
          /* @__PURE__ */ jsx(
            "path",
            {
              className: "opacity-75",
              fill: "currentColor",
              d: "M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
            }
          )
        ]
      }
    );
  }
  async function fetcher(url, query2) {
    const isstaf = allPerm ? false : true;
    if (searchKey) {
      const result = await apputils.backend.get(
        // `${url}?search=${query}&search_key=${searchKey}`
        `${url}?search=${query2}&search_key=${searchKey}&is_staf=${isstaf}`
      );
      return result.data;
    } else {
      const result = await apputils.backend.get(
        // `${url}?search=${query}`
        `${url}?search=${query2}&is_staf=${isstaf}`
      );
      return result.data;
    }
  }
  const [query, setQuery] = useState("");
  const { data: filteredOption, error } = useSWR(
    ["/admin/transpermohonans/api/list/", query],
    ([url, query2]) => fetcher(url, query2)
  );
  const isLoading = !error && !filteredOption;
  const onChange = (e) => {
    setSelectedPerson((prev) => prev ? e : void 0);
    onValueChange(e, listOptions[0]);
  };
  const comparePeople = (a, b) => {
    var _a, _b;
    return ((_a = a == null ? void 0 : a.permohonan) == null ? void 0 : _a.nama_penerima.toLowerCase()) === ((_b = b == null ? void 0 : b.permohonan) == null ? void 0 : _b.nama_penerima.toLowerCase());
  };
  const clearValue = (e) => {
    e.preventDefault();
    if (inputRef && inputRef.current) {
      inputRef.current.value = "";
      onValueChange(null, listOptions[0]);
    }
  };
  const getPermohonan = async (id) => {
    const url = "/admin/transpermohonans/api/list/";
    const result = await apputils.backend.get(
      `${url}?search=${id}&is_staf=${false}`
    );
    if (result.data.length > 0) {
      return result.data[0];
    }
    return null;
  };
  function handleReadQRCode(text) {
    if (text) {
      getPermohonan(text.getText()).then((res) => {
        console.log(res);
        inputRef.current.value = (res == null ? void 0 : res.permohonan.nama_penerima) ?? "";
        onValueChange(res ?? null, listOptions[0]);
      });
    }
  }
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx(
      Combobox,
      {
        value: selectedPerson ?? void 0,
        by: comparePeople,
        onChange,
        children: /* @__PURE__ */ jsxs("div", { className: twMerge(`relative`, className, zIndex), children: [
          /* @__PURE__ */ jsxs(
            "div",
            {
              className: twMerge(
                "relative overflow-visible items-center flex w-full cursor-default bg-white text-left rounded-lg shadow-md focus:outline-none focus-visible:ring-2 focus-visible:ring-white/75 focus-visible:ring-offset-2 focus-visible:ring-offset-teal-300 sm:text-sm ",
                className
              ),
              children: [
                /* @__PURE__ */ jsx(
                  ListboxSelect,
                  {
                    className: "w-full md:w-2/6 text-gray-800",
                    listOptions,
                    onListChange: (e) => setSearchKey(e.value)
                  }
                ),
                /* @__PURE__ */ jsxs("div", { className: "flex items-center", children: [
                  /* @__PURE__ */ jsx(
                    "input",
                    {
                      tabIndex: -1,
                      type: "checkbox",
                      className: "w-3 h-3 rounded-md text-sm text-gray-600 mx-1",
                      disabled: isDisabledCheck,
                      onChange: () => {
                        setAllPerm((prev) => !prev);
                      },
                      defaultChecked: isChecked
                    }
                  ),
                  /* @__PURE__ */ jsx("label", { className: "text-xs text-gray-800 mr-1", children: "all" })
                ] }),
                /* @__PURE__ */ jsx(
                  Combobox.Input,
                  {
                    ref: inputRef,
                    className: "w-full border-none py-2 pl-3 pr-8 text-sm leading-5 text-gray-900 focus:ring-0 rounded-r-lg",
                    displayValue: (transpermohonan) => {
                      var _a;
                      return ((_a = transpermohonan.permohonan) == null ? void 0 : _a.nama_penerima) ?? "";
                    },
                    onChange: (event) => setQuery(event.target.value),
                    autoComplete: "off",
                    placeholder: "Pilih Permohonan"
                  }
                ),
                inputRef.current && inputRef.current.value != "" && /* @__PURE__ */ jsx(
                  "a",
                  {
                    tabIndex: -1,
                    href: "#",
                    className: "absolute inset-y-0 right-10 flex items-center pr-2",
                    onClick: clearValue,
                    children: /* @__PURE__ */ jsx(
                      XCircleIcon,
                      {
                        className: "h-5 w-5 text-gray-400",
                        "aria-hidden": "true"
                      }
                    )
                  }
                ),
                /* @__PURE__ */ jsxs(Combobox.Button, { className: "absolute inset-y-0 right-5 flex items-center pr-2 ", children: [
                  isLoading && /* @__PURE__ */ jsx(LoadingSpinner, {}),
                  /* @__PURE__ */ jsx(
                    ChevronUpDownIcon,
                    {
                      className: "h-5 w-5 text-gray-400",
                      "aria-hidden": "true"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsx(
                  "a",
                  {
                    className: "absolute inset-y-0 right-0 flex items-center pr-2",
                    href: "#",
                    children: /* @__PURE__ */ jsx(
                      QrCodeIcon,
                      {
                        className: "h-5 w-5 text-gray-400",
                        "aria-hidden": "true",
                        onClick: () => {
                          setshowCamera(true);
                        }
                      }
                    )
                  }
                )
              ]
            }
          ),
          /* @__PURE__ */ jsx(
            Transition,
            {
              as: Fragment$1,
              leave: "transition ease-in duration-100",
              leaveFrom: "opacity-100",
              leaveTo: "opacity-0",
              afterLeave: () => setQuery(""),
              children: /* @__PURE__ */ jsxs(Combobox.Options, { className: "absolute mt-1 max-h-60 -ml-6 w-[calc(100vw-1rem)] md:w-[110vh] overflow-auto rounded-md bg-white py-0 shadow-lg ring-1 ring-black/5 focus:outline-none text-xs", children: [
                filteredOption && filteredOption.length > 0 ? /* @__PURE__ */ jsxs(
                  "div",
                  {
                    className: `flex flex-row p-2 w-full font-bold bg-lightBlue-800 text-lightBlue-300 border-lightBlue-700 z-50`,
                    children: [
                      /* @__PURE__ */ jsx("div", { className: "w-[18%] md:w-[8%]", children: "No Daftar" }),
                      /* @__PURE__ */ jsx("div", { className: "w-[10%] hidden md:block", children: "Proses" }),
                      /* @__PURE__ */ jsx("div", { className: "w-[16%] hidden md:block", children: "Pelepas" }),
                      /* @__PURE__ */ jsx("div", { className: "w-[36%] md:w-[16%]", children: "Penerima" }),
                      /* @__PURE__ */ jsx("div", { className: "w-[18%] md:w-[20%]", children: "Alas Hak" }),
                      /* @__PURE__ */ jsx("div", { className: "w-[27%] md:w-[20%]", children: "Letak" }),
                      /* @__PURE__ */ jsx("div", { className: "w-[10%] hidden md:block", children: "Users" })
                    ]
                  }
                ) : null,
                filteredOption && filteredOption.length === 0 && query !== "" ? /* @__PURE__ */ jsx("div", { className: "relative cursor-default select-none px-2 py-2 text-gray-700", children: "Nothing value." }) : filteredOption && filteredOption.map(
                  (transpermohonan) => /* @__PURE__ */ jsx(
                    Combobox.Option,
                    {
                      className: ({ active }) => `relative cursor-default select-none pr-2 ${active ? "bg-lightBlue-600 text-white" : "text-lightBlue-950"}`,
                      value: transpermohonan,
                      children: ({ selected, active }) => {
                        var _a, _b, _c, _d;
                        return /* @__PURE__ */ jsxs(
                          "div",
                          {
                            className: `flex flex-row p-2 w-full ${selected ? "font-bold" : ""}`,
                            children: [
                              /* @__PURE__ */ jsx("div", { className: "w-[18%] md:w-[8%]", children: transpermohonan.no_daftar }),
                              /* @__PURE__ */ jsx("div", { className: "w-[10%] hidden md:block", children: transpermohonan.jenispermohonan.nama_jenispermohonan }),
                              /* @__PURE__ */ jsx("div", { className: "w-[16%] hidden md:block", children: (_a = transpermohonan.permohonan) == null ? void 0 : _a.nama_pelepas }),
                              /* @__PURE__ */ jsx("div", { className: "w-[36%] md:w-[16%]", children: (_b = transpermohonan.permohonan) == null ? void 0 : _b.nama_penerima }),
                              /* @__PURE__ */ jsxs("div", { className: "w-[18%] md:w-[20%]", children: [
                                (_c = transpermohonan.permohonan) == null ? void 0 : _c.nomor_hak,
                                ", L.",
                                transpermohonan.permohonan.luas_tanah,
                                "M2"
                              ] }),
                              /* @__PURE__ */ jsx("div", { className: "w-[27%] md:w-[20%]", children: (_d = transpermohonan.permohonan) == null ? void 0 : _d.letak_obyek }),
                              /* @__PURE__ */ jsx("div", { className: "w-[10%] hidden md:block", children: transpermohonan.permohonan.users && transpermohonan.permohonan.users.map(
                                (usr, i) => /* @__PURE__ */ jsx(
                                  "span",
                                  {
                                    children: usr.name
                                  },
                                  i
                                )
                              ) })
                            ]
                          }
                        );
                      }
                    },
                    transpermohonan.id
                  )
                )
              ] })
            }
          ),
          errors ? /* @__PURE__ */ jsx("span", { className: "text-sm text-red-500", children: errors }) : null
        ] })
      }
    ),
    /* @__PURE__ */ jsx(
      ModalQRCode,
      {
        showModal: showCamera,
        setShowModal: () => setshowCamera(false),
        onReadQRCode: handleReadQRCode
      }
    )
  ] });
}
export {
  TranspermohonanSelect as T
};
