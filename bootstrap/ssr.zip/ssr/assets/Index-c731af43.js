import { jsxs, jsx } from "react/jsx-runtime";
import { A as AdminLayout } from "./AdminLayout-4bc80775.js";
import { useState, useEffect } from "react";
import { twMerge } from "tailwind-merge";
import { usePage, router, Link } from "@inertiajs/react";
import { usePrevious } from "react-use";
import { pickBy } from "lodash";
import { P as Pagination } from "./Pagination-30af682d.js";
import { I as InputSearch } from "./InputSearch-6032da7e.js";
import { L as LinkButton } from "./LinkButton-a291522b.js";
import { u as useSwal } from "./useSwal-5d61a319.js";
import { A as AsyncSelectSearch } from "./AsyncSelectSearch-23c2f5cb.js";
import { M as MenuDropdown } from "./MenuDropdown-419bd59d.js";
import { S as SelectSearch } from "./SelectSearch-22ab8168.js";
import { c as copyToClipboard } from "./index-d9460823.js";
import { Tooltip } from "react-tooltip";
import "./NotificationDropdown-abde11b8.js";
import "@popperjs/core";
import "./ResponsiveNavLink-41b4fa07.js";
import "react-hot-toast";
import "./AuthContext-5300e6b5.js";
import "firebase/app";
import "firebase/auth";
import "firebase/firestore";
import "firebase/storage";
import "./bootstrap-b9d9b211.js";
import "axios";
import "firebase/messaging";
import "./MenuItem-f3c50e94.js";
import "classnames";
import "sweetalert2";
import "react-select/async";
import "react-select";
function CardTableRincianbiayaperms({
  color = "light",
  rincianbiayaperms,
  className = "",
  meta,
  labelLinks
}) {
  const { isAdmin, user, base_route, statusOpts, curstatus } = usePage().props;
  const params = new URLSearchParams(window.location.search);
  const [values, setValues] = useState({
    search: params.get("search"),
    sortBy: params.get("sortBy"),
    sortDir: params.get("sortDir"),
    status: curstatus
  });
  const prevValues = usePrevious(values);
  useState();
  useState(false);
  function handleSortLinkClick({
    sortBy,
    sortDir
  }) {
    setValues((values2) => ({ ...values2, sortBy, sortDir }));
  }
  const IconSort = ({
    sortBy,
    sortDir
  }) => {
    if (values.sortBy === sortBy && sortDir === "asc") {
      return /* @__PURE__ */ jsx("i", { className: "fa-solid fa-sort-up" });
    } else if (values.sortBy === sortBy && sortDir === "desc") {
      return /* @__PURE__ */ jsx("i", { className: "fa-solid fa-sort-down" });
    }
    return /* @__PURE__ */ jsx("i", { className: "fa-solid fa-sort" });
  };
  const handleRemoveData = (id) => {
    router.delete(route("admin.transaksi.rincianbiayaperms.destroy", id));
  };
  const cstatus = statusOpts.find((e) => e.value == values.status);
  const [curStatus, setCurStatus] = useState(
    cstatus ? cstatus : null
  );
  useEffect(() => {
    if (prevValues) {
      const query = Object.keys(pickBy(values)).length ? pickBy(values) : {};
      router.get(
        route(route().current() ? route().current() + "" : ""),
        query,
        {
          replace: true,
          preserveState: true
        }
      );
    }
  }, [values]);
  return /* @__PURE__ */ jsxs(
    "div",
    {
      className: twMerge(
        "relative flex flex-col min-w-0 break-words w-full mb-6 shadow-lg shadow-slate-700 rounded-md py-1 ",
        color === "light" ? "bg-white" : "bg-lightBlue-900 text-white",
        className
      ),
      children: [
        /* @__PURE__ */ jsx("div", { className: "rounded-full mb-0 px-4 py-3 border-0 ", children: /* @__PURE__ */ jsxs("div", { className: "flex justify-between w-full flex-col md:flex-row", children: [
          /* @__PURE__ */ jsx("div", { className: "relative w-full max-w-full flex-grow flex-1 ", children: /* @__PURE__ */ jsx(
            "h3",
            {
              className: "font-semibold text-lg " + (color === "light" ? "text-blueGray-700" : "text-white"),
              children: "Rincian Biaya List"
            }
          ) }),
          /* @__PURE__ */ jsxs("div", { className: "flex flex-col justify-center gap-1 md:flex-row items-start w-full md:w-3/4", children: [
            isAdmin ? /* @__PURE__ */ jsx(
              AsyncSelectSearch,
              {
                placeholder: "Pilih User",
                value: user,
                name: "users",
                url: "/admin/users/api/list/",
                onChange: (e) => setValues((v) => ({
                  ...v,
                  user_id: e ? e.value : ""
                })),
                isClearable: true,
                optionLabels: ["name"],
                optionValue: "id",
                className: "text-blueGray-900 w-full md:w-1/2"
              }
            ) : null,
            /* @__PURE__ */ jsx(
              SelectSearch,
              {
                name: "status",
                className: "text-gray-800 w-full md:w-1/2",
                value: curStatus,
                options: statusOpts,
                placeholder: "Pilih Status",
                onChange: (e) => {
                  setValues((prev) => ({
                    ...prev,
                    status: e.value
                  }));
                  setCurStatus(e ? e : {});
                }
              }
            ),
            /* @__PURE__ */ jsx(
              InputSearch,
              {
                className: "w-full md:w-1/3",
                value: values.search ? values.search : "",
                onChange: (e) => setValues((v) => ({
                  ...v,
                  search: e.target.value
                }))
              }
            ),
            /* @__PURE__ */ jsx(
              LinkButton,
              {
                theme: "blue",
                href: route(
                  "admin.transaksi.rincianbiayaperms.create"
                ),
                children: /* @__PURE__ */ jsxs("span", { className: "flex items-center gap-1", children: [
                  /* @__PURE__ */ jsx("i", { className: "fa-solid fa-plus" }),
                  " New"
                ] })
              }
            )
          ] })
        ] }) }),
        /* @__PURE__ */ jsx("div", { className: "block w-full overflow-x-auto overflow-y-visible md:overflow-auto", children: /* @__PURE__ */ jsxs("table", { className: "items-center w-full bg-transparent border-collapse", children: [
          /* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", { children: [
            /* @__PURE__ */ jsx(
              "th",
              {
                className: "px-2 align-middle border border-solid py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left " + (color === "light" ? "bg-blueGray-50 text-blueGray-500 border-blueGray-100" : "bg-lightBlue-800 text-lightBlue-300 border-lightBlue-700"),
                children: /* @__PURE__ */ jsx(
                  Link,
                  {
                    href: "#",
                    onClick: (e) => handleSortLinkClick({
                      sortBy: "created_at",
                      sortDir: values.sortDir === "asc" ? "desc" : "asc"
                    }),
                    children: /* @__PURE__ */ jsxs("div", { className: "flex flex-row justify-between", children: [
                      /* @__PURE__ */ jsx("span", { children: "Tanggal" }),
                      /* @__PURE__ */ jsx(
                        IconSort,
                        {
                          sortBy: "created_at",
                          sortDir: values.sortDir || ""
                        }
                      )
                    ] })
                  }
                )
              }
            ),
            /* @__PURE__ */ jsx(
              "th",
              {
                className: "px-2 align-middle border border-solid py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left " + (color === "light" ? "bg-blueGray-50 text-blueGray-500 border-blueGray-100" : "bg-lightBlue-800 text-lightBlue-300 border-lightBlue-700"),
                children: /* @__PURE__ */ jsx("div", { className: "flex flex-row justify-between", children: /* @__PURE__ */ jsx("span", { children: "Pemasukan" }) })
              }
            ),
            /* @__PURE__ */ jsx(
              "th",
              {
                className: "px-2 align-middle border border-solid py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left " + (color === "light" ? "bg-blueGray-50 text-blueGray-500 border-blueGray-100" : "bg-lightBlue-800 text-lightBlue-300 border-lightBlue-700"),
                children: /* @__PURE__ */ jsx("div", { className: "flex flex-row justify-between", children: /* @__PURE__ */ jsx("span", { children: "Pengeluaran" }) })
              }
            ),
            /* @__PURE__ */ jsx(
              "th",
              {
                className: "px-2 align-middle border border-solid py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left " + (color === "light" ? "bg-blueGray-50 text-blueGray-500 border-blueGray-100" : "bg-lightBlue-800 text-lightBlue-300 border-lightBlue-700"),
                children: /* @__PURE__ */ jsx("div", { className: "flex flex-row justify-between", children: /* @__PURE__ */ jsx("span", { children: "Sisa Saldo" }) })
              }
            ),
            /* @__PURE__ */ jsx(
              "th",
              {
                className: "px-2 align-middle border border-solid py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left " + (color === "light" ? "bg-blueGray-50 text-blueGray-500 border-blueGray-100" : "bg-lightBlue-800 text-lightBlue-300 border-lightBlue-700"),
                children: /* @__PURE__ */ jsx("div", { className: "flex flex-row justify-between", children: /* @__PURE__ */ jsx("span", { children: "Keterangan" }) })
              }
            ),
            /* @__PURE__ */ jsx(
              "th",
              {
                className: "px-2 align-middle border border-solid py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left " + (color === "light" ? "bg-blueGray-50 text-blueGray-500 border-blueGray-100" : "bg-lightBlue-800 text-lightBlue-300 border-lightBlue-700"),
                children: /* @__PURE__ */ jsx("div", { className: "flex flex-row justify-between", children: /* @__PURE__ */ jsx("span", { children: "Transaksi" }) })
              }
            ),
            /* @__PURE__ */ jsx(
              "th",
              {
                className: "px-2 align-middle border border-solid py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left " + (color === "light" ? "bg-blueGray-50 text-blueGray-500 border-blueGray-100" : "bg-lightBlue-800 text-lightBlue-300 border-lightBlue-700"),
                children: /* @__PURE__ */ jsx("div", { className: "flex flex-row justify-between", children: /* @__PURE__ */ jsx("span", { children: "Permohonan" }) })
              }
            ),
            /* @__PURE__ */ jsx(
              "th",
              {
                className: "px-2 align-middle border border-solid py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left " + (color === "light" ? "bg-blueGray-50 text-blueGray-500 border-blueGray-100" : "bg-lightBlue-800 text-lightBlue-300 border-lightBlue-700"),
                children: /* @__PURE__ */ jsx("div", { className: "flex flex-row justify-between", children: /* @__PURE__ */ jsx("span", { children: "User" }) })
              }
            ),
            /* @__PURE__ */ jsx(
              "th",
              {
                className: "px-2 align-middle border border-solid py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left " + (color === "light" ? "bg-blueGray-50 text-blueGray-500 border-blueGray-100" : "bg-lightBlue-800 text-lightBlue-300 border-lightBlue-700"),
                children: /* @__PURE__ */ jsx("div", { className: "flex flex-row justify-between", children: /* @__PURE__ */ jsx("span", { children: "Status" }) })
              }
            ),
            /* @__PURE__ */ jsx(
              "th",
              {
                className: "px-2 align-middle border border-solid py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left " + (color === "light" ? "bg-blueGray-50 text-blueGray-500 border-blueGray-100" : "bg-lightBlue-800 text-lightBlue-300 border-lightBlue-700"),
                children: "Menu"
              }
            )
          ] }) }),
          /* @__PURE__ */ jsx("tbody", { children: rincianbiayaperms.map(
            ({
              id,
              tgl_rincianbiayaperm,
              total_pemasukan,
              total_pengeluaran,
              sisa_saldo,
              ket_rincianbiayaperm,
              user: user2,
              status_rincianbiayaperm,
              permohonan,
              letak_obyek,
              nama_jenispermohonan,
              no_daftar
            }, index) => /* @__PURE__ */ jsxs("tr", { children: [
              /* @__PURE__ */ jsx("td", { className: "border-t-0 px-2 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-2", children: tgl_rincianbiayaperm }),
              /* @__PURE__ */ jsx("td", { className: "border-t-0 px-2 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-2", children: total_pemasukan }),
              /* @__PURE__ */ jsx("td", { className: "border-t-0 px-2 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-2", children: total_pengeluaran }),
              /* @__PURE__ */ jsx("td", { className: "border-t-0 px-2 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-2", children: sisa_saldo }),
              /* @__PURE__ */ jsx("td", { className: "border-t-0 px-2 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-2", children: ket_rincianbiayaperm }),
              /* @__PURE__ */ jsx("td", { className: "border-t-0 px-2 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-2", children: nama_jenispermohonan }),
              /* @__PURE__ */ jsx("td", { className: "border-t-0 px-2 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-2", children: /* @__PURE__ */ jsxs("div", { className: "flex flex-col items-start justify-start", children: [
                /* @__PURE__ */ jsx(Tooltip, { id: "my-tooltip" }),
                /* @__PURE__ */ jsx(
                  "div",
                  {
                    "data-tooltip-id": "my-tooltip",
                    "data-tooltip-content": "Copy No Daftar",
                    "data-tooltip-place": "top",
                    className: "hover:cursor-pointer hover:text-lightBlue-300",
                    onClick: (e) => copyToClipboard(
                      `${no_daftar}`
                    ),
                    children: permohonan
                  }
                ),
                /* @__PURE__ */ jsx("div", { children: letak_obyek })
              ] }) }),
              /* @__PURE__ */ jsx("td", { className: "border-t-0 px-2 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-2", children: user2.name }),
              /* @__PURE__ */ jsx("td", { className: "border-t-0 px-2 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-2", children: status_rincianbiayaperm }),
              /* @__PURE__ */ jsx("td", { className: "border-t-0 px-2 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap py-4", children: /* @__PURE__ */ jsxs(MenuDropdown, { children: [
                /* @__PURE__ */ jsxs(
                  Link,
                  {
                    href: route(
                      "admin.transaksi.rincianbiayaperms.edit",
                      id
                    ),
                    className: "text-sm py-2 px-4 font-normal block w-full whitespace-nowrap bg-transparent text-blueGray-700",
                    children: [
                      /* @__PURE__ */ jsx("i", { className: "fas fa-edit" }),
                      /* @__PURE__ */ jsx("span", { children: " Edit" })
                    ]
                  }
                ),
                /* @__PURE__ */ jsxs(
                  "a",
                  {
                    href: "#",
                    onClick: (e) => {
                      e.preventDefault();
                      useSwal.confirm({
                        title: "Hapus Data",
                        text: "apakah akan menghapus?"
                      }).then((result) => {
                        if (result.isConfirmed) {
                          handleRemoveData(
                            id
                          );
                        }
                      });
                    },
                    className: "text-sm py-2 px-4 font-normal block w-full whitespace-nowrap bg-transparent text-blueGray-700 hover:text-blue-400 transition hover:scale-110 origin-top-left",
                    children: [
                      /* @__PURE__ */ jsx("i", { className: "fas fa-trash" }),
                      /* @__PURE__ */ jsx("span", { children: " Hapus" })
                    ]
                  }
                )
              ] }) })
            ] }, index)
          ) })
        ] }) }),
        meta.total > meta.per_page ? /* @__PURE__ */ jsx(
          "div",
          {
            className: "flex justify-end px-2 py-1  " + (color === "light" ? "bg-blueGray-50 text-blueGray-500 border-blueGray-100" : "bg-lightBlue-800 text-lightBlue-300 border-lightBlue-700"),
            children: /* @__PURE__ */ jsx(Pagination, { links: meta.links, labelLinks })
          }
        ) : null
      ]
    }
  );
}
const Index = ({
  rincianbiayaperms
}) => {
  const { data, meta, links } = rincianbiayaperms;
  return /* @__PURE__ */ jsx(AdminLayout, { children: /* @__PURE__ */ jsx(
    CardTableRincianbiayaperms,
    {
      color: "dark",
      rincianbiayaperms: data,
      meta,
      labelLinks: links
    }
  ) });
};
export {
  Index as default
};
