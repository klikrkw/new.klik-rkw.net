import { jsxs, jsx } from "react/jsx-runtime";
import { I as Input } from "./Input-72be4948.js";
import { L as LinkButton } from "./LinkButton-a291522b.js";
import { L as LoadingButton } from "./LoadingButton-c9189101.js";
import { A as AdminLayout } from "./AdminLayout-4bc80775.js";
import { useForm, usePage, router } from "@inertiajs/react";
import { M as MoneyInput } from "./MoneyInput-87a36109.js";
import { S as SelectSearch } from "./SelectSearch-22ab8168.js";
import { useState, useRef, useEffect } from "react";
import { C as CardDkeluarbiayapermuserList } from "./CardDkeluarbiayapermuserList-6ee92950.js";
import { B as Button } from "./Button-e2b11bd9.js";
import { M as ModalCetakLaporan } from "./ModalCetakLaporan-767963a0.js";
import { M as Modal } from "./Modal-d06b3568.js";
import { t as toRupiah } from "./index-d9460823.js";
import { M as ModalAddPermohonan } from "./ModalAddPermohonan-72cf984e.js";
import { C as CardPermohonanEditable } from "./CardPermohonanEditable-d1f1f0c5.js";
import { T as TranspermohonanSelect } from "./TranspermohonanSelect-e6be2ec6.js";
import "firebase/storage";
import { u as useAuth } from "./AuthContext-5300e6b5.js";
import "react-image-file-resizer";
import { U as UploadImage } from "./UploadImage-dc2b2f0d.js";
import "tailwind-merge";
import "classnames";
import "./NotificationDropdown-abde11b8.js";
import "@popperjs/core";
import "./ResponsiveNavLink-41b4fa07.js";
import "react-hot-toast";
import "./MenuItem-f3c50e94.js";
import "react-number-format";
import "lodash";
import "react-select";
import "./Pagination-30af682d.js";
import "./useScreenSize-4351026c.js";
import "./useSwal-5d61a319.js";
import "sweetalert2";
import "./bootstrap-b9d9b211.js";
import "axios";
import "react-dom";
import "@emotion/react";
import "@emotion/cache";
import "react-loader-spinner";
import "@headlessui/react";
import "@heroicons/react/20/solid";
import "swr";
import "./ListboxSelect-3ce899e5.js";
import "@zxing/browser";
import "firebase/app";
import "firebase/auth";
import "firebase/firestore";
import "firebase/messaging";
const Edit = ({
  keluarbiayapermuser,
  itemkegiatanOpts,
  status_keluarbiayapermusers,
  is_admin,
  base_route
}) => {
  var _a, _b, _c;
  const selStatusKeluarbiayapermuser = status_keluarbiayapermusers.find(
    (item) => item.value == keluarbiayapermuser.status_keluarbiayapermuser
  );
  const [statusKeluarbiayapermuser, setStatusKeluarbiayapermuser] = useState(
    selStatusKeluarbiayapermuser ? selStatusKeluarbiayapermuser : null
  );
  const [showStatusDialog, setShowStatusDialog] = useState(false);
  const { data, setData, errors, processing, post, reset } = useForm({
    itemkegiatan: void 0,
    itemkegiatan_id: "",
    jumlah_biaya: "0",
    ket_biaya: "",
    permohonan: void 0,
    transpermohonan_id: "",
    image_dkeluarbiayapermuser: "",
    _method: "PUT"
  });
  const firstInput = useRef(null);
  const [showModalLaporan, setShowModalLaporan] = useState(false);
  const [showModalAddPermohonan, setShowModalAddPermohonan] = useState(false);
  function handleUpdateStatus(e) {
    e.preventDefault();
    const data2 = {
      status_keluarbiayapermuser: statusKeluarbiayapermuser == null ? void 0 : statusKeluarbiayapermuser.value
    };
    router.put(
      route(
        base_route + "transaksi.keluarbiayapermusers.status.update",
        keluarbiayapermuser.id
      ),
      data2,
      {
        onSuccess: (e2) => {
          setShowStatusDialog(false);
        }
      }
    );
  }
  function handleSubmit(e) {
    e.preventDefault();
    post(
      route(
        base_route + "transaksi.keluarbiayapermusers.update",
        keluarbiayapermuser.id
      ),
      {
        onSuccess: () => {
          reset();
          if (firstInput && firstInput.current) {
            firstInput.current.value = "";
            firstInput.current.focus();
          }
        }
      }
    );
  }
  function prosesLaporan(e) {
    e.preventDefault();
    setShowModalLaporan(true);
  }
  useEffect(() => {
    if (firstInput.current) {
      firstInput.current.focus();
    }
  }, []);
  const setPermohonan = (perm) => {
    if (firstInput && firstInput.current) {
      firstInput.current.value = (perm == null ? void 0 : perm.nama_penerima) ?? "";
    }
    setData({
      ...data,
      permohonan: perm,
      transpermohonan_id: (perm == null ? void 0 : perm.transpermohonan) ? perm.transpermohonan.id : ""
    });
  };
  useRef();
  useState(null);
  useState();
  const { currentUser, login, logout } = useAuth();
  const { fbtoken } = usePage().props;
  useEffect(() => {
    if (!currentUser) {
      login(fbtoken);
    }
    return () => {
      if (currentUser) {
        console.log("logout firebase");
        logout();
      }
    };
  }, []);
  return /* @__PURE__ */ jsxs(AdminLayout, { children: [
    /* @__PURE__ */ jsx("div", { className: "flex content-center items-center justify-center relative -top-6", children: /* @__PURE__ */ jsx("div", { className: "w-full lg:w-11/12 px-4 ", children: /* @__PURE__ */ jsxs("div", { className: "relative flex flex-col min-w-0 break-words w-full mb-2 shadow-lg shadow-slate-400 rounded-lg bg-blueGray-100 border-0", children: [
      /* @__PURE__ */ jsx("div", { className: "rounded-t mb-1 px-4 py-4 ", children: /* @__PURE__ */ jsxs("div", { className: "w-full grid grid-cols-1 md:grid-cols-2 bg-lightBlue-800 text-lightBlue-100 px-4 py-2 shadow-md rounded-lg", children: [
        /* @__PURE__ */ jsx("div", { className: "text-left", children: /* @__PURE__ */ jsx("h6", { className: "font-semibold", children: "PENGELUARAN BIAYA PERMOHONAN" }) }),
        /* @__PURE__ */ jsx("div", { className: "text-left md:text-right", children: keluarbiayapermuser.created_at })
      ] }) }),
      /* @__PURE__ */ jsxs("div", { className: "flex-auto px-4 lg:px-6 py-4 pt-0", children: [
        /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-2", children: [
          /* @__PURE__ */ jsx(
            Input,
            {
              name: "instansi",
              label: "Instansi",
              disabled: true,
              value: (_a = keluarbiayapermuser.instansi) == null ? void 0 : _a.nama_instansi
            }
          ),
          /* @__PURE__ */ jsx(
            Input,
            {
              name: "metodebayar",
              label: "Metode Bayar",
              disabled: true,
              value: (_b = keluarbiayapermuser.metodebayar) == null ? void 0 : _b.nama_metodebayar
            }
          ),
          /* @__PURE__ */ jsxs("div", { className: "flex flex-col", children: [
            /* @__PURE__ */ jsx("div", { className: "mb-2 font-bold text-xs", children: "KASBON" }),
            /* @__PURE__ */ jsx("div", { className: "px-2 py-2 rounded text-sm bg-blueGray-200 text-blueGray-600", children: keluarbiayapermuser.kasbons.length > 0 ? keluarbiayapermuser.kasbons.map(
              (e, i) => /* @__PURE__ */ jsxs("span", { children: [
                e.id,
                " :",
                " ",
                toRupiah(
                  e.jumlah_kasbon
                )
              ] }, i)
            ) : /* @__PURE__ */ jsx("span", { children: "No Kasbon" }) })
          ] })
        ] }),
        keluarbiayapermuser && keluarbiayapermuser.status_keluarbiayapermuser == "wait_approval" ? /* @__PURE__ */ jsx("form", { onSubmit: handleSubmit, children: /* @__PURE__ */ jsxs("div", { className: "w-full grid grid-cols-1 md:grid-cols-2 md:gap-2", children: [
          /* @__PURE__ */ jsxs("div", { className: "w-full grid grid-cols-1", children: [
            /* @__PURE__ */ jsxs("div", { className: "flex flex-row justify-between items-center", children: [
              /* @__PURE__ */ jsx(
                TranspermohonanSelect,
                {
                  inputRef: firstInput,
                  value: (_c = data.permohonan) == null ? void 0 : _c.transpermohonan,
                  className: "mb-1 w-full mr-2",
                  errors: errors.transpermohonan_id,
                  onValueChange: (e) => {
                    setPermohonan(
                      e == null ? void 0 : e.permohonan
                    );
                  },
                  isChecked: true
                }
              ),
              /* @__PURE__ */ jsx(
                "a",
                {
                  tabIndex: -1,
                  href: "#",
                  className: "w-8 h-8 px-2 py-1 rounded-full bg-blue-600/20 shadow-xl mb-1",
                  onClick: (e) => {
                    e.preventDefault();
                    setShowModalAddPermohonan(
                      true
                    );
                  },
                  children: /* @__PURE__ */ jsx("i", { className: "fas fa-add text-md text-center text-gray-700" })
                }
              )
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 md:grid-cols-2 md:gap-2", children: [
              /* @__PURE__ */ jsx(
                SelectSearch,
                {
                  placeholder: "Pilih Kegiatan",
                  name: "itemkegiatan_id",
                  value: data.itemkegiatan,
                  options: itemkegiatanOpts,
                  onChange: (e) => setData({
                    ...data,
                    itemkegiatan: e ? e : {},
                    itemkegiatan_id: e ? e.value : ""
                  }),
                  errors: errors.itemkegiatan_id
                }
              ),
              /* @__PURE__ */ jsx(
                Input,
                {
                  name: "ket_biaya",
                  placeholder: "Keterangan",
                  errors: errors.ket_biaya,
                  value: data.ket_biaya,
                  onChange: (e) => setData(
                    "ket_biaya",
                    e.target.value
                  )
                }
              )
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "flex justify-between gap-2 items-start", children: [
              /* @__PURE__ */ jsx(
                MoneyInput,
                {
                  name: "jumlah_biaya",
                  errors: errors.jumlah_biaya,
                  autoComplete: "off",
                  value: data.jumlah_biaya,
                  placeholder: "Jumlah",
                  onValueChange: (e) => setData((prev) => ({
                    ...prev,
                    jumlah_biaya: e.value
                  }))
                }
              ),
              /* @__PURE__ */ jsx(
                LoadingButton,
                {
                  theme: "black",
                  loading: processing,
                  type: "submit",
                  className: "pb-3 text-sm",
                  children: /* @__PURE__ */ jsx("span", { children: "Simpan" })
                }
              ),
              /* @__PURE__ */ jsx(
                Button,
                {
                  disabled: !is_admin,
                  theme: "blueGrey",
                  className: "py-2 text-sm text-blueGray-500",
                  onClick: (e) => {
                    e.preventDefault();
                    setShowStatusDialog(
                      true
                    );
                  },
                  children: /* @__PURE__ */ jsx("span", { children: keluarbiayapermuser.status_keluarbiayapermuser })
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsx(
            UploadImage,
            {
              name: "image_dkeluarbiaya",
              image: data.image_dkeluarbiayapermuser,
              imagePath: "/images/dkeluarbiayapermusers/",
              setImage: (imgfile) => setData(
                "image_dkeluarbiayapermuser",
                imgfile
              )
            }
          ),
          /* @__PURE__ */ jsx("div", { className: "w-full flex items-start", children: /* @__PURE__ */ jsx(
            CardPermohonanEditable,
            {
              permohonan: data.permohonan,
              base_route,
              setPermohonan
            }
          ) })
        ] }) }) : /* @__PURE__ */ jsx(
          Button,
          {
            disabled: !is_admin,
            theme: "blueGrey",
            className: "py-2 text-sm text-blueGray-500",
            onClick: (e) => {
              e.preventDefault();
              setShowStatusDialog(true);
            },
            children: /* @__PURE__ */ jsx("span", { children: keluarbiayapermuser.status_keluarbiayapermuser })
          }
        ),
        /* @__PURE__ */ jsx("div", { className: "w-full flex items-start", children: /* @__PURE__ */ jsx(
          CardDkeluarbiayapermuserList,
          {
            keluarbiayapermuser
          }
        ) }),
        /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsx(
            LinkButton,
            {
              theme: "blueGrey",
              href: route(
                base_route + "transaksi.keluarbiayapermusers.index"
              ),
              children: /* @__PURE__ */ jsx("span", { children: "Kembali" })
            }
          ),
          /* @__PURE__ */ jsx(
            Button,
            {
              disabled: parseInt(
                keluarbiayapermuser.jumlah_biaya
              ) == 0,
              theme: "blue",
              onClick: (e) => prosesLaporan(e),
              children: /* @__PURE__ */ jsx("span", { children: "Cetak" })
            }
          )
        ] })
      ] })
    ] }) }) }),
    /* @__PURE__ */ jsx(
      ModalCetakLaporan,
      {
        showModal: showModalLaporan,
        setShowModal: setShowModalLaporan,
        src: route(
          "keluarbiayapermusers.lap.staf",
          keluarbiayapermuser.id
        )
      }
    ),
    /* @__PURE__ */ jsx(
      ModalAddPermohonan,
      {
        showModal: showModalAddPermohonan,
        setShowModal: setShowModalAddPermohonan,
        setPermohonan,
        src: route(base_route + "permohonans.modal.create")
      }
    ),
    showStatusDialog ? /* @__PURE__ */ jsx(
      Modal,
      {
        closeable: true,
        show: showStatusDialog,
        maxWidth: "md",
        onClose: () => setShowStatusDialog(false),
        children: /* @__PURE__ */ jsxs("div", { className: "w-full p-4 flex flex-col gap-2", children: [
          /* @__PURE__ */ jsx("h1", { children: "Update Status Pengeluaran" }),
          /* @__PURE__ */ jsx(
            SelectSearch,
            {
              placeholder: "Status",
              name: "status_keluarbiayapermuser",
              value: statusKeluarbiayapermuser,
              options: status_keluarbiayapermusers,
              onChange: (e) => setStatusKeluarbiayapermuser(e)
            }
          ),
          /* @__PURE__ */ jsxs("div", { className: "flex justify-end gap-2", children: [
            /* @__PURE__ */ jsx(
              Button,
              {
                theme: "blue",
                onClick: (e) => handleUpdateStatus(e),
                children: /* @__PURE__ */ jsx("span", { children: "Simpan" })
              }
            ),
            /* @__PURE__ */ jsx(
              Button,
              {
                theme: "blueGrey",
                onClick: (e) => setShowStatusDialog(false),
                children: /* @__PURE__ */ jsx("span", { children: "Batal" })
              }
            )
          ] })
        ] })
      }
    ) : null
  ] });
};
export {
  Edit as default
};
