import { jsxs, jsx, Fragment } from "react/jsx-runtime";
import { P as Pilihstatusprosesperm } from "./PilihStatusprosesperm-521513a1.js";
import { S as SelectSearch } from "./SelectSearch-22ab8168.js";
import { usePage, router, useForm, Link } from "@inertiajs/react";
import { pickBy } from "lodash";
import { useState, useEffect } from "react";
import { usePrevious } from "react-use";
import { M as Modal } from "./Modal-d06b3568.js";
import { L as LoadingButton } from "./LoadingButton-c9189101.js";
import { L as LinkButton } from "./LinkButton-a291522b.js";
import { I as Input } from "./Input-72be4948.js";
import { u as useSwal } from "./useSwal-5d61a319.js";
import moment from "moment";
import { D as DateInput } from "./DateInput-8d13eeac.js";
import { P as Pagination } from "./Pagination-30af682d.js";
const CardFilterProsespermohonan = ({ itemprosespermsOpts }) => {
  const {
    itemprosesperm_id,
    statusprosesperms,
    statusprosesperm_id,
    transpermohonan_id,
    user_id,
    permohonan,
    user,
    userOpts
  } = usePage().props;
  const [values, setValues] = useState({
    itemprosesperm_id,
    statusprosesperm_id,
    transpermohonan_id,
    permohonan,
    user_id
  });
  const prevValues = usePrevious(values);
  const itemprosesperm = itemprosespermsOpts.find(
    (e) => e.value == itemprosesperm_id
  );
  const statusprosesperm = statusprosesperms.find(
    (e) => e.id == statusprosesperm_id
  );
  const [cUser, setCUser] = useState(user);
  useEffect(() => {
    if (prevValues) {
      const query = Object.keys(pickBy(values)).length ? pickBy(values) : {};
      router.get(
        route(route().current() ? route().current() + "" : ""),
        query,
        {
          replace: true,
          preserveState: true
        }
      );
    }
  }, [values]);
  return /* @__PURE__ */ jsxs("div", { className: "py-4 px-10 bg-blueGray-200 shadow-lg rounded-md flex flex-col shadow-gray-400", children: [
    /* @__PURE__ */ jsx("h1", { className: "font-bold text-lightBlue-700 mb-2", children: "Filter" }),
    /* @__PURE__ */ jsx(
      SelectSearch,
      {
        name: "user",
        value: cUser,
        options: userOpts,
        placeholder: "Pilih Petugas",
        onChange: (e) => {
          setValues((prev) => ({
            ...prev,
            user_id: e.value
          }));
          setCUser(e);
        }
      }
    ),
    /* @__PURE__ */ jsx(
      SelectSearch,
      {
        options: itemprosespermsOpts,
        value: itemprosesperm,
        onChange: (e) => {
          setValues((v) => ({
            ...v,
            itemprosesperm_id: e.value
          }));
        },
        className: "mb-2"
      }
    ),
    /* @__PURE__ */ jsx(
      Pilihstatusprosesperm,
      {
        statusprosesperms,
        statusprosesperm,
        setStatusprosesperm: (e) => {
          setValues((v) => ({
            ...v,
            statusprosesperm_id: e.id
          }));
        }
      }
    )
  ] });
};
const ModalEditProsespermohonan = ({
  showModal,
  setShowModal,
  prosespermohonan,
  statusprosesperm
}) => {
  const { statuspermOpts, base_route = "admin." } = usePage().props;
  const cstatusperm = statuspermOpts.find(
    (item) => item.value == (statusprosesperm == null ? void 0 : statusprosesperm.id)
  );
  const { data, setData, errors, post, processing, reset } = useForm({
    prosespermohonan_id: (prosespermohonan == null ? void 0 : prosespermohonan.id) || "",
    prosespermohonan,
    statusprosesperm_id: (cstatusperm == null ? void 0 : cstatusperm.value) || "",
    statusprosesperm: cstatusperm,
    catatan_statusprosesperm: (statusprosesperm == null ? void 0 : statusprosesperm.pivot.catatan_statusprosesperm) || "",
    is_alert: (prosespermohonan == null ? void 0 : prosespermohonan.is_alert) || false,
    start: moment((prosespermohonan == null ? void 0 : prosespermohonan.start) || Date.now()).format(
      "YYYY-MM-DD HH:mm"
    ),
    end: moment((prosespermohonan == null ? void 0 : prosespermohonan.end) || Date.now()).format(
      "YYYY-MM-DD HH:mm"
    ),
    _method: "POST"
  });
  function handleSubmit(e) {
    e.preventDefault();
    useSwal.confirm({
      title: "Simpan Data",
      text: "apakah akan menyimpan?"
    }).then((result) => {
      if (result.isConfirmed) {
        post(
          route(
            base_route + "transaksi.prosespermohonans.statusprosesperms.store",
            data.prosespermohonan_id
          ),
          {
            onSuccess: () => {
              reset(
                "prosespermohonan_id",
                "statusprosesperm_id",
                "catatan_statusprosesperm"
              );
              setShowModal(false);
            }
          }
        );
      }
    });
  }
  return /* @__PURE__ */ jsx(
    Modal,
    {
      show: showModal,
      maxWidth: "md",
      closeable: false,
      onClose: () => alert("modal close"),
      children: /* @__PURE__ */ jsx("div", { className: "p-4", children: /* @__PURE__ */ jsxs("form", { onSubmit: handleSubmit, children: [
        /* @__PURE__ */ jsx(
          SelectSearch,
          {
            name: "itemprosesperm_id",
            label: "Status Proses",
            value: data.statusprosesperm,
            options: statuspermOpts,
            onChange: (e) => setData({
              ...data,
              statusprosesperm_id: e ? e.value : "",
              statusprosesperm: e ? e : {}
            }),
            errors: errors.statusprosesperm_id
          }
        ),
        /* @__PURE__ */ jsx(
          Input,
          {
            name: "catatan_statusprosesperm",
            label: "Catatan",
            errors: errors.catatan_statusprosesperm,
            value: data.catatan_statusprosesperm,
            onChange: (e) => setData("catatan_statusprosesperm", e.target.value)
          }
        ),
        /* @__PURE__ */ jsx("div", { className: "relative h-full mr-4 mt-2", children: /* @__PURE__ */ jsxs("label", { className: "inline-flex items-center cursor-pointer", children: [
          /* @__PURE__ */ jsx(
            "input",
            {
              id: "customCheckAlert",
              type: "checkbox",
              className: "form-checkbox border-0 rounded text-blueGray-700 ml-1 w-5 h-5 ease-linear transition-all duration-150",
              checked: data.is_alert,
              onChange: (e) => setData("is_alert", e.target.checked)
            }
          ),
          /* @__PURE__ */ jsx("span", { className: "ml-2 text-sm font-semibold text-blueGray-600", children: "Ingatkan" })
        ] }) }),
        data.is_alert ? /* @__PURE__ */ jsxs("div", { className: "w-full flex flex-col gap-2 mb-4", children: [
          /* @__PURE__ */ jsx(
            DateInput,
            {
              label: "Start",
              selected: data.start,
              value: data.start,
              name: "start",
              errors: errors.start,
              showTimeSelect: true,
              customDateFormat: "DD-MMM-YYYY HH:mm",
              onChange: (e) => setData(
                "start",
                moment(e).format("YYYY-MM-DD HH:mm")
              )
            }
          ),
          /* @__PURE__ */ jsx(
            DateInput,
            {
              label: "End",
              selected: data.end,
              value: data.end,
              name: "end",
              errors: errors.end,
              customDateFormat: "DD-MMM-YYYY HH:mm",
              showTimeSelect: true,
              onChange: (e) => setData(
                "end",
                moment(e).format("YYYY-MM-DD HH:mm")
              )
            }
          )
        ] }) : null,
        /* @__PURE__ */ jsxs("div", { className: "mt-4 w-full flex justify-between items-center", children: [
          /* @__PURE__ */ jsx(
            LoadingButton,
            {
              theme: "black",
              loading: processing,
              type: "submit",
              children: /* @__PURE__ */ jsx("span", { children: "Simpan" })
            }
          ),
          /* @__PURE__ */ jsx(
            LinkButton,
            {
              href: "#",
              theme: "blue",
              onClick: (e) => {
                e.preventDefault();
                setShowModal(false);
              },
              children: /* @__PURE__ */ jsx("span", { children: "Close" })
            }
          )
        ] })
      ] }) })
    }
  );
};
const CardListProsespermohonan = ({
  prosespermohonans: { data, links }
}) => {
  const [showModalEditProsesperm, setshowModalEditProsesperm] = useState(false);
  const [prosespermohonan, setProsespermohonan] = useState();
  const [statusprosesperm, setStatusprosesperm] = useState();
  return /* @__PURE__ */ jsxs("div", { className: "p-4 flex flex-col text-xs bg-blueGray-200 rounded-md shadow-lg shadow-gray-400", children: [
    /* @__PURE__ */ jsx("h1", { className: "font-bold text-lg text-lightBlue-700", children: "Proses Permohonan" }),
    /* @__PURE__ */ jsx("ul", { className: "list-none", children: data && data.map((p, i) => /* @__PURE__ */ jsxs("li", { children: [
      /* @__PURE__ */ jsxs("div", { className: "relative w-full flex flex-row justify-between rounded-t-md mt-2 px-2 pt-2 bg-white text-lightBlue-700 font-bold text-xs", children: [
        /* @__PURE__ */ jsx("span", { children: p.itemprosesperm.nama_itemprosesperm }),
        /* @__PURE__ */ jsxs("span", { children: [
          p.transpermohonan.jenispermohonan.nama_jenispermohonan,
          " ",
          "(",
          p.transpermohonan.nodaftar_transpermohonan,
          "/",
          p.transpermohonan.thdaftar_transpermohonan,
          ")"
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "w-full grid grid-cols-1 md:grid-cols-2 mt-0 bg-white px-2 shadow", children: [
        /* @__PURE__ */ jsxs("div", { className: "w-full flex items-start flex-wrap", children: [
          /* @__PURE__ */ jsx("div", { className: "w-1/4", children: "Penerima" }),
          /* @__PURE__ */ jsx("div", { className: "w-3/4 font-bold", children: p.transpermohonan.permohonan.nama_penerima }),
          /* @__PURE__ */ jsx("div", { className: "w-1/4", children: "Pelepas" }),
          /* @__PURE__ */ jsx("div", { className: "w-3/4", children: p.transpermohonan.permohonan.nama_pelepas }),
          /* @__PURE__ */ jsx("div", { className: "w-1/4", children: "Alas Hak" }),
          /* @__PURE__ */ jsxs("div", { className: "w-3/4", children: [
            p.transpermohonan.permohonan.jenishak.singkatan,
            ".",
            p.transpermohonan.permohonan.nomor_hak,
            ",",
            " ",
            p.transpermohonan.permohonan.jenishak.singkatan == "C" ? "Ps " + p.transpermohonan.permohonan.persil + ", " + p.transpermohonan.permohonan.klas : null,
            " ",
            "L.",
            p.transpermohonan.permohonan.luas_tanah,
            "M2"
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "w-full flex items-start flex-wrap", children: [
          /* @__PURE__ */ jsx("div", { className: "w-1/4", children: "Atas Nama" }),
          /* @__PURE__ */ jsx("div", { className: "w-3/4", children: p.transpermohonan.permohonan.atas_nama }),
          /* @__PURE__ */ jsx("div", { className: "w-1/4", children: "Lokasi" }),
          /* @__PURE__ */ jsxs("div", { className: "w-3/4", children: [
            "Desa",
            " ",
            p.transpermohonan.permohonan.desa.nama_desa,
            ",",
            " ",
            p.transpermohonan.permohonan.desa.kecamatan.nama_kecamatan
          ] }),
          /* @__PURE__ */ jsx("div", { className: "w-1/4", children: "User" }),
          /* @__PURE__ */ jsx("div", { className: "w-3/4", children: p.transpermohonan.permohonan.users && p.transpermohonan.permohonan.users.length > 0 && p.transpermohonan.permohonan.users.map(
            (u, i2) => /* @__PURE__ */ jsxs("span", { children: [
              i2 > 0 ? ", " : "",
              u.name
            ] }, i2)
          ) })
        ] })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "relative w-full flex rounded-b-md px-2 py-2 pb-2 bg-white text-red-700 text-xs shadow gap-2", children: p.statusprosesperms && p.statusprosesperms.map((e, i2) => /* @__PURE__ */ jsxs(Fragment, { children: [
        /* @__PURE__ */ jsxs(
          "ol",
          {
            className: "flex flex-wrap w-9/12 list-disc ml-3 gap-1",
            children: [
              /* @__PURE__ */ jsx("li", { children: moment(
                e.pivot.created_at
              ).format(
                "DD MMM YYYY HH:mm"
              ) }),
              /* @__PURE__ */ jsx("li", { className: "ml-4", children: e.nama_statusprosesperm }),
              e.pivot.catatan_statusprosesperm ? /* @__PURE__ */ jsx("li", { className: "ml-4", children: e.pivot.catatan_statusprosesperm }) : null
            ]
          },
          i2
        ),
        /* @__PURE__ */ jsx("div", { className: "w-3/12 p-1 items-center flex justify-end", children: /* @__PURE__ */ jsx(
          Link,
          {
            href: "#",
            onClick: (event) => {
              event.preventDefault();
              setProsespermohonan(p);
              setStatusprosesperm(e);
              setshowModalEditProsesperm(
                true
              );
            },
            className: "text-lightBlue-500 background-transparent font-bold px-3 py-1 text-xs outline-none focus:outline-none hover:text-lightBlue-100 hover:scale-105 mr-1 mb-1 ease-linear transition-all duration-150",
            type: "button",
            children: "Edit"
          }
        ) })
      ] })) })
    ] }, i)) }),
    /* @__PURE__ */ jsx(Pagination, { links }),
    showModalEditProsesperm && /* @__PURE__ */ jsx(
      ModalEditProsespermohonan,
      {
        showModal: showModalEditProsesperm,
        setShowModal: setshowModalEditProsesperm,
        prosespermohonan,
        statusprosesperm
      }
    )
  ] });
};
export {
  CardFilterProsespermohonan as C,
  CardListProsespermohonan as a
};
