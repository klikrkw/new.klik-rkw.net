import { jsxs, jsx } from "react/jsx-runtime";
import { I as Input } from "./Input-72be4948.js";
import { L as LinkButton } from "./LinkButton-a291522b.js";
import { L as LoadingButton } from "./LoadingButton-c9189101.js";
import { usePage, router, useForm } from "@inertiajs/react";
import { M as MoneyInput } from "./MoneyInput-87a36109.js";
import { S as SelectSearch } from "./SelectSearch-22ab8168.js";
import moment from "moment";
import { P as PermohonanSelect } from "./PermohonanSelect-e6abd996.js";
import { useRef, useState, useEffect } from "react";
import { P as Pagination } from "./Pagination-30af682d.js";
import { u as useSwal } from "./useSwal-5d61a319.js";
import { S as StafLayout } from "./StafLayout-f28c615d.js";
import { C as CardPermohonanEditable } from "./CardPermohonanEditable-d1f1f0c5.js";
import { M as ModalAddPermohonan } from "./ModalAddPermohonan-72cf984e.js";
import "tailwind-merge";
import "classnames";
import "react-number-format";
import "lodash";
import "react-select";
import "@headlessui/react";
import "@heroicons/react/20/solid";
import "swr";
import "./bootstrap-b9d9b211.js";
import "axios";
import "./ListboxSelect-3ce899e5.js";
import "sweetalert2";
import "./NotificationDropdown-abde11b8.js";
import "@popperjs/core";
import "./ResponsiveNavLink-41b4fa07.js";
import "react-hot-toast";
import "./AuthContext-5300e6b5.js";
import "firebase/app";
import "firebase/auth";
import "firebase/firestore";
import "firebase/storage";
import "firebase/messaging";
import "./MenuItem-f3c50e94.js";
import "react-loader-spinner";
const CardAnggarankeluarbiayapermList = ({ kasbon }) => {
  const {
    anggarankeluarbiayaperms: { data, links, meta },
    total_biaya
  } = usePage().props;
  const handleRemoveData = (id) => {
    router.delete(
      route("admin.transaksi.anggarankeluarbiayaperms.destroy", id)
    );
  };
  return /* @__PURE__ */ jsxs("div", { className: "w-full mt-4 flex flex-col mb-2", children: [
    /* @__PURE__ */ jsx("ul", { className: "list-none container-snap max-h-56 overflow-x-hidden", children: /* @__PURE__ */ jsxs("li", { className: "flex uppercase gap-1 flex-row w-full items-center rounded-t-md text-xs border justify-start bg-lightBlue-600 border-blueGray-400 px-2 py-2  text-lightBlue-50 font-semibold", children: [
      /* @__PURE__ */ jsx("div", { className: "w-[5%]", children: "No" }),
      /* @__PURE__ */ jsx("div", { className: "w-[35%]", children: "Permohonan" }),
      /* @__PURE__ */ jsx("div", { className: "w-[35%] md:w-[20%]", children: "Nama Kegiatan" }),
      /* @__PURE__ */ jsx("div", { className: "hidden md:block w-[20%]", children: "Keterangan" }),
      /* @__PURE__ */ jsx("div", { className: "w-[15%] text-right pr-2", children: "Jumlah" }),
      /* @__PURE__ */ jsx("div", { className: "w-[5%] text-center", children: "Menu" })
    ] }) }),
    /* @__PURE__ */ jsx("ul", { className: "list-none container-snap max-h-80 overflow-x-hidden rounded-b-md shadow-md", children: data && data.map((item, index) => /* @__PURE__ */ jsx(
      "li",
      {
        className: "w-full flex flex-col overflow-hidden bg-lightBlue-300",
        children: /* @__PURE__ */ jsxs("div", { className: "flex w-full gap-1 text-xs px-2 py-0 items-center justify-start text-lightBlue-900 border-b-2 border-lightBlue-200", children: [
          /* @__PURE__ */ jsxs("div", { className: "pb-1 w-[5%]", children: [
            index + 1,
            "."
          ] }),
          /* @__PURE__ */ jsx("div", { className: "pb-1 w-[35%]", children: item.permohonan }),
          /* @__PURE__ */ jsx("div", { className: "pb-1 w-[35%] md:w-[20%]", children: item.ket_biaya }),
          /* @__PURE__ */ jsx("div", { className: "pb-1 hidden md:block md:w-[20%]", children: item.ket_biaya }),
          /* @__PURE__ */ jsx("div", { className: "pb-1 w-[15%] text-right pr-2", children: item.jumlah_biaya }),
          /* @__PURE__ */ jsx("div", { className: "pb-1 w-[5%] flex justify-center items-center gap-2", children: kasbon.status_kasbon === "wait_approval" ? /* @__PURE__ */ jsx(
            "button",
            {
              onClick: (e) => useSwal.confirm({
                title: "Hapus Data",
                text: "apakah akan menghapus?"
              }).then((result) => {
                if (result.isConfirmed) {
                  handleRemoveData(
                    item.id
                  );
                }
              }),
              className: "text-lightBlue-500 background-transparent text-lg font-bold uppercase px-0 py-0 outline-none focus:outline-none mr-1 mb-1 ease-linear transition-all duration-150",
              type: "button",
              children: /* @__PURE__ */ jsx(
                "i",
                {
                  className: "fa fa-trash",
                  "aria-hidden": "true"
                }
              )
            }
          ) : null })
        ] })
      },
      item.id
    )) }),
    /* @__PURE__ */ jsx("ul", { className: "list-none container-snap max-h-80 overflow-x-hidden rounded-b-md shadow-md", children: /* @__PURE__ */ jsx("li", { className: "w-full flex flex-col overflow-hidden bg-lightBlue-600 px-2 py-1  font-semibold text-lightBlue-50", children: /* @__PURE__ */ jsxs("div", { className: "flex w-full gap-1 text-xs px-2 py-1 items-center justify-start border-b-2 border-lightBlue-500", children: [
      /* @__PURE__ */ jsx("div", { className: "w-[60%]" }),
      /* @__PURE__ */ jsx("div", { className: "hidden md:block md:w-[20%] text-right", children: "Total Biaya" }),
      /* @__PURE__ */ jsx("div", { className: "w-[15%] text-right", children: total_biaya }),
      /* @__PURE__ */ jsx("div", { className: "w-[5%] flex justify-start items-center gap-2" })
    ] }) }) }),
    /* @__PURE__ */ jsx(Pagination, { links: meta.links, labelLinks: links })
  ] });
};
const Create = ({ kasbon, itemkegiatanOpts, is_admin, base_route }) => {
  const { data, setData, errors, processing, post, reset } = useForm({
    itemkegiatan: void 0,
    itemkegiatan_id: "",
    kasbon_id: kasbon.id,
    jumlah_biaya: "0",
    ket_biaya: "",
    permohonan: void 0,
    transpermohonan_id: "",
    _method: "POST"
  });
  const firstInput = useRef();
  useState(false);
  const [showModalAddPermohonan, setShowModalAddPermohonan] = useState(false);
  function handleSubmit(e) {
    e.preventDefault();
    post(route(base_route + "transaksi.anggarankeluarbiayaperms.store"), {
      onSuccess: () => {
        reset();
        firstInput.current.value = "";
        firstInput.current.focus();
      }
    });
  }
  useEffect(() => {
    if (firstInput.current) {
      firstInput.current.focus();
    }
  }, []);
  const setPermohonan = (perm) => {
    firstInput.current.value = perm == null ? void 0 : perm.nama_penerima;
    setData({
      ...data,
      permohonan: perm,
      transpermohonan_id: (perm == null ? void 0 : perm.transpermohonan) ? perm.transpermohonan.id : ""
    });
  };
  return /* @__PURE__ */ jsxs(StafLayout, { children: [
    /* @__PURE__ */ jsx("div", { className: "flex content-center items-center justify-center relative -top-2", children: /* @__PURE__ */ jsx("div", { className: "w-full lg:w-11/12 px-4 ", children: /* @__PURE__ */ jsxs("div", { className: "relative flex flex-col min-w-0 break-words w-full mb-2 shadow-lg shadow-slate-400 rounded-lg bg-blueGray-100 border-0", children: [
      /* @__PURE__ */ jsx("div", { className: "rounded-t mb-1 px-4 py-4 ", children: /* @__PURE__ */ jsxs("div", { className: "w-full grid grid-cols-1 md:grid-cols-2 bg-lightBlue-800 text-lightBlue-100 px-4 py-2 shadow-md rounded-lg", children: [
        /* @__PURE__ */ jsx("div", { className: "text-left", children: /* @__PURE__ */ jsx("h6", { className: "font-semibold", children: "ANGGARAN PENGELUARAN BIAYA" }) }),
        /* @__PURE__ */ jsx("div", { className: "text-left md:text-right", children: moment(
          /* @__PURE__ */ new Date(),
          "DD MMM YYYY hh:mm"
        ).format("DD MMM YYYY hh:mm") })
      ] }) }),
      /* @__PURE__ */ jsxs("div", { className: "flex-auto px-4 lg:px-6 py-4 pt-0", children: [
        /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 md:grid-cols-3 gap-2", children: [
          /* @__PURE__ */ jsx(
            MoneyInput,
            {
              label: "Kasbon",
              value: kasbon.jumlah_kasbon,
              disabled: true
            }
          ),
          /* @__PURE__ */ jsx(
            Input,
            {
              label: "Instansi",
              value: kasbon.instansi.nama_instansi,
              disabled: true,
              name: "instansi"
            }
          ),
          /* @__PURE__ */ jsx(
            Input,
            {
              label: "Keperluan",
              value: kasbon.keperluan,
              disabled: true,
              name: "instansi"
            }
          )
        ] }),
        kasbon.status_kasbon === "wait_approval" ? /* @__PURE__ */ jsx("form", { onSubmit: handleSubmit, children: /* @__PURE__ */ jsxs("div", { className: "w-full grid grid-cols-2 gap-2", children: [
          /* @__PURE__ */ jsxs("div", { className: "w-full grid grid-cols-1", children: [
            /* @__PURE__ */ jsxs("div", { className: "flex flex-row justify-between items-center", children: [
              /* @__PURE__ */ jsx(
                PermohonanSelect,
                {
                  inputRef: firstInput,
                  value: data.permohonan,
                  className: "mb-1 w-full mr-2",
                  errors: errors.transpermohonan_id,
                  onValueChange: (e) => {
                    setData((v) => ({
                      ...v,
                      permohonan: e,
                      transpermohonan_id: e.transpermohonan.id
                    }));
                  }
                }
              ),
              /* @__PURE__ */ jsx(
                "a",
                {
                  tabIndex: -1,
                  href: "#",
                  className: "w-8 h-8 px-2 py-1 rounded-full bg-blue-600/20 shadow-xl mb-1",
                  onClick: (e) => {
                    e.preventDefault();
                    setShowModalAddPermohonan(
                      true
                    );
                  },
                  children: /* @__PURE__ */ jsx("i", { className: "fas fa-add text-md text-center text-gray-700" })
                }
              )
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 gap-2", children: [
              /* @__PURE__ */ jsx(
                SelectSearch,
                {
                  placeholder: "Pilih Kegiatan",
                  name: "itemkegiatan_id",
                  value: data.itemkegiatan,
                  options: itemkegiatanOpts,
                  onChange: (e) => setData({
                    ...data,
                    itemkegiatan: e ? e : {},
                    itemkegiatan_id: e ? e.value : ""
                  }),
                  errors: errors.itemkegiatan_id
                }
              ),
              /* @__PURE__ */ jsx(
                Input,
                {
                  name: "ket_biaya",
                  placeholder: "Keterangan",
                  errors: errors.ket_biaya,
                  value: data.ket_biaya,
                  onChange: (e) => setData(
                    "ket_biaya",
                    e.target.value
                  )
                }
              )
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "flex justify-between gap-2 items-start", children: [
              /* @__PURE__ */ jsx(
                MoneyInput,
                {
                  name: "jumlah_biaya",
                  errors: errors.jumlah_biaya,
                  autoComplete: "off",
                  value: data.jumlah_biaya,
                  placeholder: "Jumlah",
                  onValueChange: (e) => setData((prev) => ({
                    ...prev,
                    jumlah_biaya: e.value
                  }))
                }
              ),
              /* @__PURE__ */ jsx(
                LoadingButton,
                {
                  theme: "black",
                  loading: processing,
                  type: "submit",
                  className: "pb-3 text-sm",
                  children: /* @__PURE__ */ jsx("span", { children: "Simpan" })
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsx("div", { className: "w-full flex items-start", children: /* @__PURE__ */ jsx(
            CardPermohonanEditable,
            {
              permohonan: data.permohonan,
              base_route
            }
          ) })
        ] }) }) : null,
        /* @__PURE__ */ jsx("div", { className: "w-full flex items-start", children: /* @__PURE__ */ jsx(
          CardAnggarankeluarbiayapermList,
          {
            kasbon
          }
        ) }),
        /* @__PURE__ */ jsx("div", { className: "flex items-center justify-between", children: /* @__PURE__ */ jsx(
          LinkButton,
          {
            theme: "blueGrey",
            href: route(
              base_route + "transaksi.kasbons.index"
            ),
            children: /* @__PURE__ */ jsx("span", { children: "Kembali" })
          }
        ) })
      ] })
    ] }) }) }),
    /* @__PURE__ */ jsx(
      ModalAddPermohonan,
      {
        showModal: showModalAddPermohonan,
        setShowModal: setShowModalAddPermohonan,
        setPermohonan,
        src: route(base_route + "permohonans.modal.create")
      }
    )
  ] });
};
export {
  Create as default
};
