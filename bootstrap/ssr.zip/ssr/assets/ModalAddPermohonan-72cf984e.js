import { jsx, jsxs } from "react/jsx-runtime";
import { Fragment, useState, useEffect, useRef } from "react";
import { a as apputils } from "./bootstrap-b9d9b211.js";
import { ThreeDots } from "react-loader-spinner";
import { usePage } from "@inertiajs/react";
import { Transition, Dialog } from "@headlessui/react";
function ModalAutosize({
  children,
  show = false,
  maxWidth = "2xl",
  closeable = true,
  title,
  onClose = () => {
  }
}) {
  const close = () => {
    if (closeable) {
      onClose();
    }
  };
  const maxWidthClass = {
    sm: "sm:max-w-sm",
    md: "sm:max-w-md",
    lg: "sm:max-w-lg",
    xl: "sm:max-w-xl",
    "2xl": "sm:max-w-2xl"
  }[maxWidth];
  return /* @__PURE__ */ jsx(Transition, { show, as: Fragment, leave: "duration-200", children: /* @__PURE__ */ jsxs(
    Dialog,
    {
      as: "div",
      id: "modal",
      className: "fixed inset-0 flex overflow-y-auto px-4 py-4 sm:px-0 items-center z-[55] transform transition-all",
      onClose: close,
      children: [
        /* @__PURE__ */ jsx(
          Transition.Child,
          {
            as: Fragment,
            enter: "ease-out duration-300",
            enterFrom: "opacity-0",
            enterTo: "opacity-100",
            leave: "ease-in duration-200",
            leaveFrom: "opacity-100",
            leaveTo: "opacity-0",
            children: /* @__PURE__ */ jsx("div", { className: "absolute inset-0 bg-gray-500/75" })
          }
        ),
        /* @__PURE__ */ jsx(
          Transition.Child,
          {
            as: Fragment,
            enter: "ease-out duration-300",
            enterFrom: "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95",
            enterTo: "opacity-100 translate-y-0 sm:scale-100",
            leave: "ease-in duration-200",
            leaveFrom: "opacity-100 translate-y-0 sm:scale-100",
            leaveTo: "opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95",
            children: /* @__PURE__ */ jsxs(
              Dialog.Panel,
              {
                className: `h-full py-4 bg-white rounded-lg shadow-xl transform transition-all sm:w-full sm:mx-auto overflow-visible ${maxWidthClass}`,
                children: [
                  title ? /* @__PURE__ */ jsx(
                    Dialog.Title,
                    {
                      as: "h3",
                      className: "text-lg font-medium leading-6 text-gray-900",
                      children: title
                    }
                  ) : null,
                  children
                ]
              }
            )
          }
        )
      ]
    }
  ) });
}
const ModalAddPermohonan = ({
  showModal,
  setShowModal,
  src,
  setPermohonan
}) => {
  usePage().props;
  useState();
  const [isLoading, setisLoading] = useState(false);
  useEffect(() => {
    setisLoading(true);
    const getLaporan = async () => {
      const response = await apputils.backend.get(src);
      response.data;
      setisLoading(false);
    };
    if (showModal) {
      getLaporan();
    }
  }, [showModal]);
  const iframe = useRef(null);
  window.parentCallback = (perm) => {
    setPermohonan(perm);
    setShowModal(false);
  };
  const [loadingIframe, setLoadingIframe] = useState(true);
  return /* @__PURE__ */ jsxs(
    ModalAutosize,
    {
      show: showModal,
      maxWidth: "2xl",
      closeable: false,
      onClose: () => setShowModal(false),
      children: [
        /* @__PURE__ */ jsx("div", { className: "p-2 bg-white rounded-md text-xs z-40 h-full", children: /* @__PURE__ */ jsxs("div", { className: "w-full h-full relative flex flex-col m-auto justify-center items-center rounded-md mt-4", children: [
          loadingIframe || isLoading ? /* @__PURE__ */ jsx("div", { className: "absolute top-7", children: /* @__PURE__ */ jsx(
            ThreeDots,
            {
              visible: true,
              height: "100",
              width: "100",
              color: "#4fa94d",
              radius: "9",
              ariaLabel: "three-dots-loading",
              wrapperStyle: {},
              wrapperClass: ""
            }
          ) }) : null,
          /* @__PURE__ */ jsx(
            "iframe",
            {
              src,
              title: "Add Permohonan",
              ref: iframe,
              className: "w-full h-full rounded-md",
              onLoad: () => setLoadingIframe(false),
              loading: "lazy"
            }
          )
        ] }) }),
        /* @__PURE__ */ jsx("div", { className: "w-full absolute right-1 top-1 flex justify-end items-center px-1 ", children: /* @__PURE__ */ jsx(
          "button",
          {
            className: "text-blueGray-700 background-transparent font-bold uppercase px-0 py-0 text-xl outline-none focus:outline-none mr-1 mb-1 ease-linear transition-all duration-150",
            type: "button",
            onClick: (e) => setShowModal(false),
            children: /* @__PURE__ */ jsx("i", { className: "fa fa-times-circle", "aria-hidden": "true" })
          }
        ) })
      ]
    }
  );
};
export {
  ModalAddPermohonan as M
};
