import { jsxs, jsx } from "react/jsx-runtime";
import { I as Input } from "./Input-72be4948.js";
import { L as LinkButton } from "./LinkButton-a291522b.js";
import { L as LoadingButton } from "./LoadingButton-c9189101.js";
import { A as AdminLayout } from "./AdminLayout-4bc80775.js";
import { useForm, router } from "@inertiajs/react";
import { M as MoneyInput } from "./MoneyInput-87a36109.js";
import moment from "moment";
import { useRef, useState } from "react";
import { C as CardPermohonanEditable } from "./CardPermohonanEditable-d1f1f0c5.js";
import { I as InputLabel } from "./InputLabel-747c5b8a.js";
import { S as SelectSearch } from "./SelectSearch-22ab8168.js";
import { C as CardDrincianbiayapermList } from "./CardDrincianbiayapermList-58b31a1a.js";
import { M as ModalCetakLaporan } from "./ModalCetakLaporan-767963a0.js";
import { B as Button } from "./Button-e2b11bd9.js";
import { u as useSwal } from "./useSwal-5d61a319.js";
import { M as Modal } from "./Modal-29294895.js";
import "tailwind-merge";
import "classnames";
import "./NotificationDropdown-abde11b8.js";
import "@popperjs/core";
import "./ResponsiveNavLink-41b4fa07.js";
import "react-hot-toast";
import "./AuthContext-5300e6b5.js";
import "firebase/app";
import "firebase/auth";
import "firebase/firestore";
import "firebase/storage";
import "./bootstrap-b9d9b211.js";
import "axios";
import "firebase/messaging";
import "./MenuItem-f3c50e94.js";
import "react-number-format";
import "./ModalAddPermohonan-72cf984e.js";
import "react-loader-spinner";
import "@headlessui/react";
import "lodash";
import "react-select";
import "./Pagination-30af682d.js";
import "./index-d9460823.js";
import "./Modal-d06b3568.js";
import "react-dom";
import "@emotion/react";
import "@emotion/cache";
import "sweetalert2";
const Edit = ({
  itemrincianbiayapermOpts,
  base_route,
  isAdmin,
  rincianbiayaperm,
  permohonan,
  biayapermOpts
}) => {
  const { data, setData, errors, post, processing, reset } = useForm({
    itemrincianbiayapermOpt: void 0,
    itemrincianbiayaperm_id: "",
    rincianbiayaperm_id: rincianbiayaperm.id,
    jumlah_biaya: "0",
    ket_biaya: "",
    _method: "PUT"
  });
  const firstInput = useRef();
  function handleSubmit(e) {
    e.preventDefault();
    post(
      route(
        base_route + "transaksi.rincianbiayaperms.update",
        rincianbiayaperm.id
      ),
      {
        onSuccess: (d) => {
          reset("jumlah_biaya", "ket_biaya");
          firstInput.current.focus();
        }
      }
    );
  }
  const [showModalLaporan, setShowModalLaporan] = useState(false);
  const [showStatusDialog, setShowStatusDialog] = useState(false);
  const [biayaperm, setBiayaperm] = useState();
  function prosesLaporan(e) {
    e.preventDefault();
    setShowModalLaporan(true);
  }
  function handleUpdateStatus(e) {
    e.preventDefault();
    const data2 = {
      biayaperms: biayaperm ? [biayaperm.value] : []
    };
    router.put(
      route(
        base_route + "transaksi.rincianbiayaperms.biayaperms.update",
        rincianbiayaperm.id
      ),
      data2,
      {
        onSuccess: (e2) => {
          setShowStatusDialog(false);
          useSwal.info({
            title: "Informasi",
            text: "Biaya berhasil diupdate"
          });
        }
      }
    );
  }
  return /* @__PURE__ */ jsxs(AdminLayout, { children: [
    /* @__PURE__ */ jsx("div", { className: "flex content-center items-center justify-center relative -top-2", children: /* @__PURE__ */ jsx("div", { className: "w-full lg:w-11/12 px-4", children: /* @__PURE__ */ jsxs("div", { className: "relative flex flex-col min-w-0 break-words w-full mb-2 shadow-lg shadow-slate-400 rounded-lg bg-blueGray-100 border-0", children: [
      /* @__PURE__ */ jsx("div", { className: "rounded-t mb-1 px-4 py-4 ", children: /* @__PURE__ */ jsxs("div", { className: "w-full grid grid-cols-1 md:grid-cols-2 bg-lightBlue-800 text-lightBlue-100 px-2 py-2 shadow-md rounded-lg", children: [
        /* @__PURE__ */ jsx("div", { className: "text-left", children: /* @__PURE__ */ jsx("h6", { className: "font-semibold", children: "RINCIAN BIAYA PERMOHONAN" }) }),
        /* @__PURE__ */ jsx("div", { className: "text-left md:text-right", children: moment(
          new Date(rincianbiayaperm.created_at)
        ).format("DD MMM YYYY HH:mm") })
      ] }) }),
      /* @__PURE__ */ jsxs("div", { className: "flex-auto px-4 lg:px-4 py-4 pt-0", children: [
        /* @__PURE__ */ jsxs("div", { className: "w-full grid grid-cols-1 md:grid-cols-2 gap-2", children: [
          /* @__PURE__ */ jsxs("div", { className: "w-full flex flex-col gap-2 mt-2", children: [
            /* @__PURE__ */ jsxs("div", { className: "flex flex-row items-start w-full gap-2", children: [
              /* @__PURE__ */ jsxs("div", { className: "flex flex-col md:flex-row gap-2 justify-start items-center w-full bg-gray-300 py-1 px-2 rounded-md shadow-md", children: [
                /* @__PURE__ */ jsx("label", { children: "Status : " }),
                /* @__PURE__ */ jsx(
                  InputLabel,
                  {
                    className: "",
                    value: rincianbiayaperm.status_rincianbiayaperm
                  }
                )
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "flex flex-col md:flex-row gap-2 justify-start items-center w-full bg-gray-300 py-1 px-2 rounded-md shadow-md", children: [
                /* @__PURE__ */ jsx("label", { children: "User : " }),
                /* @__PURE__ */ jsx(
                  InputLabel,
                  {
                    value: rincianbiayaperm.user.name
                  }
                )
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "flex flex-row items-start w-full gap-2", children: [
              /* @__PURE__ */ jsxs("div", { className: "flex flex-col md:flex-row gap-2 justify-start items-center w-full bg-gray-300 py-1 px-2 rounded-md shadow-md", children: [
                /* @__PURE__ */ jsx("label", { children: "Keterangan : " }),
                /* @__PURE__ */ jsx(
                  InputLabel,
                  {
                    value: rincianbiayaperm.ket_rincianbiayaperm
                  }
                )
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "flex flex-col md:flex-row gap-2 justify-start items-center w-full bg-gray-300 py-1 px-2 rounded-md shadow-md", children: [
                /* @__PURE__ */ jsx("label", { children: "Metode : " }),
                /* @__PURE__ */ jsx(
                  InputLabel,
                  {
                    value: rincianbiayaperm.metodebayar.nama_metodebayar
                  }
                )
              ] })
            ] }),
            rincianbiayaperm.status_rincianbiayaperm === "wait_approval" ? /* @__PURE__ */ jsxs("form", { onSubmit: handleSubmit, children: [
              /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-2", children: [
                /* @__PURE__ */ jsxs("div", { className: "w-full flex flex-col mb-2", children: [
                  /* @__PURE__ */ jsx(
                    SelectSearch,
                    {
                      xref: firstInput,
                      focused: true,
                      placeholder: "Pilih Kegiatan",
                      className: "mb-0",
                      name: "itemkegiatan_id",
                      value: data.itemrincianbiayapermOpt,
                      options: itemrincianbiayapermOpts,
                      onChange: (e) => setData({
                        ...data,
                        itemrincianbiayapermOpt: e ? e : {},
                        itemrincianbiayaperm_id: e ? e.value : ""
                      }),
                      errors: errors.itemrincianbiayaperm_id
                    }
                  ),
                  data.itemrincianbiayapermOpt ? /* @__PURE__ */ jsx("label", { className: "ml-2 text-gray-500 text-sm uppercase", children: data.itemrincianbiayapermOpt.jenis_itemrincianbiayaperm }) : null
                ] }),
                /* @__PURE__ */ jsx(
                  Input,
                  {
                    disabled: rincianbiayaperm.status_rincianbiayaperm != "wait_approval",
                    name: "ket_biaya",
                    placeholder: "Keterangan",
                    errors: errors.ket_biaya,
                    value: data.ket_biaya,
                    onChange: (e) => setData(
                      "ket_biaya",
                      e.target.value
                    )
                  }
                )
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "flex flex-row items-start justify-between gap-2", children: [
                /* @__PURE__ */ jsx(
                  MoneyInput,
                  {
                    name: "jumlah_biaya",
                    disabled: rincianbiayaperm.status_rincianbiayaperm != "wait_approval",
                    errors: errors.jumlah_biaya,
                    autoComplete: "off",
                    value: data.jumlah_biaya,
                    placeholder: "Jumlah",
                    onValueChange: (e) => setData((prev) => ({
                      ...prev,
                      jumlah_biaya: e.value
                    }))
                  }
                ),
                /* @__PURE__ */ jsxs("div", { className: "w-full flex justify-around items-center ", children: [
                  /* @__PURE__ */ jsx(
                    LoadingButton,
                    {
                      theme: "red",
                      loading: processing,
                      type: "submit",
                      className: "text-sm py-2",
                      children: /* @__PURE__ */ jsx("span", { children: "Simpan" })
                    }
                  ),
                  rincianbiayaperm.total_pemasukan > 0 && /* @__PURE__ */ jsx(
                    LinkButton,
                    {
                      tabIndex: -1,
                      href: "#",
                      theme: "blue",
                      className: "py-2 text-xs",
                      onClick: (e) => {
                        e.preventDefault();
                        setShowStatusDialog(
                          true
                        );
                      },
                      children: /* @__PURE__ */ jsx("span", { children: "Set Biaya" })
                    }
                  )
                ] })
              ] })
            ] }) : null
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "w-full flex flex-col items-start mt-2", children: [
            /* @__PURE__ */ jsxs("div", { className: "flex flex-row gap-2 justify-start items-center w-full bg-gray-300 py-1 px-2 rounded-md shadow-md", children: [
              /* @__PURE__ */ jsx("label", { children: "Transaksi : " }),
              /* @__PURE__ */ jsx(
                InputLabel,
                {
                  value: rincianbiayaperm.transpermohonan.jenispermohonan.nama_jenispermohonan
                }
              )
            ] }),
            /* @__PURE__ */ jsx(
              CardPermohonanEditable,
              {
                permohonan,
                base_route
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsx(
            LinkButton,
            {
              theme: "blueGrey",
              tabIndex: -1,
              href: route(
                base_route + "transaksi.rincianbiayaperms.index"
              ),
              children: /* @__PURE__ */ jsx("span", { children: "Kembali" })
            }
          ),
          /* @__PURE__ */ jsx(
            Button,
            {
              disabled: rincianbiayaperm.total_pemasukan == 0,
              theme: "blue",
              onClick: (e) => prosesLaporan(e),
              children: /* @__PURE__ */ jsx("span", { children: "Cetak" })
            }
          )
        ] }),
        /* @__PURE__ */ jsx(
          CardDrincianbiayapermList,
          {
            rincianbiayaperm
          }
        )
      ] })
    ] }) }) }),
    /* @__PURE__ */ jsx(
      ModalCetakLaporan,
      {
        showModal: showModalLaporan,
        setShowModal: setShowModalLaporan,
        src: route("rincianbiayaperms.lap.staf", rincianbiayaperm.id)
      }
    ),
    showStatusDialog ? /* @__PURE__ */ jsx(
      Modal,
      {
        closeable: true,
        show: showStatusDialog,
        maxWidth: "md",
        onClose: () => setShowStatusDialog(false),
        children: /* @__PURE__ */ jsxs("div", { className: "w-full p-4 flex flex-col gap-2", children: [
          /* @__PURE__ */ jsx("h1", { children: "Update Biaya Permohonan" }),
          /* @__PURE__ */ jsx(
            SelectSearch,
            {
              placeholder: "Biaya Permohonan",
              name: "biayaperm",
              value: biayaperm,
              options: biayapermOpts,
              onChange: (e) => setBiayaperm(e)
            }
          ),
          /* @__PURE__ */ jsxs("div", { className: "flex justify-end gap-2", children: [
            /* @__PURE__ */ jsx(
              Button,
              {
                disabled: !biayaperm,
                theme: "blue",
                onClick: (e) => handleUpdateStatus(e),
                children: /* @__PURE__ */ jsx("span", { children: "Update" })
              }
            ),
            /* @__PURE__ */ jsx(
              Button,
              {
                theme: "blueGrey",
                onClick: (e) => setShowStatusDialog(false),
                children: /* @__PURE__ */ jsx("span", { children: "Batal" })
              }
            )
          ] })
        ] })
      }
    ) : null
  ] });
};
export {
  Edit as default
};
