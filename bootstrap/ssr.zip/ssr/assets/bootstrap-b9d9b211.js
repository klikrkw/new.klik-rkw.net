import axios from "axios";
window.axios = axios;
window.axios.defaults.headers.common["X-Requested-With"] = "XMLHttpRequest";
var lvToken = document.querySelector('meta[name="csrf-token"]');
lvToken ? lvToken.getAttribute("content") : "";
window.backend = axios.create({
  timeout: 4e3
  // headers: { "X-CSRF-TOKEN": lvToken },
});
const xmeta = document.querySelector('meta[name="refresh-token"]');
const refreshToken = xmeta ? xmeta.getAttribute("content") : "";
const apputils = { backend: window.backend, refreshToken };
export {
  apputils as a
};
