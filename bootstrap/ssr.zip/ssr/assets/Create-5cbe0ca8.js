import { jsxs, Fragment, jsx } from "react/jsx-runtime";
import { M as ModalAddPermohonan } from "./ModalAddPermohonan-72cf984e.js";
import { Link, useForm, router } from "@inertiajs/react";
import { useState, useEffect, Fragment as Fragment$1, useRef } from "react";
import { L as LoadingButton } from "./LoadingButton-c9189101.js";
import { Combobox, Transition } from "@headlessui/react";
import { XCircleIcon, ChevronUpDownIcon } from "@heroicons/react/20/solid";
import { twMerge } from "tailwind-merge";
import useSWR from "swr";
import { a as apputils } from "./bootstrap-b9d9b211.js";
import { L as ListboxSelect } from "./ListboxSelect-3ce899e5.js";
import { T as TranspermohonanSelect } from "./TranspermohonanSelect-e6be2ec6.js";
import { S as StafLayout } from "./StafLayout-f28c615d.js";
import { u as useSwal } from "./useSwal-5d61a319.js";
import { pickBy } from "lodash";
import { usePrevious } from "react-use";
import "react-loader-spinner";
import "classnames";
import "axios";
import "./Modal-d06b3568.js";
import "./LinkButton-a291522b.js";
import "@zxing/browser";
import "./useScreenSize-4351026c.js";
import "./NotificationDropdown-abde11b8.js";
import "@popperjs/core";
import "./ResponsiveNavLink-41b4fa07.js";
import "react-hot-toast";
import "./AuthContext-5300e6b5.js";
import "firebase/app";
import "firebase/auth";
import "firebase/firestore";
import "firebase/storage";
import "firebase/messaging";
import "./MenuItem-f3c50e94.js";
import "sweetalert2";
function CardTranspermohonanEditable({
  permohonan,
  base_route,
  setPermohonan,
  isEditable = true
}) {
  const [showModalEditPermohonan, setShowModalEditPermohonan] = useState(false);
  const [permohonanId, setPermohonanId] = useState("");
  const [newpermohonan, setNewpermohonan] = useState();
  const setCPermohonan = (perm) => {
    setPermohonan ? setPermohonan(perm == null ? void 0 : perm.transpermohonan) : null;
    setNewpermohonan(perm == null ? void 0 : perm.transpermohonan);
  };
  useEffect(() => {
    setNewpermohonan(permohonan);
  }, [permohonan]);
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    newpermohonan && newpermohonan.permohonan ? /* @__PURE__ */ jsx("div", { className: "relative flex flex-col min-w-0 break-words w-full mb-2 shadow-lg rounded-lg bg-blueGray-50 border-0 text-xs mt-2", children: /* @__PURE__ */ jsx("div", { className: "flex-auto px-2 lg:px-4 py-4 pt-0", children: /* @__PURE__ */ jsxs("div", { className: "relative w-full mt-2 grid grid-cols-2 md:grid-cols-4", children: [
      /* @__PURE__ */ jsx("span", { className: "font-bold", children: "No Daftar" }),
      /* @__PURE__ */ jsxs("span", { children: [
        " ",
        newpermohonan.no_daftar
      ] }),
      /* @__PURE__ */ jsx("span", { className: "font-bold", children: "Tgl Daftar" }),
      /* @__PURE__ */ jsxs("span", { children: [
        " ",
        newpermohonan.tgl_daftar
      ] }),
      /* @__PURE__ */ jsx("span", { className: "font-bold", children: "Nama Pelepas" }),
      /* @__PURE__ */ jsxs("span", { children: [
        " ",
        newpermohonan.permohonan.nama_pelepas
      ] }),
      /* @__PURE__ */ jsx("span", { className: "font-bold", children: "Nama Penerima" }),
      /* @__PURE__ */ jsxs("span", { children: [
        " ",
        newpermohonan.permohonan.nama_penerima
      ] }),
      /* @__PURE__ */ jsx("span", { className: "font-bold", children: "Alas Hak" }),
      /* @__PURE__ */ jsxs("span", { children: [
        " ",
        newpermohonan.permohonan.nomor_hak
      ] }),
      /* @__PURE__ */ jsx("span", { className: "font-bold", children: "Atas Nama" }),
      /* @__PURE__ */ jsxs("span", { children: [
        " ",
        newpermohonan.permohonan.atas_nama
      ] }),
      /* @__PURE__ */ jsx("span", { className: "font-bold", children: "Luas Tanah" }),
      /* @__PURE__ */ jsxs("span", { children: [
        newpermohonan.permohonan.luas_tanah,
        " M2"
      ] }),
      /* @__PURE__ */ jsx("span", { className: "font-bold", children: "Letak Obyek" }),
      /* @__PURE__ */ jsxs("span", { children: [
        " ",
        newpermohonan.permohonan.letak_obyek
      ] }),
      /* @__PURE__ */ jsx("span", { className: "font-bold", children: "Jenis Permohonan" }),
      /* @__PURE__ */ jsx("span", { children: newpermohonan.jenispermohonan.nama_jenispermohonan }),
      /* @__PURE__ */ jsx("span", { className: "font-bold", children: "Users" }),
      /* @__PURE__ */ jsx("span", { children: newpermohonan.permohonan.users && newpermohonan.permohonan.users.map(
        (user, i) => /* @__PURE__ */ jsxs("span", { children: [
          i > 0 ? ", " : "",
          user.name
        ] }, i)
      ) }),
      isEditable ? /* @__PURE__ */ jsx(
        Link,
        {
          href: "#",
          tabIndex: -1,
          className: "z-30 w-8 h-8 px-2 py-2 text-center rounded-full bg-blue-600/20 shadow-xl mb-1 absolute -bottom-2 -right-2 ",
          onClick: (e) => {
            e.preventDefault();
            setPermohonanId(
              newpermohonan.permohonan.id
            );
            setShowModalEditPermohonan(true);
          },
          children: /* @__PURE__ */ jsx("i", { className: "fas fa-edit text-md text-center text-gray-700" })
        }
      ) : null
    ] }) }) }) : null,
    /* @__PURE__ */ jsx(
      ModalAddPermohonan,
      {
        showModal: showModalEditPermohonan,
        setShowModal: setShowModalEditPermohonan,
        setPermohonan: setCPermohonan,
        src: route(base_route + "permohonans.modal.edit", permohonanId)
      }
    )
  ] });
}
function TempatarsipSelect({
  className,
  onValueChange,
  value,
  errors,
  inputRef,
  isStaf
}) {
  const [selectedPerson, setSelectedPerson] = useState(value ? value : void 0);
  const listOptions = [
    { label: "ALL", value: "" },
    { label: "NAMA TEMPAT", value: "nama_tempatarsip" },
    { label: "NAMA RUANG", value: "nama_ruang" },
    { label: "JENIS TEMPAT", value: "nama_jenistempatarsip" }
  ];
  const [searchKey, setSearchKey] = useState("");
  function LoadingSpinner() {
    return /* @__PURE__ */ jsxs(
      "svg",
      {
        className: "h-5 w-5 animate-spin text-gray-500",
        xmlns: "http://www.w3.org/2000/svg",
        fill: "none",
        viewBox: "0 0 24 24",
        children: [
          /* @__PURE__ */ jsx(
            "circle",
            {
              className: "opacity-25",
              cx: "12",
              cy: "12",
              r: "10",
              stroke: "currentColor",
              strokeWidth: "4"
            }
          ),
          /* @__PURE__ */ jsx(
            "path",
            {
              className: "opacity-75",
              fill: "currentColor",
              d: "M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
            }
          )
        ]
      }
    );
  }
  async function fetcher(url, query2) {
    if (searchKey) {
      const result = await apputils.backend.get(
        // `${url}?search=${query}&search_key=${searchKey}`
        `${url}?search=${query2}&search_key=${searchKey}&is_staf=${isStaf}`
      );
      return result.data;
    } else {
      const result = await apputils.backend.get(
        // `${url}?search=${query}`
        `${url}?search=${query2}&is_staf=${isStaf}`
      );
      return result.data;
    }
  }
  const [query, setQuery] = useState("");
  const { data: filteredOption, error } = useSWR(
    ["/admin/tempatarsips/api/list/", query],
    ([url, query2]) => fetcher(url, query2)
  );
  const isLoading = !error && !filteredOption;
  const onChange = (e) => {
    setSelectedPerson((prev) => prev ? e : void 0);
    onValueChange(e, listOptions[0]);
  };
  const comparePeople = (a, b) => (a == null ? void 0 : a.nama_tempatarsip.toLowerCase()) === (b == null ? void 0 : b.nama_tempatarsip.toLowerCase());
  const clearValue = (e) => {
    e.preventDefault();
    if (inputRef && inputRef.current) {
      inputRef.current.value = "";
      onValueChange(null, listOptions[0]);
    }
  };
  return /* @__PURE__ */ jsx(Fragment, { children: /* @__PURE__ */ jsx(
    Combobox,
    {
      value: selectedPerson,
      by: comparePeople,
      onChange,
      children: /* @__PURE__ */ jsxs("div", { className: twMerge(`relative z-20`, className), children: [
        /* @__PURE__ */ jsxs(
          "div",
          {
            className: twMerge(
              "relative overflow-visible flex w-full cursor-default bg-white text-left rounded-lg shadow-md focus:outline-none focus-visible:ring-2 focus-visible:ring-white/75 focus-visible:ring-offset-2 focus-visible:ring-offset-teal-300 sm:text-sm",
              className
            ),
            children: [
              /* @__PURE__ */ jsx(
                ListboxSelect,
                {
                  className: "w-2/5 text-gray-800",
                  listOptions,
                  onListChange: (e) => setSearchKey(e.value)
                }
              ),
              /* @__PURE__ */ jsx(
                Combobox.Input,
                {
                  ref: inputRef,
                  className: "w-full border-none py-2 pl-3 pr-8 text-sm leading-5 text-gray-900 focus:ring-0 rounded-r-lg",
                  displayValue: (tempatarsip) => (tempatarsip == null ? void 0 : tempatarsip.nama_tempatarsip) ?? "",
                  onChange: (event) => setQuery(event.target.value),
                  autoComplete: "off",
                  placeholder: "Pilih Tempat Arsip"
                }
              ),
              selectedPerson && /* @__PURE__ */ jsx(
                "a",
                {
                  tabIndex: -1,
                  href: "#",
                  className: "absolute inset-y-0 right-0 flex items-center pr-8",
                  onClick: clearValue,
                  children: /* @__PURE__ */ jsx(
                    XCircleIcon,
                    {
                      className: "h-5 w-5 text-gray-400",
                      "aria-hidden": "true"
                    }
                  )
                }
              ),
              /* @__PURE__ */ jsxs(Combobox.Button, { className: "absolute inset-y-0 right-0 flex items-center pr-2", children: [
                isLoading && /* @__PURE__ */ jsx(LoadingSpinner, {}),
                /* @__PURE__ */ jsx(
                  ChevronUpDownIcon,
                  {
                    className: "h-5 w-5 text-gray-400",
                    "aria-hidden": "true"
                  }
                )
              ] })
            ]
          }
        ),
        /* @__PURE__ */ jsx(
          Transition,
          {
            as: Fragment$1,
            leave: "transition ease-in duration-100",
            leaveFrom: "opacity-100",
            leaveTo: "opacity-0",
            afterLeave: () => setQuery(""),
            children: /* @__PURE__ */ jsxs(Combobox.Options, { className: "absolute mt-1 max-h-60 w-full md:w-[100vh] overflow-auto rounded-md bg-white py-0 text-base shadow-lg ring-1 ring-black/5 focus:outline-none sm:text-xs", children: [
              filteredOption && filteredOption.length > 0 ? /* @__PURE__ */ jsxs(
                "div",
                {
                  className: `flex flex-row p-2 w-full font-bold bg-lightBlue-800 text-lightBlue-300 border-lightBlue-700 z-50`,
                  children: [
                    /* @__PURE__ */ jsx("div", { className: "w-[8%]", children: "Kode" }),
                    /* @__PURE__ */ jsx("div", { className: "w-[16%]", children: "Kantor" }),
                    /* @__PURE__ */ jsx("div", { className: "w-[15%]", children: "Ruang" }),
                    /* @__PURE__ */ jsx("div", { className: "w-[30%]", children: "Nama Tempat Berkas" }),
                    /* @__PURE__ */ jsx("div", { className: "w-[15%]", children: "Jenis" }),
                    /* @__PURE__ */ jsx("div", { className: "w-[8%]", children: "Baris" }),
                    /* @__PURE__ */ jsx("div", { className: "w-[8%]", children: "Kolom" })
                  ]
                }
              ) : null,
              filteredOption && filteredOption.length === 0 && query !== "" ? /* @__PURE__ */ jsx("div", { className: "relative cursor-default select-none px-2 py-2 text-gray-700", children: "Nothing value." }) : filteredOption && filteredOption.map(
                (tempatarsip) => /* @__PURE__ */ jsx(
                  Combobox.Option,
                  {
                    className: ({ active }) => `relative cursor-default select-none pr-2 ${active ? "bg-lightBlue-600 text-white" : "text-lightBlue-950"}`,
                    value: tempatarsip,
                    children: ({ selected, active }) => {
                      var _a;
                      return /* @__PURE__ */ jsxs(
                        "div",
                        {
                          className: `flex flex-row p-2 w-full ${selected ? "font-bold" : ""}`,
                          children: [
                            /* @__PURE__ */ jsx("div", { className: "w-[8%]", children: tempatarsip.kode_tempatarsip }),
                            /* @__PURE__ */ jsx("div", { className: "w-[16%]", children: tempatarsip.ruang.kantor.nama_kantor }),
                            /* @__PURE__ */ jsx("div", { className: "w-[15%]", children: (_a = tempatarsip.ruang) == null ? void 0 : _a.nama_ruang }),
                            /* @__PURE__ */ jsx("div", { className: "w-[30%]", children: tempatarsip.nama_tempatarsip }),
                            /* @__PURE__ */ jsx("div", { className: "w-[15%]", children: tempatarsip.jenistempatarsip.nama_jenistempatarsip }),
                            /* @__PURE__ */ jsx("div", { className: "w-[8%]", children: tempatarsip.baris }),
                            /* @__PURE__ */ jsx("div", { className: "w-[8%]", children: tempatarsip.kolom })
                          ]
                        }
                      );
                    }
                  },
                  tempatarsip.id
                )
              )
            ] })
          }
        ),
        errors ? /* @__PURE__ */ jsx("span", { className: "text-sm text-red-500", children: errors }) : null
      ] })
    }
  ) });
}
const Create = ({ baseRoute, ctranspermohonan, ctempatarsip }) => {
  const [transpermohonan, setTranspermohonan] = useState(ctranspermohonan);
  const [tempatarsip, setTempatarsip] = useState(ctempatarsip);
  const [values, setValues] = useState({
    transpermohonan_id: ctranspermohonan ? ctranspermohonan.id : ""
    // tempatarsip_id: ctempatarsip ? ctempatarsip.id : "",
  });
  const { data, setData, errors, post, processing } = useForm({
    tempatarsip_id: tempatarsip ? tempatarsip.id : "",
    transpermohonan_id: transpermohonan ? transpermohonan.id : "",
    _method: "PUT"
  });
  function handleSubmit(e) {
    e.preventDefault();
    useSwal.confirm({
      title: "Simpan Data",
      text: "apakah akan menyimpan?"
    }).then((result) => {
      if (result.isConfirmed) {
        post(
          route(
            baseRoute + "transaksi.transpermohonans.tempatarsips.store",
            transpermohonan ? transpermohonan.id : ""
          )
        );
      }
    });
  }
  const setCtranspermohonan = (transperm) => {
    if (transperm) {
      setData({
        ...data,
        transpermohonan_id: transperm.id
      });
      setTranspermohonan(transperm);
      setValues((prev) => ({
        ...prev,
        transpermohonan_id: transperm.id
      }));
    } else {
      setValues((prev) => ({
        ...prev,
        transpermohonan_id: ""
      }));
    }
  };
  const setCtempatarsip = (tmparsip) => {
    if (tmparsip) {
      setData({
        ...data,
        tempatarsip_id: tmparsip.id
      });
      setTempatarsip(tmparsip);
    } else {
      setTempatarsip(null);
    }
  };
  const prevValues = usePrevious(values);
  const transpermohonanRef = useRef(null);
  const tempatarsipRef = useRef(null);
  useEffect(() => {
    if (prevValues) {
      const query = Object.keys(pickBy(values)).length ? pickBy(values) : {};
      router.get(
        route(route().current() ? route().current() + "" : ""),
        query,
        {
          replace: true,
          preserveState: false
        }
      );
      setTempatarsip(ctempatarsip ? ctempatarsip : null);
    }
  }, [values]);
  return /* @__PURE__ */ jsx(StafLayout, { children: /* @__PURE__ */ jsx("div", { className: "flex content-center items-center justify-center h-full", children: /* @__PURE__ */ jsx("div", { className: "w-full md:w-[80%] px-4", children: /* @__PURE__ */ jsxs("div", { className: "relative flex flex-col min-w-0 break-words w-full mb-6 shadow-lg rounded-lg bg-blueGray-200 border-0", children: [
    /* @__PURE__ */ jsxs("div", { className: "rounded-t mb-0 px-6 py-6", children: [
      /* @__PURE__ */ jsx("div", { className: "text-center mb-3", children: /* @__PURE__ */ jsx("h6", { className: "text-blueGray-500 text-lg font-bold", children: "Tempat Arsip Permohonan" }) }),
      /* @__PURE__ */ jsx("hr", { className: "mt-6 border-b-1 border-blueGray-300" })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "flex-auto px-4 lg:px-10 py-10 pt-0", children: /* @__PURE__ */ jsxs("form", { onSubmit: handleSubmit, children: [
      /* @__PURE__ */ jsx(
        TranspermohonanSelect,
        {
          inputRef: transpermohonanRef,
          isStaf: true,
          onValueChange: (transperm, opt) => setCtranspermohonan(transperm),
          value: transpermohonan,
          errors: errors.transpermohonan_id
        }
      ),
      /* @__PURE__ */ jsx(
        CardTranspermohonanEditable,
        {
          base_route: baseRoute,
          permohonan: transpermohonan,
          setPermohonan: (perm) => setTranspermohonan(perm)
        }
      ),
      /* @__PURE__ */ jsx(
        TempatarsipSelect,
        {
          className: "mt-2",
          inputRef: tempatarsipRef,
          isStaf: false,
          onValueChange: (tmparsip, opt) => {
            setCtempatarsip(tmparsip);
          },
          value: tempatarsip,
          errors: errors.tempatarsip_id
        }
      ),
      tempatarsip ? /* @__PURE__ */ jsx("div", { className: "relative flex flex-col min-w-0 break-words w-full mb-2 shadow-lg rounded-lg bg-blueGray-50 border-0 text-xs mt-2", children: /* @__PURE__ */ jsxs("div", { className: "flex-auto px-2 lg:px-4 py-4 pt-0 ", children: [
        /* @__PURE__ */ jsxs("div", { className: "relative w-full mt-2 grid grid-cols-2 md:grid-cols-4 gap-1", children: [
          /* @__PURE__ */ jsx("div", { children: "Kantor" }),
          /* @__PURE__ */ jsx("div", { children: tempatarsip.ruang.kantor.nama_kantor }),
          /* @__PURE__ */ jsx("div", { children: "Ruang" }),
          /* @__PURE__ */ jsx("div", { children: tempatarsip.ruang.nama_ruang }),
          /* @__PURE__ */ jsx("div", { children: "Nama Tempat" }),
          /* @__PURE__ */ jsx("div", { children: tempatarsip.nama_tempatarsip }),
          /* @__PURE__ */ jsx("div", { children: "Jenis" }),
          /* @__PURE__ */ jsx("div", { children: tempatarsip.jenistempatarsip.nama_jenistempatarsip })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "relative w-full mt-2 grid grid-cols-1 md:grid-cols-2 gap-1", children: [
          /* @__PURE__ */ jsx("div", { className: "grid grid-cols-1 row-span-2", children: /* @__PURE__ */ jsx("div", { className: "flex flex-wrap justify-center p-2", children: tempatarsip.image_tempatarsip ? /* @__PURE__ */ jsx("div", { className: "w-full group rounded-lg bg-gray-400 overflow-hidden border-2 cursor-pointer", children: /* @__PURE__ */ jsx(
            "img",
            {
              src: tempatarsip.image_tempatarsip,
              alt: "...",
              className: "shadow rounded max-w-full h-auto align-middle border-none transition-all group-hover:scale-110 group-hover:bg-gray-600"
            }
          ) }) : null }) }),
          /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-2 ", children: [
            /* @__PURE__ */ jsx("div", { children: "baris" }),
            /* @__PURE__ */ jsx("div", { children: tempatarsip.baris }),
            /* @__PURE__ */ jsx("div", { children: "Kolom" }),
            /* @__PURE__ */ jsx("div", { children: tempatarsip.kolom }),
            /* @__PURE__ */ jsx("div", { children: "Kode" }),
            /* @__PURE__ */ jsx("div", { children: tempatarsip.kode_tempatarsip })
          ] })
        ] })
      ] }) }) : null,
      /* @__PURE__ */ jsx(
        LoadingButton,
        {
          disabled: (ctempatarsip == null ? void 0 : ctempatarsip.id) === data.tempatarsip_id || tempatarsip === null,
          className: "mt-2",
          theme: "black",
          loading: processing,
          type: "submit",
          children: /* @__PURE__ */ jsx("span", { children: "Simpan" })
        }
      )
    ] }) })
  ] }) }) }) });
};
export {
  Create as default
};
