import { jsxs, jsx } from "react/jsx-runtime";
import { C as CardFilterProsesbyPermohonan } from "./style.min-55dc4264.js";
import { P as Pagination } from "./Pagination-30af682d.js";
import moment from "moment";
import { VerticalTimeline, VerticalTimelineElement } from "react-vertical-timeline-component";
import { A as AdminLayout } from "./AdminLayout-4bc80775.js";
import { usePage } from "@inertiajs/react";
import "./PilihStatusprosesperm-521513a1.js";
import "@headlessui/react";
import "./SelectSearch-22ab8168.js";
import "lodash";
import "react";
import "react-select";
import "tailwind-merge";
import "./TranspermohonanSelect-e6be2ec6.js";
import "@heroicons/react/20/solid";
import "swr";
import "./bootstrap-b9d9b211.js";
import "axios";
import "./ListboxSelect-3ce899e5.js";
import "./Modal-d06b3568.js";
import "./LinkButton-a291522b.js";
import "@zxing/browser";
import "./useScreenSize-4351026c.js";
import "react-use";
import "classnames";
import "./NotificationDropdown-abde11b8.js";
import "@popperjs/core";
import "./ResponsiveNavLink-41b4fa07.js";
import "react-hot-toast";
import "./AuthContext-5300e6b5.js";
import "firebase/app";
import "firebase/auth";
import "firebase/firestore";
import "firebase/storage";
import "firebase/messaging";
import "./MenuItem-f3c50e94.js";
const CardListProsesbyPermohonanTimeline = ({
  prosespermohonans: { data, links },
  transpermohonan
}) => {
  var _a, _b;
  return /* @__PURE__ */ jsxs("div", { className: "p-4 flex flex-col text-xs bg-blueGray-200 rounded-md shadow-lg shadow-gray-400 ", children: [
    /* @__PURE__ */ jsx("h1", { className: "font-bold text-lg text-lightBlue-700 mb-2", children: "Proses Permohonan" }),
    transpermohonan && /* @__PURE__ */ jsxs("div", { className: "w-full grid grid-cols-1 md:grid-cols-2 mt-0 bg-white px-2 shadow-md rounded-md p-2", children: [
      /* @__PURE__ */ jsxs("div", { className: "w-full flex items-start flex-wrap", children: [
        /* @__PURE__ */ jsx("div", { className: "w-1/4", children: "Permohonan" }),
        /* @__PURE__ */ jsxs("div", { className: "w-3/4", children: [
          transpermohonan.jenispermohonan.nama_jenispermohonan,
          " - ",
          transpermohonan.no_daftar
        ] }),
        /* @__PURE__ */ jsx("div", { className: "w-1/4", children: "Pelepas" }),
        /* @__PURE__ */ jsx("div", { className: "w-3/4", children: transpermohonan.permohonan.nama_pelepas }),
        /* @__PURE__ */ jsx("div", { className: "w-1/4", children: "Penerima" }),
        /* @__PURE__ */ jsx("div", { className: "w-3/4", children: transpermohonan.permohonan.nama_penerima }),
        /* @__PURE__ */ jsx("div", { className: "w-1/4", children: "Alas Hak" }),
        /* @__PURE__ */ jsxs("div", { className: "w-3/4", children: [
          (_a = transpermohonan.permohonan.jenishak) == null ? void 0 : _a.singkatan,
          transpermohonan.permohonan.nomor_hak,
          ",",
          " ",
          ((_b = transpermohonan.permohonan.jenishak) == null ? void 0 : _b.singkatan) == "C" ? "Ps " + transpermohonan.permohonan.persil + ", " + transpermohonan.permohonan.klas : null,
          " ",
          "L.",
          transpermohonan.permohonan.luas_tanah,
          "M2"
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "w-full flex items-start flex-wrap", children: [
        /* @__PURE__ */ jsx("div", { className: "w-1/4", children: "Atas Nama" }),
        /* @__PURE__ */ jsx("div", { className: "w-3/4", children: transpermohonan.permohonan.atas_nama }),
        /* @__PURE__ */ jsx("div", { className: "w-1/4", children: "Lokasi" }),
        /* @__PURE__ */ jsxs("div", { className: "w-3/4", children: [
          "Desa ",
          transpermohonan.permohonan.letak_obyek
        ] }),
        /* @__PURE__ */ jsx("div", { className: "w-1/4", children: "User" }),
        /* @__PURE__ */ jsx("div", { className: "w-3/4", children: transpermohonan.permohonan.users && transpermohonan.permohonan.users.length > 0 && transpermohonan.permohonan.users.map((u, i) => /* @__PURE__ */ jsxs("span", { children: [
          i > 0 ? ", " : "",
          u.name
        ] }, i)) }),
        /* @__PURE__ */ jsx("div", { className: "w-1/4", children: " " }),
        /* @__PURE__ */ jsx("div", { className: "w-3/4" })
      ] })
    ] }),
    data && data.map((p, i) => /* @__PURE__ */ jsx(VerticalTimeline, { children: p.statusprosesperms && p.statusprosesperms.map((e, idx) => /* @__PURE__ */ jsx(
      VerticalTimelineElement,
      {
        className: "vertical-timeline-element--work",
        position: `${i % 2 === 0 ? "left" : "right"}`,
        contentStyle: {
          background: "rgb(90, 135, 177)",
          color: "#fff",
          padding: "10px"
        },
        contentArrowStyle: {
          borderRight: "7px solid  rgb(33, 150, 243)"
        },
        dateClassName: "timeline-date",
        date: moment(e.pivot.created_at).format(
          "DD MMM YYYY HH:mm"
        ),
        iconStyle: {
          background: "rgba(168, 229, 245, 1)",
          color: "#fff"
        },
        icon: /* @__PURE__ */ jsx("div", { className: "rounded-full p-2", children: /* @__PURE__ */ jsx(
          "img",
          {
            src: e.image_statusprosesperm,
            className: "w-full"
          }
        ) }),
        children: /* @__PURE__ */ jsxs("div", { className: "w-full flex flex-col p-2 text-sm bg-white/20 shadow-md rounded-md", children: [
          /* @__PURE__ */ jsx("h3", { className: "vertical-timeline-element-title text-sm font-bold text-yellow-300 ", children: p.itemprosesperm.nama_itemprosesperm }),
          /* @__PURE__ */ jsx("h4", { className: "vertical-timeline-element-subtitle text-xs", children: e.nama_statusprosesperm }),
          /* @__PURE__ */ jsx("div", { className: "flex flex-row justify-between text-xs", children: p.catatan_prosesperm })
        ] })
      },
      e.id
    )) }, p.id)),
    data && data.length > 0 && /* @__PURE__ */ jsx(VerticalTimeline, { children: /* @__PURE__ */ jsx(
      VerticalTimelineElement,
      {
        iconStyle: {
          background: "rgb(16, 204, 82)",
          color: "#fff"
        },
        icon: /* @__PURE__ */ jsx(
          "svg",
          {
            className: "MuiSvgIcon-root",
            focusable: "false",
            viewBox: "0 0 24 24",
            "aria-hidden": "true",
            children: /* @__PURE__ */ jsx("path", { d: "M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" })
          }
        )
      }
    ) }),
    /* @__PURE__ */ jsx(Pagination, { links })
  ] });
};
const ByPermohonan = () => {
  const { itemprosespermsOpts, prosespermohonans, transpermohonan } = usePage().props;
  return /* @__PURE__ */ jsx(AdminLayout, { children: /* @__PURE__ */ jsxs("div", { className: "flex flex-col md:flex-row items-start gap-2", children: [
    /* @__PURE__ */ jsx("div", { className: "w-full md:w-1/3", children: /* @__PURE__ */ jsx(
      CardFilterProsesbyPermohonan,
      {
        itemprosespermsOpts
      }
    ) }),
    /* @__PURE__ */ jsx("div", { className: "w-full md:w-2/3", children: /* @__PURE__ */ jsx(
      CardListProsesbyPermohonanTimeline,
      {
        prosespermohonans,
        transpermohonan
      }
    ) })
  ] }) });
};
export {
  ByPermohonan as default
};
