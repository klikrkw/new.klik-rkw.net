import { jsx, Fragment, jsxs } from "react/jsx-runtime";
import { Head } from "@inertiajs/react";
import { C as CardSocialTraffic, a as CardPageVisits } from "./CardSocialTraffic-b8ae4410.js";
import { S as StafLayout } from "./StafLayout-f28c615d.js";
import { D as DashboardIcon, C as CardNotifications, B as BasicCalendar } from "./BasicCalender-7faf871f.js";
import "./NotificationDropdown-abde11b8.js";
import "react";
import "@popperjs/core";
import "./ResponsiveNavLink-41b4fa07.js";
import "react-hot-toast";
import "./AuthContext-5300e6b5.js";
import "firebase/app";
import "firebase/auth";
import "firebase/firestore";
import "firebase/storage";
import "./bootstrap-b9d9b211.js";
import "axios";
import "firebase/messaging";
import "./MenuItem-f3c50e94.js";
import "moment";
import "react-big-calendar";
import "moment/dist/locale/id.js";
function CardStafMenus({ baseRoute }) {
  return /* @__PURE__ */ jsx(Fragment, { children: /* @__PURE__ */ jsx("div", { className: "relative flex flex-col min-w-0 break-words bg-slate-200 w-full shadow-lg rounded min-h-[590px]", children: /* @__PURE__ */ jsx("div", { className: "block w-full overflow-x-auto", children: /* @__PURE__ */ jsxs("div", { className: "flex flex-col p-4 ", children: [
    /* @__PURE__ */ jsx("div", { className: "w-full p-2 mb-2 bg-slate-400 shadow-md", children: /* @__PURE__ */ jsx("h1", { className: "font-bold text-blueGray-200", children: "Data Master" }) }),
    /* @__PURE__ */ jsx("div", { className: "grid grid-cols-3 md:grid-cols-6 gap-3 px-2 ", children: /* @__PURE__ */ jsx(
      DashboardIcon,
      {
        url: baseRoute + "permohonans.index",
        title: "Permohonan",
        iconName: "fa-address-card"
      }
    ) }),
    /* @__PURE__ */ jsx("div", { className: "w-full p-2 mb-2 bg-slate-400 shadow-md mt-3", children: /* @__PURE__ */ jsx("h1", { className: "font-bold text-blueGray-200", children: "Transaksi Umum" }) }),
    /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-3 md:grid-cols-6 gap-3 px-2 ", children: [
      /* @__PURE__ */ jsx(
        DashboardIcon,
        {
          url: baseRoute + "transaksi.prosespermohonans.create",
          title: "Proses Permohonan",
          iconName: "fa-gears"
        }
      ),
      /* @__PURE__ */ jsx(
        DashboardIcon,
        {
          url: baseRoute + "transaksi.transpermohonans.posisiberkas.create",
          title: "Tempat Berkas",
          iconName: "fa-archive"
        }
      )
    ] }),
    /* @__PURE__ */ jsx("div", { className: "w-full p-2 mb-2 bg-slate-400 shadow-md mt-3", children: /* @__PURE__ */ jsx("h1", { className: "font-bold text-blueGray-200", children: "Transaksi Keuangan" }) }),
    /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-3 md:grid-cols-6 gap-3 px-2 ", children: [
      /* @__PURE__ */ jsx(
        DashboardIcon,
        {
          url: baseRoute + "transaksi.rincianbiayaperms.index",
          title: "Rincian Biaya",
          iconName: "fa-list-ol"
        }
      ),
      /* @__PURE__ */ jsx(
        DashboardIcon,
        {
          url: baseRoute + "transaksi.biayaperms.create",
          title: "Biaya Permohonan",
          iconName: "fa-shopping-cart"
        }
      ),
      /* @__PURE__ */ jsx(
        DashboardIcon,
        {
          url: baseRoute + "transaksi.kasbons.index",
          title: "Kasbon",
          iconName: "fa-shopping-bag"
        }
      ),
      /* @__PURE__ */ jsx(
        DashboardIcon,
        {
          url: baseRoute + "transaksi.keluarbiayas.index",
          title: "Pengeluaran Umum",
          iconName: "fa-shopping-cart"
        }
      ),
      /* @__PURE__ */ jsx(
        DashboardIcon,
        {
          url: baseRoute + "transaksi.keluarbiayapermusers.index",
          title: "Pengeluaran Permohonan",
          iconName: "fa-shopping-cart"
        }
      ),
      /* @__PURE__ */ jsx(
        DashboardIcon,
        {
          url: baseRoute + "transaksi.events.index",
          title: "Event",
          iconName: "fa-calendar"
        }
      )
    ] }),
    /* @__PURE__ */ jsx("div", { className: "w-full p-2 mb-2 bg-slate-400 shadow-md mt-3", children: /* @__PURE__ */ jsx("h1", { className: "font-bold text-blueGray-200", children: "Informasi" }) }),
    /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-3 md:grid-cols-6 gap-3 px-2 ", children: [
      /* @__PURE__ */ jsx(
        DashboardIcon,
        {
          url: baseRoute + "informasi.prosespermohonans.index",
          title: "Proses Permohonan",
          iconName: "fa-list"
        }
      ),
      /* @__PURE__ */ jsx(
        DashboardIcon,
        {
          url: baseRoute + "informasi.prosespermohonans.bypermohonan",
          title: "Proses By Permohonan",
          iconName: "fa-list"
        }
      ),
      /* @__PURE__ */ jsx(
        DashboardIcon,
        {
          url: baseRoute + "informasi.keuangans.keluarbiayas",
          title: "Pengeluaran Umum",
          iconName: "fa-list"
        }
      ),
      /* @__PURE__ */ jsx(
        DashboardIcon,
        {
          url: baseRoute + "informasi.keuangans.keluarbiayapermusers",
          title: "Pengeluaran Permohonan",
          iconName: "fa-users"
        }
      ),
      /* @__PURE__ */ jsx(
        DashboardIcon,
        {
          url: baseRoute + "permohonans.qrcode.create",
          title: "Label Berkas dan Qr Qode",
          iconName: "fa-qrcode"
        }
      )
    ] })
  ] }) }) }) });
}
function StafDashboard({
  auth,
  traffics,
  recentActivities,
  events,
  baseRoute
}) {
  return /* @__PURE__ */ jsxs(
    StafLayout,
    {
      header: /* @__PURE__ */ jsx("h2", { className: "font-semibold text-xl text-gray-800 leading-tight", children: "Dashboard" }),
      children: [
        /* @__PURE__ */ jsx(Head, { title: "Dashboard" }),
        /* @__PURE__ */ jsxs(Fragment, { children: [
          /* @__PURE__ */ jsxs("div", { className: "flex flex-wrap", children: [
            /* @__PURE__ */ jsx("div", { className: "w-full xl:w-8/12 mb-12 xl:mb-6 ", children: /* @__PURE__ */ jsx(CardStafMenus, { baseRoute }) }),
            /* @__PURE__ */ jsx("div", { className: "w-full xl:w-4/12 px-4", children: /* @__PURE__ */ jsx(CardNotifications, { user: auth.user }) })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex flex-wrap mt-4", children: [
            /* @__PURE__ */ jsx("div", { className: "w-full xl:w-8/12 mb-12 xl:mb-0 px-4", children: /* @__PURE__ */ jsx(BasicCalendar, { events }) }),
            /* @__PURE__ */ jsxs("div", { className: "w-full xl:w-4/12 px-4", children: [
              /* @__PURE__ */ jsx(CardSocialTraffic, { traffics }),
              /* @__PURE__ */ jsx(CardPageVisits, { recentActivities })
            ] })
          ] })
        ] })
      ]
    }
  );
}
export {
  StafDashboard as default
};
