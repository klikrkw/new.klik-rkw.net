import { jsx } from "react/jsx-runtime";
import { A as AdminLayout } from "./AdminLayout-4bc80775.js";
import { C as CardTableKeluarbiayapermusers } from "./CardTableKeluarbiayapermusers-d239073a.js";
import "./NotificationDropdown-abde11b8.js";
import "react";
import "@popperjs/core";
import "./ResponsiveNavLink-41b4fa07.js";
import "@inertiajs/react";
import "react-hot-toast";
import "./AuthContext-5300e6b5.js";
import "firebase/app";
import "firebase/auth";
import "firebase/firestore";
import "firebase/storage";
import "./bootstrap-b9d9b211.js";
import "axios";
import "firebase/messaging";
import "./MenuItem-f3c50e94.js";
import "tailwind-merge";
import "react-use";
import "lodash";
import "./Pagination-30af682d.js";
import "classnames";
import "./InputSearch-6032da7e.js";
import "./LinkButton-a291522b.js";
import "./AsyncSelectSearch-23c2f5cb.js";
import "react-select/async";
import "./index-d9460823.js";
import "./SelectSearch-22ab8168.js";
import "react-select";
const Index = ({ keluarbiayapermusers }) => {
  const {
    data,
    meta,
    links
  } = keluarbiayapermusers;
  return /* @__PURE__ */ jsx(AdminLayout, { children: /* @__PURE__ */ jsx(CardTableKeluarbiayapermusers, { color: "dark", keluarbiayapermusers: data, meta, labelLinks: links }) });
};
export {
  Index as default
};
