import { jsx, Fragment, jsxs } from "react/jsx-runtime";
import { useState, useEffect } from "react";
import { u as useAuth } from "./AuthContext-5300e6b5.js";
import { usePage, Link } from "@inertiajs/react";
import moment from "moment";
import { Calendar as Calendar$1, momentLocalizer, Views } from "react-big-calendar";
import "moment/dist/locale/id.js";
const reactBigCalendar = "";
function CardNotifications({ user }) {
  const {
    currentUser,
    login,
    logout,
    getFirestoreDocsRealTime,
    removeExpiredFirestoreDocuments
  } = useAuth();
  const { fbtoken } = usePage().props;
  const [notifications, setNotifications] = useState();
  useEffect(() => {
    if (!currentUser) {
      login(fbtoken);
    }
    getFirestoreDocsRealTime("notifications", user.id, (notifs) => {
      setNotifications(notifs);
    });
    removeExpiredFirestoreDocuments("notifications");
  }, []);
  return /* @__PURE__ */ jsx(Fragment, { children: /* @__PURE__ */ jsxs("div", { className: "relative flex flex-col min-w-0 break-words bg-white w-full mb-6 shadow-lg rounded pb-4", children: [
    /* @__PURE__ */ jsx("div", { className: "rounded-t mb-0 px-4 py-3 border-0", children: /* @__PURE__ */ jsx("div", { className: "flex flex-wrap items-center", children: /* @__PURE__ */ jsx("div", { className: "relative w-full max-w-full flex-grow flex-1", children: /* @__PURE__ */ jsx("h3", { className: "font-semibold text-base text-blueGray-700", children: "Notifikasi" }) }) }) }),
    /* @__PURE__ */ jsx("div", { className: "block w-full overflow-x-auto h-[530px] px-4", children: /* @__PURE__ */ jsx("ol", { children: notifications && notifications.map((notif, idx) => /* @__PURE__ */ jsxs(
      "li",
      {
        className: "flex flex-col text-sm rounded-md bg-yellow-400/50 mb-2 p-2 shadow-md",
        children: [
          /* @__PURE__ */ jsxs("div", { className: "flex flex-row justify-between items-center bg-yellow-400/90 rounded-full px-2 shadow-md", children: [
            /* @__PURE__ */ jsx("span", { className: "font-bold", children: notif.title }),
            /* @__PURE__ */ jsx("span", { className: "text-xs italic", children: moment(
              notif.timestamp.toDate()
            ).format("DD/MM/YYYY H:m:s") })
          ] }),
          /* @__PURE__ */ jsx("div", { className: "text-xs px-2 py-1", children: notif.body })
        ]
      },
      idx
    )) }) })
  ] }) });
}
const DashboardIcon = ({ title: title2, iconName, url }) => {
  return /* @__PURE__ */ jsx(Link, { href: route(url), className: "group", children: /* @__PURE__ */ jsxs("div", { className: "w-24 h-16 p-2 rounded-lg bg-white text-sm flex flex-col justify-center items-center shadow-lg border-2 border-white/90 transition-all group-hover:scale-110", children: [
    /* @__PURE__ */ jsx("i", { className: `fas ${iconName} text-xl` }),
    /* @__PURE__ */ jsx("div", { className: "mt-1 text-xs text-blueGray-800 text-center", children: title2 })
  ] }) });
};
const DashboardIcon$1 = DashboardIcon;
moment.locale("id");
const localizer = momentLocalizer(moment);
function Calendar(props) {
  return /* @__PURE__ */ jsx(Calendar$1, { ...props, localizer });
}
const index = "";
function BasicCalendar({ events }) {
  const event = ({ event: event2 }) => {
    return /* @__PURE__ */ jsx("div", { className: "text-xs py-1 flex flex-col items-start w-full px-1", children: /* @__PURE__ */ jsxs("div", { className: "flex flex-col h-16 overflow-x-auto no-scrollbar", children: [
      /* @__PURE__ */ jsx(
        "div",
        {
          className: "request-top",
          style: {
            whiteSpace: "pre-wrap",
            overflowWrap: "break-word"
          },
          children: event2.title
        }
      ),
      /* @__PURE__ */ jsx(
        "div",
        {
          className: "request-top",
          style: {
            whiteSpace: "pre-wrap",
            overflowWrap: "break-word"
          },
          children: event2.data
        }
      )
    ] }) });
  };
  for (let index2 = 0; index2 < events.length; index2++) {
    var element = events[index2];
    element.start = moment(element.start).toDate();
    element.end = moment(element.end).toDate();
    events[index2] = element;
  }
  useState(false);
  useState();
  return /* @__PURE__ */ jsx("div", { className: "p-4 bg-white rounded-lg shadow-lg w-full h-full inline-block", children: /* @__PURE__ */ jsx(
    Calendar,
    {
      events,
      style: { minHeight: 500 },
      components: { event },
      step: 10,
      defaultView: Views.MONTH
    }
  ) });
}
export {
  BasicCalendar as B,
  CardNotifications as C,
  DashboardIcon$1 as D
};
