import { jsxs, jsx } from "react/jsx-runtime";
import { P as Pilihstatusprosesperm } from "./PilihStatusprosesperm-521513a1.js";
import { S as SelectSearch } from "./SelectSearch-22ab8168.js";
import { T as TranspermohonanSelect } from "./TranspermohonanSelect-e6be2ec6.js";
import { usePage, router } from "@inertiajs/react";
import { pickBy } from "lodash";
import { useRef, useState, useEffect } from "react";
import { usePrevious } from "react-use";
const CardFilterProsesbyPermohonan = ({ itemprosespermsOpts }) => {
  const transPermSelectRef = useRef();
  const {
    itemprosesperm_id,
    statusprosesperms,
    statusprosesperm_id,
    transpermohonan_id,
    transpermohonan
  } = usePage().props;
  const [values, setValues] = useState({
    itemprosesperm_id,
    statusprosesperm_id,
    transpermohonan_id
  });
  const prevValues = usePrevious(values);
  const itemprosesperm = itemprosespermsOpts.find(
    (e) => e.value == itemprosesperm_id
  );
  const statusprosesperm = statusprosesperms.find(
    (e) => e.id == statusprosesperm_id
  );
  const [ctranspermohonan, setCtranspermohonan] = useState(transpermohonan);
  useEffect(() => {
    if (prevValues) {
      const query = Object.keys(pickBy(values)).length ? pickBy(values) : {};
      router.get(
        route(route().current() ? route().current() + "" : ""),
        query,
        {
          replace: true,
          preserveState: true
        }
      );
    }
  }, [values]);
  useEffect(() => {
    if (ctranspermohonan) {
      if (transPermSelectRef.current) {
        transPermSelectRef.current.value = ctranspermohonan.permohonan.nama_penerima;
      }
    }
  }, []);
  return /* @__PURE__ */ jsxs("div", { className: "py-2 px-4 bg-blueGray-200 shadow-lg rounded-lg flex flex-col shadow-gray-400", children: [
    /* @__PURE__ */ jsx("h1", { className: "font-bold text-lightBlue-700 mb-2", children: "Permohonan" }),
    /* @__PURE__ */ jsx(
      TranspermohonanSelect,
      {
        inputRef: transPermSelectRef,
        value: ctranspermohonan,
        className: "mb-1",
        onValueChange: (e) => {
          setCtranspermohonan(e);
          setValues((v) => ({
            ...v,
            transpermohonan_id: e ? e.id : ""
          }));
        }
      }
    ),
    /* @__PURE__ */ jsx("h1", { className: "font-bold text-lightBlue-700 mb-2", children: "Nama Proses" }),
    /* @__PURE__ */ jsx(
      SelectSearch,
      {
        options: itemprosespermsOpts,
        value: itemprosesperm,
        onChange: (e) => {
          setValues((v) => ({ ...v, itemprosesperm_id: e.value }));
        }
      }
    ),
    /* @__PURE__ */ jsx("h1", { className: "font-bold text-lightBlue-700 mb-2", children: "Status Proses" }),
    /* @__PURE__ */ jsx(
      Pilihstatusprosesperm,
      {
        statusprosesperms,
        statusprosesperm,
        setStatusprosesperm: (e) => {
          setValues((v) => ({ ...v, statusprosesperm_id: e.id }));
        }
      }
    )
  ] });
};
const style_min = "";
export {
  CardFilterProsesbyPermohonan as C
};
