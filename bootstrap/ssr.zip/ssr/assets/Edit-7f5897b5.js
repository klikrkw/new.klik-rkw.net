import { jsxs, jsx } from "react/jsx-runtime";
import { M as ModalCetakLaporan } from "./ModalCetakLaporan-767963a0.js";
import { P as PrintDialog } from "./PrintDialog-e8e99716.js";
import { I as Input } from "./Input-72be4948.js";
import { L as LinkButton } from "./LinkButton-a291522b.js";
import { L as LoadingButton } from "./LoadingButton-c9189101.js";
import { N as NumberInput } from "./NumberInput-0f6b329c.js";
import { S as SelectSearch } from "./SelectSearch-22ab8168.js";
import { U as UploadImage } from "./UploadImage-dc2b2f0d.js";
import { A as AdminLayout } from "./AdminLayout-4bc80775.js";
import { useForm } from "@inertiajs/react";
import { useState } from "react";
import "./Modal-d06b3568.js";
import "@headlessui/react";
import "./bootstrap-b9d9b211.js";
import "axios";
import "react-dom";
import "@emotion/react";
import "@emotion/cache";
import "react-loader-spinner";
import "./Button-e2b11bd9.js";
import "tailwind-merge";
import "classnames";
import "react-number-format";
import "lodash";
import "react-select";
import "firebase/storage";
import "./AuthContext-5300e6b5.js";
import "firebase/app";
import "firebase/auth";
import "firebase/firestore";
import "firebase/messaging";
import "react-image-file-resizer";
import "./NotificationDropdown-abde11b8.js";
import "@popperjs/core";
import "./ResponsiveNavLink-41b4fa07.js";
import "react-hot-toast";
import "./MenuItem-f3c50e94.js";
const Edit = ({
  tempatarsip,
  baseDir,
  baseRoute,
  selRuangOpt,
  ruangOpts,
  selJenistempatarsipOpt,
  jenistempatarsipOpts,
  base_route
}) => {
  const { data, setData, errors, post, processing } = useForm({
    id: tempatarsip.id || "",
    nama_tempatarsip: tempatarsip.nama_tempatarsip || "",
    kode_tempatarsip: tempatarsip.kode_tempatarsip || "",
    image_tempatarsip: tempatarsip.image_tempatarsip || "",
    ruang_id: tempatarsip.ruang.id || "",
    baris: tempatarsip.baris || 0,
    kolom: tempatarsip.kolom || 0,
    ruang: selRuangOpt || void 0,
    jenistempatarsip_id: tempatarsip.jenistempatarsip.id || "",
    jenistempatarsip: selJenistempatarsipOpt || void 0,
    _method: "PUT"
  });
  function handleSubmit(e) {
    e.preventDefault();
    post(route("admin.tempatarsips.update", tempatarsip.id));
  }
  const [showModalLaporan, setShowModalLaporan] = useState(false);
  const [showModalPrint, setShowModalPrint] = useState(false);
  const [printData, setPrintData] = useState({
    row: "1",
    col: "1"
  });
  return /* @__PURE__ */ jsxs(AdminLayout, { children: [
    /* @__PURE__ */ jsx("div", { className: "flex content-center items-center justify-center h-full", children: /* @__PURE__ */ jsx("div", { className: "w-full lg:w-2/3 px-4", children: /* @__PURE__ */ jsxs("div", { className: "relative flex flex-col min-w-0 break-words w-full mb-6 shadow-lg rounded-lg bg-blueGray-200 border-0", children: [
      /* @__PURE__ */ jsxs("div", { className: "rounded-t mb-0 px-6 py-6", children: [
        /* @__PURE__ */ jsx("div", { className: "text-center mb-3", children: /* @__PURE__ */ jsx("h6", { className: "text-blueGray-500 text-lg font-bold", children: "Edit Tempatarsip" }) }),
        /* @__PURE__ */ jsx("hr", { className: "mt-6 border-b-1 border-blueGray-300" })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "flex-auto px-4 lg:px-10 py-10 pt-0", children: /* @__PURE__ */ jsxs("form", { onSubmit: handleSubmit, children: [
        /* @__PURE__ */ jsx(
          SelectSearch,
          {
            name: "ruang_id",
            label: "Ruang",
            value: data.ruang,
            options: ruangOpts,
            className: "w-full mb-4",
            onChange: (e) => setData({
              ...data,
              ruang_id: e ? e.value : "",
              ruang: e ? e : {}
            })
          }
        ),
        /* @__PURE__ */ jsx(
          SelectSearch,
          {
            name: "jenistempatarsip_id",
            label: "Jenis Tempat Arsip",
            value: data.jenistempatarsip,
            options: jenistempatarsipOpts,
            className: "w-full mb-4",
            onChange: (e) => setData({
              ...data,
              jenistempatarsip_id: e ? e.value : "",
              jenistempatarsip: e ? e : {}
            })
          }
        ),
        /* @__PURE__ */ jsx(
          Input,
          {
            name: "nama_tempatarsip",
            label: "Nama Tempat Arsip",
            errors: errors.nama_tempatarsip,
            value: data.nama_tempatarsip,
            onChange: (e) => setData(
              "nama_tempatarsip",
              e.target.value
            )
          }
        ),
        /* @__PURE__ */ jsx(
          NumberInput,
          {
            name: "baris",
            label: "Baris",
            errors: errors.baris,
            value: data.baris,
            onChange: (e) => setData(
              "baris",
              parseInt(e.target.value)
            )
          }
        ),
        /* @__PURE__ */ jsx(
          NumberInput,
          {
            name: "kolom",
            label: "Kolom",
            errors: errors.kolom,
            value: data.kolom,
            onChange: (e) => setData(
              "kolom",
              parseInt(e.target.value)
            )
          }
        ),
        /* @__PURE__ */ jsx(
          UploadImage,
          {
            image: data.image_tempatarsip,
            imagePath: "/images/tempatarsips/",
            setImage: (image) => setData("image_tempatarsip", image),
            name: "image_tempatarsip"
          }
        ),
        /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between mt-4", children: [
          /* @__PURE__ */ jsx(
            LinkButton,
            {
              theme: "blueGrey",
              href: route(
                baseRoute + "tempatarsips.index"
              ),
              children: /* @__PURE__ */ jsx("span", { children: "Kembali" })
            }
          ),
          /* @__PURE__ */ jsxs(
            LinkButton,
            {
              theme: "blueGrey",
              href: "#",
              onClick: (e) => {
                e.preventDefault();
                setShowModalPrint(true);
              },
              children: [
                /* @__PURE__ */ jsx("i", { className: "fas fa-qrcode" }),
                /* @__PURE__ */ jsx("span", { className: "ml-1", children: "Cetak Qrcode" })
              ]
            }
          ),
          /* @__PURE__ */ jsx(
            LoadingButton,
            {
              theme: "black",
              loading: processing,
              type: "submit",
              children: /* @__PURE__ */ jsx("span", { children: "Simpan" })
            }
          )
        ] })
      ] }) })
    ] }) }) }),
    /* @__PURE__ */ jsx(
      PrintDialog,
      {
        showModal: showModalPrint,
        setShowModal: (e) => setShowModalPrint(e),
        onCommit: (e) => {
          setPrintData(e);
          setShowModalPrint(false);
          setShowModalLaporan(true);
        }
      }
    ),
    /* @__PURE__ */ jsx(
      ModalCetakLaporan,
      {
        showModal: showModalLaporan,
        setShowModal: setShowModalLaporan,
        src: route(base_route + "tempatarsips.qrcode.cetak", {
          tempatarsip: tempatarsip.id,
          row: printData.row,
          col: printData.col
        })
      }
    )
  ] });
};
export {
  Edit as default
};
