import { jsx, jsxs } from "react/jsx-runtime";
import { C as CardFilterProsespermohonan, a as CardListProsespermohonan } from "./CardListProsespermohonan-54fb6221.js";
import { S as StafLayout } from "./StafLayout-f28c615d.js";
import { usePage } from "@inertiajs/react";
import "./PilihStatusprosesperm-521513a1.js";
import "@headlessui/react";
import "./SelectSearch-22ab8168.js";
import "lodash";
import "react";
import "react-select";
import "tailwind-merge";
import "react-use";
import "./Modal-d06b3568.js";
import "./LoadingButton-c9189101.js";
import "classnames";
import "./LinkButton-a291522b.js";
import "./Input-72be4948.js";
import "./useSwal-5d61a319.js";
import "sweetalert2";
import "moment";
import "./DateInput-8d13eeac.js";
import "react-datepicker";
/* empty css                           */import "./Pagination-30af682d.js";
import "./NotificationDropdown-abde11b8.js";
import "@popperjs/core";
import "./ResponsiveNavLink-41b4fa07.js";
import "react-hot-toast";
import "./AuthContext-5300e6b5.js";
import "firebase/app";
import "firebase/auth";
import "firebase/firestore";
import "firebase/storage";
import "./bootstrap-b9d9b211.js";
import "axios";
import "firebase/messaging";
import "./MenuItem-f3c50e94.js";
const Index = () => {
  const { itemprosespermsOpts, prosespermohonans } = usePage().props;
  return /* @__PURE__ */ jsx(StafLayout, { children: /* @__PURE__ */ jsxs("div", { className: "flex flex-col md:flex-row items-start gap-2", children: [
    /* @__PURE__ */ jsx("div", { className: "w-full md:w-1/3", children: /* @__PURE__ */ jsx(
      CardFilterProsespermohonan,
      {
        itemprosespermsOpts
      }
    ) }),
    /* @__PURE__ */ jsx("div", { className: "w-full md:w-2/3", children: /* @__PURE__ */ jsx(
      CardListProsespermohonan,
      {
        prosespermohonans
      }
    ) })
  ] }) });
};
export {
  Index as default
};
