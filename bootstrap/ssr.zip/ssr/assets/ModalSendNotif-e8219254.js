import { jsx, jsxs } from "react/jsx-runtime";
import { useState } from "react";
import { M as Modal } from "./Modal-d06b3568.js";
import { L as LoadingButton } from "./LoadingButton-c9189101.js";
import { L as LinkButton } from "./LinkButton-a291522b.js";
import { useForm } from "@inertiajs/react";
import { S as SelectSearch } from "./SelectSearch-22ab8168.js";
import { a as apputils } from "./bootstrap-b9d9b211.js";
const ModalSendNotif = ({
  showModal,
  setShowModal,
  userOpts,
  statusprosesperm,
  transpermohonan,
  prosesperm
}) => {
  const notifTypeOpts = [
    { label: "Notification", value: "notification" },
    { label: "Whatsapp", value: "whatsapp" }
  ];
  const [allUser, setAllUser] = useState(true);
  const { data, setData, errors, post, processing, reset } = useForm({
    users: [],
    _method: "POST"
  });
  function handleSubmit(e) {
    e.preventDefault();
    if (!allUser && userOpts.length < 1) {
      return;
    }
    if (statusprosesperm) {
      sendMessageToMobile(
        prosesperm ? prosesperm.itemprosesperm.nama_itemprosesperm : "",
        `${transpermohonan.no_daftar} - [${transpermohonan.jenispermohonan.nama_jenispermohonan} - ${transpermohonan.permohonan.nama_penerima}-${transpermohonan.permohonan.nomor_hak},${transpermohonan.permohonan.letak_obyek}]${statusprosesperm.nama_statusprosesperm} - ${statusprosesperm.pivot.catatan_statusprosesperm ? statusprosesperm.pivot.catatan_statusprosesperm : ""}, Petugas : ${statusprosesperm.user.name}`,
        {
          navigationId: "main"
        },
        pesan
      ).then(() => {
        setShowModal(false);
      });
    } else {
      console.log("error");
    }
  }
  const [notifType, setNotifType] = useState(notifTypeOpts[0]);
  const [users, setUsers] = useState([]);
  const [pesan, setPesan] = useState("");
  const sendMessageToMobile = async (title, body, datas, pesan2) => {
    let xlink = `/admin/messages/api/sendmessagetomobile`;
    if (notifType.value === "whatsapp") {
      xlink = `/admin/notifikasis/api/sendwhatsapp`;
    }
    let userids = users.map((usr) => usr.value);
    if (allUser) {
      userids = userOpts.map((usr) => usr.value);
    }
    if (userids.length < 1) {
      return;
    }
    const response = await apputils.backend.post(xlink, {
      user_ids: userids,
      title,
      body,
      datas,
      pesan: pesan2,
      alluser: allUser
    });
    response.data;
  };
  return /* @__PURE__ */ jsx(
    Modal,
    {
      show: showModal,
      maxWidth: "md",
      closeable: false,
      onClose: () => setShowModal(false),
      children: /* @__PURE__ */ jsx("div", { className: "p-4 bg-blueGray-100 rounded-md", children: /* @__PURE__ */ jsxs("form", { onSubmit: handleSubmit, children: [
        /* @__PURE__ */ jsx("h1", { className: "font-bold text-xl text-blueGray-700 mb-4", children: "KIRIM NOTIFIKASI" }),
        /* @__PURE__ */ jsxs("div", { className: "w-full flex flex-col items-start gap-2", children: [
          /* @__PURE__ */ jsx(
            SelectSearch,
            {
              name: "notif_type",
              label: "Jenis Notifikasi",
              value: notifType,
              options: notifTypeOpts,
              className: "w-full md:w-1/2",
              onChange: (e) => setNotifType(e ? e : {})
            }
          ),
          /* @__PURE__ */ jsxs("div", { className: "flex items-center", children: [
            /* @__PURE__ */ jsx(
              "input",
              {
                type: "checkbox",
                className: "w-3 h-3 rounded-md text-sm text-gray-600 mx-2",
                onChange: () => {
                  setUsers([]);
                  setAllUser((prev) => !prev);
                },
                defaultChecked: allUser
              }
            ),
            /* @__PURE__ */ jsx("label", { className: "text-md text-gray-800 mr-1", children: "All Petugas" })
          ] }),
          /* @__PURE__ */ jsx(
            SelectSearch,
            {
              name: "user_id",
              value: users,
              isMulti: true,
              options: userOpts,
              className: "w-full",
              onChange: (e) => setUsers(e ? e : {}),
              isDisabled: allUser
            }
          ),
          /* @__PURE__ */ jsxs("div", { className: "w-full flex flex-col", children: [
            /* @__PURE__ */ jsx("label", { className: "text-md text-gray-800 mr-1", children: "Isi Pesan" }),
            /* @__PURE__ */ jsx(
              "textarea",
              {
                className: "w-full p-2 border border-gray-300 rounded-md mt-1",
                rows: 3,
                name: "pesan",
                value: pesan,
                onChange: (e) => setPesan(e.target.value)
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "mt-4 w-full flex justify-between items-center", children: [
          /* @__PURE__ */ jsx(
            LoadingButton,
            {
              theme: "black",
              loading: processing,
              type: "submit",
              children: /* @__PURE__ */ jsx("span", { children: "Kirim" })
            }
          ),
          /* @__PURE__ */ jsx(
            LinkButton,
            {
              href: "#",
              theme: "blue",
              onClick: (e) => {
                e.preventDefault();
                setShowModal(false);
              },
              children: /* @__PURE__ */ jsx("span", { children: "Close" })
            }
          )
        ] })
      ] }) })
    }
  );
};
export {
  ModalSendNotif as M
};
