const toRupiah = (value) => {
  return new Intl.NumberFormat("id-ID", {
    style: "currency",
    currency: "IDR",
    maximumFractionDigits: 0
  }).format(value);
};
const formatNumber = (value) => {
  return new Intl.NumberFormat("en-GB", {
    maximumFractionDigits: 0
  }).format(value);
};
const copyToClipboard = (text) => {
  navigator.clipboard.writeText(text).then((elm) => {
    console.log(elm);
  });
};
export {
  copyToClipboard as c,
  formatNumber as f,
  toRupiah as t
};
