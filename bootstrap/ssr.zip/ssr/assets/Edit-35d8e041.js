import { jsx, jsxs } from "react/jsx-runtime";
import { I as Input } from "./Input-72be4948.js";
import { L as LinkButton } from "./LinkButton-a291522b.js";
import { L as LoadingButton } from "./LoadingButton-c9189101.js";
import { S as SelectSearch } from "./SelectSearch-22ab8168.js";
import { A as AdminLayout } from "./AdminLayout-4bc80775.js";
import { usePage, useForm } from "@inertiajs/react";
import { useRef } from "react";
import "tailwind-merge";
import "classnames";
import "lodash";
import "react-select";
import "./NotificationDropdown-abde11b8.js";
import "@popperjs/core";
import "./ResponsiveNavLink-41b4fa07.js";
import "react-hot-toast";
import "./AuthContext-5300e6b5.js";
import "firebase/app";
import "firebase/auth";
import "firebase/firestore";
import "firebase/storage";
import "./bootstrap-b9d9b211.js";
import "axios";
import "firebase/messaging";
import "./MenuItem-f3c50e94.js";
const Edit = () => {
  const { pengaturan, tipeDataOpts, tipedata } = usePage().props;
  const { data, setData, errors, post, processing } = useForm({
    id: pengaturan.id,
    nama_pengaturan: pengaturan.nama_pengaturan,
    tipe_data: pengaturan.tipe_data,
    tipedata,
    grup: pengaturan.grup,
    nilai: pengaturan.nilai,
    _method: "PUT"
  });
  function handleSubmit(e) {
    e.preventDefault();
    post(route("admin.pengaturans.update", pengaturan.id));
  }
  const onChange = (e) => {
    setData({ ...data, tipedata: e, tipe_data: (e == null ? void 0 : e.value) ?? "text" });
  };
  useRef(null);
  return /* @__PURE__ */ jsx(AdminLayout, { children: /* @__PURE__ */ jsx("div", { className: "flex content-center items-center justify-center h-full", children: /* @__PURE__ */ jsx("div", { className: "w-full lg:w-2/3 px-4", children: /* @__PURE__ */ jsxs("div", { className: "relative flex flex-col min-w-0 break-words w-full mb-6 shadow-lg shadow-slate-400 rounded-lg bg-blueGray-200 border-0", children: [
    /* @__PURE__ */ jsxs("div", { className: "rounded-t mb-0 px-6 py-6", children: [
      /* @__PURE__ */ jsx("div", { className: "text-center mb-3", children: /* @__PURE__ */ jsx("h6", { className: "text-blueGray-500 text-lg font-bold", children: "Edit Pengaturan" }) }),
      /* @__PURE__ */ jsx("hr", { className: "mt-6 border-b-1 border-blueGray-300" })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "flex-auto px-4 lg:px-10 py-10 pt-0", children: /* @__PURE__ */ jsxs("form", { onSubmit: handleSubmit, children: [
      /* @__PURE__ */ jsx(
        Input,
        {
          name: "nama_pengaturan",
          label: "Nama Pengaturan",
          errors: errors.nama_pengaturan,
          value: data.nama_pengaturan,
          type: "nama_pengaturan",
          onChange: (e) => setData(
            "nama_pengaturan",
            e.target.value
          )
        }
      ),
      /* @__PURE__ */ jsx(
        Input,
        {
          name: "grup",
          autoComplete: "false",
          label: "Grup",
          errors: errors.grup,
          value: data.grup,
          type: "text",
          onChange: (e) => setData("grup", e.target.value)
        }
      ),
      /* @__PURE__ */ jsx(
        Input,
        {
          name: "nilai",
          label: "Nilai",
          errors: errors.nilai,
          value: data.nilai,
          onChange: (e) => setData("nilai", e.target.value)
        }
      ),
      /* @__PURE__ */ jsx(
        SelectSearch,
        {
          name: "tipedata",
          options: tipeDataOpts,
          label: "Tipe Data",
          onChange,
          value: data.tipedata
        }
      ),
      /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between", children: [
        /* @__PURE__ */ jsx(
          LinkButton,
          {
            theme: "blueGrey",
            href: route("admin.pengaturans.index"),
            children: /* @__PURE__ */ jsx("span", { children: "Kembali" })
          }
        ),
        /* @__PURE__ */ jsx(
          LoadingButton,
          {
            theme: "black",
            loading: processing,
            type: "submit",
            children: /* @__PURE__ */ jsx("span", { children: "Simpan" })
          }
        )
      ] })
    ] }) })
  ] }) }) }) });
};
export {
  Edit as default
};
